import org.junit.runner.Result;

import org.junit.runner.JUnitCore;
import il.ac.huji.cs.intro.junit.internal.IntroListener;

/**
 * Driver for Ex5 testers.
 * 
 * @author Intro2cs Team
 *
 */
public class Ex5TesterDriver {
	/**
	 * Runs the testers.
	 * @param args ignored.
	 */
	public static void main(String[] args) {
		JUnitCore junit = new JUnitCore();
		junit.addListener(new IntroListener(System.out));
		Result res=junit.run(GameOfLifeTester.class);
		System.exit(res.wasSuccessful() ? 0 : 1);
	}
}
