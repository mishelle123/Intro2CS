import org.junit.runner.*;

import org.junit.runner.JUnitCore;
import org.junit.internal.TextListener;

/**
 * Runs a single test.
 * @author intro2cs Team
 */
public class SingleTest {
    /**
     * Runs a single tester method.
     * @param args the class and method names.
     * @throws ClassNotFoundException if the given class is not found.
     */
    public static void main(String[] args) throws ClassNotFoundException {
        JUnitCore junit = new JUnitCore();
        junit.addListener(new TextListener(System.out));
        if (args.length < 2) {
            System.err.println("Usage: java SingleTest <ClassName> <methodName>");
            return;
        }
        Request request = Request.method(Class.forName(args[0]),args[1]);
        Result res = junit.run(request);
    }
}
