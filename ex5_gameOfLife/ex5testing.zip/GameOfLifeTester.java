import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

/**
 * Tests the public API of the GameOfLife class.
 *
 * @author Intro2cs Team.
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class GameOfLifeTester {
    private static final int HEIGHT = 5;
    private static final int WIDTH = 6;

    private static final String EMPTY_WORLD = "------\n" +
                                              "------\n" +
                                              "------\n" +
                                              "------\n" +
                                              "------\n";

    private static final String FULL_WORLD =  "++++++\n" +
                                              "++++++\n" +
                                              "++++++\n" +
                                              "++++++\n" +
                                              "++++++\n";

    private static final String SOME_WORLD =  "------\n" +
                                              "++++++\n" +
                                              "---+++\n" +
                                              "++-+-+\n" +
                                              "--+++-\n";
    
    /**
     * Tests the constructors.
     */    
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testCtor() {
        GameOfLife g;

        g = new GameOfLife(HEIGHT, WIDTH);
        assertEquals(EMPTY_WORLD, g.toString());

        g = new GameOfLife(HEIGHT, WIDTH, false);
        assertEquals(EMPTY_WORLD, g.toString());

        g = new GameOfLife(HEIGHT, WIDTH, true);
        assertEquals(EMPTY_WORLD, g.toString());

        g = new GameOfLife(HEIGHT, WIDTH, FULL_WORLD, false);
        assertEquals(FULL_WORLD, g.toString());

        g = new GameOfLife(HEIGHT, WIDTH, FULL_WORLD, true);
        assertEquals(FULL_WORLD, g.toString());

        g = new GameOfLife(HEIGHT, WIDTH, SOME_WORLD, false);
        assertEquals(SOME_WORLD, g.toString());

        g = new GameOfLife(HEIGHT, WIDTH, SOME_WORLD, true);
        assertEquals(SOME_WORLD, g.toString());
    }

    /**
     * Tests addCreature.
     */        
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testAddCreature() {
        testAddCreature(true);
        testAddCreature(false);
    }
    
    // Tests addCreature in a cyclic / acyclic world.
    private void testAddCreature(boolean isCyclic) {
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, isCyclic);
        for (int i = 0; i < Math.min(HEIGHT, WIDTH); i++){
            g.addCreature(i, i);
        }
        assertEquals("+-----\n" +
                     "-+----\n" +
                     "--+---\n" +
                     "---+--\n" +
                     "----+-\n",
                     g.toString());
    }

    /**
     * Tests removeCreature.
     */        
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testRemoveCreature() {
        testRemoveCreature(true);
        testRemoveCreature(false);
    }
    
    // Tests removeCreature in a cyclic / acyclic world.
    private void testRemoveCreature(boolean isCyclic) {
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, FULL_WORLD, isCyclic);
        for (int i = 0; i < Math.min(HEIGHT, WIDTH); ++i){
            g.removeCreature(i, i);
        }
        assertEquals("-+++++\n" +
                     "+-++++\n" +
                     "++-+++\n" +
                     "+++-++\n" +
                     "++++-+\n",
                     g.toString());
    }

    /**
     * Tests getWorld.
     */        
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testGetWorld() {
        testGetWorld(true);
        testGetWorld(false);
    }
    
    // Tests getWorld in a cyclic / acyclic world.
    private void testGetWorld(boolean isCyclic) {
        boolean[][] expected = { { false, false, false, false, false, false },
                                 { true,  true,  true,  true,  true,  true  },
                                 { false, false, false, true,  true,  true  },
                                 { true,  true,  false, true,  false, true  },
                                 { false, false, true,  true,  true,  false } };
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, SOME_WORLD, isCyclic);
        boolean[][] snapshot = g.getWorld();

        assertEquals(HEIGHT, snapshot.length);
        for (int i = 0; i < snapshot.length ; i++) {
	    assertEquals(WIDTH, snapshot[i].length);
            for (int j = 0; j < snapshot[i].length ; j++) {
                assertEquals("Fail with i="+i+" and j="+j,
                             expected[i][j], snapshot[i][j]);
            }
        }
        
        assertNotSame("getWorld returned the same array reference twice (expected a copy)", g.getWorld() , snapshot);

         // Change snapshot and make sure the world is unchanged.
         snapshot[1][1] = true;
        assertEquals("Changing the result of getWorld should not change the world", SOME_WORLD, g.toString());

        // Perform addCreature and then test that the snapshot is unchanged.
        g.addCreature(0, 0);
        assertFalse("Adding a creature should not change a prefetched result of getWorld", snapshot[0][0]);

        // Call getWorld again, and see that the result is indeed updated by
        // addCreature.
        assertTrue("A second call to getWorld after adding a creature does " +
                   " not reflect the addition", g.getWorld()[0][0]);
    }

    /**
     * Tests getWidth.
     */        
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testGetWidth() {
        testGetWidth(true);
        testGetWidth(false);
    }

    // Tests getWidth in a cyclic / acyclic world.
    private void testGetWidth(boolean isCyclic) {
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, isCyclic);
        assertEquals("testGetWidth failed", WIDTH, g.getWidth());

        g = new GameOfLife(HEIGHT, WIDTH, SOME_WORLD, isCyclic);
        assertEquals("testGetWidth failed", WIDTH, g.getWidth());

        g = new GameOfLife(HEIGHT, 1000002, isCyclic);
        assertEquals("testGetWidth failed", 1000002, g.getWidth());
    }

    /**
     * Tests getHeight.
     */         
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testGetHeight() {
        testGetHeight(true);
        testGetHeight(false);
    }

    // Tests getHeight in a cyclic / acyclic world.
    private void testGetHeight(boolean isCyclic) {
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, isCyclic);
        assertEquals("testGetHeight failed", HEIGHT, g.getHeight());

        g = new GameOfLife(HEIGHT, WIDTH, SOME_WORLD, isCyclic);
        assertEquals("testGetHeight failed", HEIGHT, g.getHeight());

        g = new GameOfLife(12312, WIDTH, isCyclic);
        assertEquals("testGetHeight failed", 12312, g.getHeight());
    }
    
    /**
     * Tests toString.
     */        
    @Test(timeout=1000) @TestPenalty(penalty=-15)
    public void testToString() {
        testToString(true);
        testToString(false);
    }

    // Tests toString in a cyclic / acyclic world.
    private void testToString(boolean isCyclic) {
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, isCyclic);
        g.addCreature(0,0);
        g.addCreature(0,1);
        g.addCreature(0,2);
        g.addCreature(2,5);
        g.addCreature(3,0);
        g.addCreature(4,0);
        g.addCreature(4,1);
        g.addCreature(4,2);
        g.addCreature(4,3);
        g.addCreature(4,4);
        
        assertEquals("+++---\n" +
                     "------\n" +
                     "-----+\n" +
                     "+-----\n" +
                     "+++++-\n",
                     g.toString());
    }
    
    /**
     * Tests nextGeneration() in a cyclic world using the blinker pattern.
     * The blinker pattern alternates between horizontal and vertical
     * 3-creature lines.
     */    
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBlinkerCyclicNextGeneration(){    
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH);
        g.addCreature(0,0);
        g.addCreature(0,1);
        g.addCreature(0,2);

        for (int i = 0; i < 100; ++i) {
            assertEquals("+++---\n" +
                         "------\n" +
                         "------\n" +
                         "------\n" +
                         "------\n",
                         g.toString());
            g.nextGeneration();
            assertEquals("-+----\n" +
                         "-+----\n" +
                         "------\n" +
                         "------\n" +
                         "-+----\n",
                         g.toString());
            g.nextGeneration();
        }    
    }
    
    /**
     * Tests nextGeneration() in an acyclic world using the blinker pattern
     * on the edge of the world.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBlinkerNonCyclicNextGeneration(){    
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, false);
        g.addCreature(0,0);
        g.addCreature(0,1);
        g.addCreature(0,2);
        
        assertEquals("+++---\n" +
                     "------\n" +
                     "------\n" +
                     "------\n" +
                     "------\n",
                     g.toString());

        g.nextGeneration();

        assertEquals("-+----\n" +
                     "-+----\n" +
                     "------\n" +
                     "------\n" +
                     "------\n",
                     g.toString());

        g.nextGeneration();

        stressTestStill(EMPTY_WORLD, g);
    }
    
    /**
     * Tests nextGeneration() using the block "still life" pattern.
     */    
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBlockNextGeneration() {
        testBlockNextGeneration(true);
        testBlockNextGeneration(false);
    }

    // Tests the block still life pattern in a cyclic / acyclic world.
    private void testBlockNextGeneration(boolean isCyclic) {
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, isCyclic);
        g.addCreature(0,0);
        g.addCreature(0,1);
        g.addCreature(1,0);
        g.addCreature(1,1);

        stressTestStill("++----\n" +
                        "++----\n" +
                        "------\n" +
                        "------\n" +
                        "------\n",
                        g);
    }

    /**
     * Tests nextGeneration() using the boat "still life" pattern.
     */    
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBoatNextGeneration() {
        testBoatNextGeneration(true);
        testBoatNextGeneration(false);
    }

    // Tests the boat still life pattern in a cyclic / acyclic world.
    private void testBoatNextGeneration(boolean isCyclic) {
        GameOfLife g = new GameOfLife(HEIGHT, WIDTH, isCyclic);
        g.addCreature(1,1);
        g.addCreature(1,2);
        g.addCreature(2,1);
        g.addCreature(2,3);
        g.addCreature(3,2);

        stressTestStill("------\n" +
                        "-++---\n" +
                        "-+-+--\n" +
                        "--+---\n" +
                        "------\n",
                        g);
    }

    // Verifies that g holds a still world, represented by expected.
    private void stressTestStill(String expected, GameOfLife g) {
        for (int i = 0; i < 100; ++i) {
            assertEquals(expected, g.toString());
            g.nextGeneration();
        }
    }
    
    /**
     * Tests construction, nextGeneration and toString using a 50x50 world.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-15)
    public void testHugeWorld() {
        String huge = "+--+--+-++--+-----+----+-+-+----+-+-+---+------+--\n" +
                      "++--+--------++-+-+-++---+++------+------+---+++--\n" +
                      "---+--+---+---+-----+--+---+-----+---+--+----++++-\n" +
                      "--++-+-----+-+---++-+-------+--+--+-++-------+-++-\n" +
                      "-++---+--------+-+-+----------------+---+-+------+\n" +
                      "+----+-+++---------+-----+---+-+++---+------+-+---\n" +
                      "------++--+---+-------------+------++--+-+-----+--\n" +
                      "----------+--+-----+---+--+--+------+-+---+----+++\n" +
                      "+--+---+----++++-+---------+---+--++-++--+--------\n" +
                      "-++++-++-+-+---+------------+--+---++-------+++++-\n" +
                      "-+-+--+--+-+-+-+--+--++---+-++--+----+-+-++---+--+\n" +
                      "-+------+-++----+-++----+++---+----++---------+---\n" +
                      "----------+------++-+---+---+---------+++++--+--+-\n" +
                      "-+--------+---+----+-+-----+++-----++--+-+-+++++-+\n" +
                      "---+-+-+-----+----++----+--+---+++-+++------+--++-\n" +
                      "--+---+---------+----++--+++--+-------+-++-+---+--\n" +
                      "++-+--------+--+-+--+-++------+-++-+++-+++-+-+----\n" +
                      "+-------+---+---++-+-+--+-++--+---+--+------++-+--\n" +
                      "-+----+--+--+++---+-+--+-+----+--+-----++---------\n" +
                      "+-+--------+------------+--+++-+-+---+--------+-++\n" +
                      "-+-------+-----++------+-+-+-+---++-+---+-----+---\n" +
                      "+---+++-+----+---+--+++-+-----+-+------+------+--+\n" +
                      "-++--+--+++-+-+---+---+-++------+-+-+++----+-+-++-\n" +
                      "-+-----+-----+---+--+---------+------++++-+---+--+\n" +
                      "----+---+------+-+---+++-+--+--++-+----+---+-+---+\n" +
                      "-+-----+--++--+----++-+--+---+-------+----------+-\n" +
                      "---------+---+++---+-+---+---+---++----++---++--++\n" +
                      "-+--++++-----+--+---+-----+-+--+++-----+--+---+-+-\n" +
                      "----+---+-+------+---+----++-+-------+--+---------\n" +
                      "-+--+------+-+--++-++--+------++------+-+-+------+\n" +
                      "------+-+-++------++--+-+---+-+-+----+------+----+\n" +
                      "----+----+--------+----+++-++---+++----+-+-++----+\n" +
                      "------+----+---+--++---+-+-++--+--+++---+-------++\n" +
                      "--+-+----+--++-++-----++---+----+---+---+----++---\n" +
                      "+-------+-------++---+------+------+-++++-+-------\n" +
                      "----------+--+--+-+-+--++-+---++--++--+--+-----+-+\n" +
                      "----+---++--+-++++-++-------++------+-----+----++-\n" +
                      "+-+------+---+-+-+--++----+-+---+----------+-+---+\n" +
                      "---+++---------++-------+++++-+-+----------+-----+\n" +
                      "-----+----++-++---+-+--------+-+------+------+----\n" +
                      "--+++-------------++----------+--++++-------+--+--\n" +
                      "+---------+------+----+-++++---+---+------+------+\n" +
                      "+-+----+--++----+-++--+--------++-----+----+-----+\n" +
                      "--+---+----+---------+---++++--+--+--------+------\n" +
                      "+-+-------------+----------++-++-+----+-------+---\n" +
                      "--+--++++++---+-++-+--+-+---++--+---++--+-+----+--\n" +
                      "-+--+---+-+-----+-+-+-------+--++-+----++--------+\n" +
                      "-----++--++--------------+----+---+-+-----++-----+\n" +
                      "----+--+++---+-+--------+-+++--++-+---+---+-----+-\n" +
                      "-----+-+++--+--++--++-+--+---++------------+++-+--\n";

        // Cyclic.
        GameOfLife g = new GameOfLife(50, 50, huge, true);
        assertEquals(huge, g.toString());
        g.nextGeneration();
        assertEquals("++--+++--+--+-+-+-+---+--+-++----+-+-----------++-\n" +
                     "++++++-+-+---+++-+--+++--+-++-----++----++---+---+\n" +
                     "-+-+-+------+-++--+-+------++----+++++------+----+\n" +
                     "-+-++++-------+-+++-+--------------+++---+---+---+\n" +
                     "+++++++++-------++-++---------++-+-++--------+++++\n" +
                     "++---+--++--------+-------------+--+-+--++--------\n" +
                     "------++--+-----------------+++-+--++-+-------++-+\n" +
                     "------++---++--+-----------++-----+---+++++----+++\n" +
                     "++-++-+++-++++-++----------++-+---+---+------+----\n" +
                     "-+--++++---+---+------------+++++-++----+++--+++++\n" +
                     "-+-++++--+-+--++++++------+-++++-----+----------+-\n" +
                     "+-+--------++---+---++-++-+-+-------++-------+++--\n" +
                     "+---------+------+--+---+-+-+--------+++-+++----+-\n" +
                     "-----------------+---------+-+--+-++---+-+-+-----+\n" +
                     "--+---+-----------++-++--+---++++-++-+++-+--------\n" +
                     "-++++-+---------+++++++-++++--+-------+--+-+--+++-\n" +
                     "+++------------+-++-+--++----++--+++++-+-+-+-+----\n" +
                     "+-+--------++-++++-+-+--+++--++-+-++-+---+--+++---\n" +
                     "-+---------+++---++++--+-+----+++++---+------++++-\n" +
                     "+-+-------+-++++-------+-+-+-+---+-----++------+-+\n" +
                     "-+---+----------+----+++-+++-+-+-++----------++-+-\n" +
                     "+-+-+++++-+--+++++---++---+----++-+-+-++-----++-++\n" +
                     "-++-++--++--+-+--++++-+-++-------+--+---+----+-++-\n" +
                     "-++----+-----++-+++------+------+--++---+-++-+++-+\n" +
                     "-------++-----+-+-++--+++----+++-----+-++-------++\n" +
                     "+-------+++--+--+-++---+-++-+++-+-+---+++----+--+-\n" +
                     "+----+-++-+-++-+---+-+---++-+++--++---+++----+--++\n" +
                     "----++++++---+-++---++---++-+++-+++---++-+---+-+++\n" +
                     "+--++-++----+----+++-+----++++--------+-+---------\n" +
                     "+----+-+---++---++-+++++---++-++-----+++-+--------\n" +
                     "-----+---++++-------+-+--+-++-+-+-----+++++-+---++\n" +
                     "+----+-+-+-+-----+----+--+------+-+-+---+--++----+\n" +
                     "---+-+----+-+-++++++-----+-----+--+-+--+++--++--++\n" +
                     "------------+-++--+---+++-++------+---+-+--------+\n" +
                     "---------+--+++------+--+--+---+--++-++-+-----+---\n" +
                     "--------+----++---+-++-----++-+---++--+-+++----+-+\n" +
                     "+-------+++-+------------+--++++---+------+---++--\n" +
                     "+----+--++---+---+++++----+----+----------+++----+\n" +
                     "+--+++----+-++-+++-+++---++-+-+-+----------------+\n" +
                     "--+--+--------++-++------+++++-+++++--------+-----\n" +
                     "---++-----++-----+++-----++---+++-+++-------------\n" +
                     "+-+-------++-----+-----+-++---++-+-++------+----++\n" +
                     "+---------++-----++--++++---+-+++---------++-----+\n" +
                     "+-++------++-----+--------+-++---+---------------+\n" +
                     "--++-+--+++----+++-------+----++-+---+------------\n" +
                     "+-++-++++-+-----+-++-----------------++-++--------\n" +
                     "+---+------+---++-++--------+-+++---++-++-++----+-\n" +
                     "+---+++---+--------------++-+++---+----+-+++----++\n" +
                     "----+---------+++-------+-+++--+-+-+------+-----+-\n" +
                     "----++----+-+++++--+---+-+---++-+--+-------++-+++-\n",
                     g.toString());

        // Acyclic.
        g = new GameOfLife(50, 50, huge, false);
        assertEquals(huge, g.toString());
        g.nextGeneration();
        assertEquals("++-----------+---+-+----++-+-----+-+-----------+--\n" +
                     "++++++-+-+---+++-+--+++--+-++-----++----++---+----\n" +
                     "-+-+-+------+-++--+-+------++----+++++------+-----\n" +
                     "-+-++++-------+-+++-+--------------+++---+---+---+\n" +
                     "-++++++++-------++-++---------++-+-++--------++++-\n" +
                     "-+---+--++--------+-------------+--+-+--++--------\n" +
                     "------++--+-----------------+++-+--++-+-------++--\n" +
                     "------++---++--+-----------++-----+---+++++----++-\n" +
                     "-+-++-+++-++++-++----------++-+---+---+------+---+\n" +
                     "++--++++---+---+------------+++++-++----+++--++++-\n" +
                     "++-++++--+-+--++++++------+-++++-----+----------+-\n" +
                     "--+--------++---+---++-++-+-+-------++-------+++--\n" +
                     "----------+------+--+---+-+-+--------+++-+++----+-\n" +
                     "-----------------+---------+-+--+-++---+-+-+-----+\n" +
                     "--+---+-----------++-++--+---++++-++-+++-+--------\n" +
                     "-++++-+---------+++++++-++++--+-------+--+-+--+++-\n" +
                     "+++------------+-++-+--++----++--+++++-+-+-+-+----\n" +
                     "+-+--------++-++++-+-+--+++--++-+-++-+---+--+++---\n" +
                     "++---------+++---++++--+-+----+++++---+------++++-\n" +
                     "+-+-------+-++++-------+-+-+-+---+-----++------+--\n" +
                     "++---+----------+----+++-+++-+-+-++----------++-++\n" +
                     "+-+-+++++-+--+++++---++---+----++-+-+-++-----++-+-\n" +
                     "+++-++--++--+-+--++++-+-++-------+--+---+----+-+++\n" +
                     "-++----+-----++-+++------+------+--++---+-++-+++-+\n" +
                     "-------++-----+-+-++--+++----+++-----+-++-------++\n" +
                     "--------+++--+--+-++---+-++-+++-+-+---+++----+--+-\n" +
                     "-----+-++-+-++-+---+-+---++-+++--++---+++----+--++\n" +
                     "----++++++---+-++---++---++-+++-+++---++-+---+-+++\n" +
                     "---++-++----+----+++-+----++++--------+-+---------\n" +
                     "-----+-+---++---++-+++++---++-++-----+++-+--------\n" +
                     "-----+---++++-------+-+--+-++-+-+-----+++++-+---++\n" +
                     "-----+-+-+-+-----+----+--+------+-+-+---+--++----+\n" +
                     "---+-+----+-+-++++++-----+-----+--+-+--+++--++--++\n" +
                     "------------+-++--+---+++-++------+---+-+---------\n" +
                     "---------+--+++------+--+--+---+--++-++-+-----+---\n" +
                     "--------+----++---+-++-----++-+---++--+-+++----+--\n" +
                     "--------+++-+------------+--++++---+------+---++-+\n" +
                     "-----+--++---+---+++++----+----+----------+++----+\n" +
                     "---+++----+-++-+++-+++---++-+-+-+-----------------\n" +
                     "--+--+--------++-++------+++++-+++++--------+-----\n" +
                     "---++-----++-----+++-----++---+++-+++-------------\n" +
                     "--+-------++-----+-----+-++---++-+-++------+----+-\n" +
                     "----------++-----++--++++---+-+++---------++------\n" +
                     "--++------++-----+--------+-++---+----------------\n" +
                     "--++-+--+++----+++-------+----++-+---+------------\n" +
                     "--++-++++-+-----+-++-----------------++-++--------\n" +
                     "----+------+---++-++--------+-+++---++-++-++----+-\n" +
                     "----+++---+--------------++-+++---+----+-+++----++\n" +
                     "----+---------+++-------+-+++--+-+-+------+-----+-\n" +
                     "------++-+----+++--------+++++++-----------++-----\n",
                     g.toString());
    }
}
