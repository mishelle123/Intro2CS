import static org.junit.Assert.*;
import il.ac.huji.cs.intro.ex8.Sequence;

import org.junit.runner.RunWith;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.Test;

/**
 * Tests for the constant sequence.
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class ConstantSequenceTester {

    private static void checkSequence(double constant) {
        checkSequence(constant, null);
    }

    private static void checkSequence(double constant, Sequence seq) {
        if(seq == null)
            seq = new ConstantSequence(constant);
        for(int i = 0; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(constant, seq.next(), 0);
        }
    }

    private static void checkToString(double constant) {
        checkToString(constant, null);
    }

    private static void checkToString(double constant, Sequence seq) {
        if(seq == null)
            seq = new ConstantSequence(constant);
        assertEquals(Double.toString(constant), seq.toString());
        assertEquals(Double.toString(constant), seq.toString());
    }

    private static void checkIndependence(double constant1, double constant2) {
        Sequence seq1 = new ConstantSequence(constant1);
        Sequence seq2 = new ConstantSequence(constant2);
        checkSequence(constant1, seq1);
        checkSequence(constant2, seq2);
        checkToString(constant1, seq1);
        checkToString(constant2, seq2);
        checkSequence(constant1, seq1);
        checkSequence(constant2, seq2);

    }

    /**
     * Basic constant sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequence1() {
        checkSequence(1);
    }

    /**
     * Basic constant sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequence_neg_pi() {
        checkSequence(-Math.PI);
    }
    
    /**
     * Basic constant sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequence0() {
        checkSequence(0);
    }

    /**
     * toString constant sequence tests.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToString() {
        checkToString(0);
        checkToString(1);
        checkToString(-Math.PI);
    }

    /**
     * Tests independence of separate constant sequences.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIndependence2_3() {
        checkIndependence(2,3);
    }
}
