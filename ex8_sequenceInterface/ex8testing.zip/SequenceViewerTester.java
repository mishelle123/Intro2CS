import static org.junit.Assert.*;

import org.junit.runner.RunWith;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import il.ac.huji.cs.intro.ex8.MockPlotter;
import il.ac.huji.cs.intro.ex8.SequencePlotter;
import il.ac.huji.cs.intro.ex8.SequencePlotter.CURVE_DISPLAY_STYLE;
import il.ac.huji.cs.intro.ex8.SequencePlotter.Point;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for the sequence viewer class.
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class SequenceViewerTester {

    /**
     * The expected "usage" string to be presented by the main function.
     */
    private static final String USAGE_STRING = 
            "Usage: SequenceViewer filePath, "
            + "where filePath is a path to an input file.";
    
    /**
     * Stream redirection variables. Stdout will be redirected here.
     */
    private ByteArrayOutputStream out;
    private PrintStream sysout;
    
    /**
     * The current mock plotter instance. Updated on each test run.
     */
    private MockPlotter mockPlotter;
    
    /**
     * Directory in which the test inputs are in.
     * (One version for automatic, and one for manual)
     */
    private static final String INPUT_DIRECTORY_LOCAL = "testInputs";
    private static final String INPUT_DIRECTORY_AUTO = "/cs/course/2012/introcsp/testers/ex8/testInputs";
    private static String INPUT_DIRECTORY = INPUT_DIRECTORY_LOCAL;
    
    public static void setAutomatic(boolean auto) {
        INPUT_DIRECTORY = auto ? INPUT_DIRECTORY_AUTO : INPUT_DIRECTORY_LOCAL;
    }
    
    /**
     * Called before the tests. 
     */
    @Before
    public void setUp() {
        // Redirect stdout:
        out = new ByteArrayOutputStream();
        sysout = System.out;
        System.setOut(new PrintStream(out));
        
        // Get a fresh mock plotter instance:
        mockPlotter = SequencePlotter.startTestMode();
    }

    /**
     * Called after the tests.
     */
    @After
    public void tearDown() {
        mockPlotter = null;
        
        // Reset stream redirection:
        System.setOut(sysout);
    }
    
    /**
     * Tests behavior for illegal input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIllegalInputNoArgs() {
        SequenceViewer.main(new String[] {});
        assertFalse("No window should be opened upon illegal input.", 
                mockPlotter.isWindowOpen());
        assertEquals("Usage instructions string was wrong, upon illegal input."
                ,USAGE_STRING, out.toString().trim());
    }
    
    /**
     * Tests behavior for illegal input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIllegalInputTwoArgs() {
        SequenceViewer.main(new String[] {"abc", "def" });
        assertFalse("No window should be opened upon illegal input.", 
                mockPlotter.isWindowOpen());
        assertEquals("Usage instructions string was wrong, upon illegal input."
                ,USAGE_STRING, out.toString().trim());
    }
    
    /**
     * Tests a simple continuous plot.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIdentityContinuousPlot() {
        
        int curve1Size = 100;
        Point[] expectedCurve1 = new Point[curve1Size];
        for(int x = 0; x < curve1Size; x++) {
            expectedCurve1[x] = new Point(x, x);
        }
        
        testMain(INPUT_DIRECTORY+File.separator+"identity_continuous.txt",
                new Point[][] { expectedCurve1 },
                new Color[] { java.awt.Color.black} , 
                new CURVE_DISPLAY_STYLE[] 
                { 
                CURVE_DISPLAY_STYLE.CONTINUOUS_LINEAR_INTERPOLATION 
                },
                new double[] {});
        
    }

    /**
     * Tests a simple dot plot.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIdentityDotPlot() {
        
        int curve1Size = 1003;
        Point[] expectedCurve1 = new Point[curve1Size];
        for(int x = 0; x < curve1Size; x++) {
            expectedCurve1[x] = new Point(x, x);
        }
        
        testMain(INPUT_DIRECTORY+File.separator+"identity_dotPlot.txt",
                new Point[][] { expectedCurve1 },
                new Color[] { java.awt.Color.red} , 
                new CURVE_DISPLAY_STYLE[] 
                { 
                CURVE_DISPLAY_STYLE.DOT_PLOT 
                },
                new double[] {});
        
    }

    
    /**
     * Tests a simple plot.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIdentityPlotWithLimitPoints() {
        
        int curve1Size = 100;
        Point[] expectedCurve1 = new Point[curve1Size];
        for(int x = 0; x < curve1Size; x++) {
            expectedCurve1[x] = new Point(x, x);
        }
        
        testMain(INPUT_DIRECTORY+File.separator+
                "identity_continuous_withLimits.txt",
                new Point[][] { expectedCurve1 },
                new Color[] { java.awt.Color.green} , 
                new CURVE_DISPLAY_STYLE[] 
                { 
                CURVE_DISPLAY_STYLE.CONTINUOUS_LINEAR_INTERPOLATION 
                },
                new double[] {-86.54684, 6.54684});
        
    }
    
    /**
     * Tests a two function plot.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testTwoFunctionPlot() {
        
        int curve1Size = 100;
        int curve2Size = 2356;
        Point[] expectedCurve1 = new Point[curve1Size];
        Point[] expectedCurve2 = new Point[curve2Size];
        
        for(int x = 0; x < curve1Size; x++) {
            expectedCurve1[x] = new Point(x, x*x - 17);
        }
        for(int x = 0; x < curve2Size; x++) {
            expectedCurve2[x] = new Point(x, -50.0 / (double)(x+3) );
        }
        
        testMain(INPUT_DIRECTORY+File.separator+
                "twoFunctionPlot.txt",
                new Point[][] { expectedCurve1, expectedCurve2 },
                new Color[] { java.awt.Color.blue, java.awt.Color.black} , 
                new CURVE_DISPLAY_STYLE[] 
                { 
                CURVE_DISPLAY_STYLE.CONTINUOUS_LINEAR_INTERPOLATION,
                CURVE_DISPLAY_STYLE.CONTINUOUS_LINEAR_INTERPOLATION
                },
                new double[] {});
        
    }
    
    /**
     * Tests a two function plot.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testTwoFunctionPlotWithLimits() {
        
        int curve1Size = 100;
        int curve2Size = 2356;
        Point[] expectedCurve1 = new Point[curve1Size];
        Point[] expectedCurve2 = new Point[curve2Size];
        
        for(int x = 0; x < curve1Size; x++) {
            expectedCurve1[x] = new Point(x, x*x - 17);
        }
        for(int x = 0; x < curve2Size; x++) {
            expectedCurve2[x] = new Point(x, -50.0 * (double)(x+3) );
        }
        
        testMain(INPUT_DIRECTORY+File.separator+
                "twoFunctionPlot_withLimits.txt",
                new Point[][] { expectedCurve1, expectedCurve2 },
                new Color[] { java.awt.Color.blue, java.awt.Color.black} , 
                new CURVE_DISPLAY_STYLE[] 
                { 
                CURVE_DISPLAY_STYLE.DOT_PLOT,
                CURVE_DISPLAY_STYLE.CONTINUOUS_LINEAR_INTERPOLATION
                },
                new double[] {2, -55.55});
        
    }
    
    /**
     * Tests 1000 functions plotted together.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testManyPlots() {
        int curveSize = 10;
        Point[] expectedCurve = new Point[curveSize];
        for(int x = 0; x < curveSize; x++) {
            expectedCurve[x] = new Point(x, 13);
        }
        
        SequenceViewer.main(new String[] { INPUT_DIRECTORY+File.separator+
                "manyPlots.txt" });
        
        List<List<Point>> curves = mockPlotter.getCurves();
        List<Color> curveColors = mockPlotter.getCurveColors();
        List<CURVE_DISPLAY_STYLE> curveStyles = 
                mockPlotter.getCurveStyles();
        List<Double> limitPoints = mockPlotter.getLimitPoints();
        
        assertEquals("Bad number of limit points.", 1, limitPoints.size());
        assertEquals(13, limitPoints.get(0), TestingUtils.EPSILON);
        
        assertEquals("Not all curves have been plotted.", 1000, curves.size());
        for(int i = 0; i < curves.size(); i++) {
            Color color = curveColors.get(i);
            CURVE_DISPLAY_STYLE style = curveStyles.get(i);
            List<Point> curve = curves.get(i);
            assertEquals(CURVE_DISPLAY_STYLE.CONTINUOUS_LINEAR_INTERPOLATION, 
                    style);
            assertEquals(java.awt.Color.red, color);
            assertEquals("Wrong number of points in curve.", 10, curve.size());
            for(int x = 0; x < curve.size(); x++) {
                Point p = curve.get(x);
                assertEquals(x, p.getX(), TestingUtils.EPSILON);
                assertEquals(13, p.getY(), TestingUtils.EPSILON);
            }
        }
    }
    
    /**
     * Tests the main method for a given file name.
     * A file with the file name is assumed to exist.
     * It is assumed that expectedCurves, expectedColors, expectedStyles
     * all have the same number of elements.
     * It is assumed that the contents of the input file dictate that every
     * curve has a unique color. This assumption is used in the test's logic.  
     */
    private void testMain(String filename,
            Point[][] expectedCurves, Color[] expectedColors,
            CURVE_DISPLAY_STYLE[] expectedStyles, 
            double[] expectedLimitPoints) {
        
        // Call the main method with the given filename:
        SequenceViewer.main(new String[] { filename });
        
        List<List<Point>> curves = mockPlotter.getCurves();
        List<Color> curveColors = mockPlotter.getCurveColors();
        List<CURVE_DISPLAY_STYLE> curveStyles = 
                mockPlotter.getCurveStyles();
        List<Double> limitPoints = mockPlotter.getLimitPoints();
        
        // Verify a window was opened:
        assertTrue("No call to openWindow() was made", 
                mockPlotter.isWindowOpen());
        
        //Verify limit points:
        assertEquals(expectedLimitPoints.length, limitPoints.size());
        for(double d : expectedLimitPoints) {
            assertTrue("Limit point not found.", limitPoints.contains(d));
        }
        
        // Check that a correct number of curves were created, 
        // with the correct colors and styles.
        int numOfCurves = expectedCurves.length;
        assertEquals("Exactly " + numOfCurves + 
                " curves must be created.", 
                numOfCurves, curves.size());

        for(int i = 0; i < numOfCurves; i++) {
            assertTrue("Color not found in plotted sequences: " + 
                    expectedColors[i], 
                    curveColors.contains(expectedColors[i]));
            assertTrue("Style not found in plotted sequences: " + 
                    expectedStyles[i], 
                    curveStyles.contains(expectedStyles[i]));
        }
        
        // Store the curves and styles according to their colors:
        Map<Color, List<Point>> plottedCurvesByColor = 
                new HashMap<Color, List<Point>>();
        Map<Color, CURVE_DISPLAY_STYLE> plottedStylesByColor = 
                new HashMap<Color, CURVE_DISPLAY_STYLE>();
        Map<Color, List<Point>> expectedCurvesByColor = 
                new HashMap<Color, List<Point>>();
        Map<Color, CURVE_DISPLAY_STYLE> expectedStylesByColor = 
                new HashMap<Color, CURVE_DISPLAY_STYLE>();

        for(int i = 0; i < numOfCurves; i++) {
            Color color = curveColors.get(i);
            List<Point> curve = curves.get(i);
            CURVE_DISPLAY_STYLE style = curveStyles.get(i);
            
            plottedCurvesByColor.put(color,  curve);
            plottedStylesByColor.put(color, style);
            
            color = expectedColors[i];
            curve = Arrays.asList(expectedCurves[i]);
            style = expectedStyles[i];
            
            expectedCurvesByColor.put(color,  curve);
            expectedStylesByColor.put(color, style);
        }
        
        // Compare expected and actual curves:
        for(Color c : expectedCurvesByColor.keySet()) {
            assertEquals("A curve was plotted with the wrong style.", 
                    expectedStylesByColor.get(c), 
                    plottedStylesByColor.get(c));
            
            List<Point> expectedCurve = expectedCurvesByColor.get(c);
            List<Point> actualCurve = plottedCurvesByColor.get(c);
            assertEquals("A curve had the wrong number of points.",
                    expectedCurve.size(), actualCurve.size());
            Iterator<Point> itExpected = expectedCurve.iterator();
            Iterator<Point> itActual = actualCurve.iterator();
            while(itExpected.hasNext()) {
                // We know itAcutal has a next element as well.
                Point pointExpected = itExpected.next();
                Point pointActual = itActual.next();
                assertEquals("Bad X value for a point in a curve.",
                        pointExpected.getX(), pointActual.getX(), 
                        TestingUtils.EPSILON);
                assertEquals("Bad Y value for a point in a curve.",
                        pointExpected.getY(), pointActual.getY(), 
                        TestingUtils.EPSILON);
            }
        }
        
    }

}
