import static org.junit.Assert.*;
import il.ac.huji.cs.intro.ex8.Sequence;

import org.junit.runner.RunWith;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.Test;

/**
 * Tests for the identity sequence.
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class IdentitySequenceTester {

    private static final double[] EXPECTED = getBeginningArray(10000);

    private static double[] getBeginningArray(int length) {
        double[] list = new double[length];
        for(int i=0; i<list.length; i++) {
            list[i] = i;
        }
        return list;
    }

    private static int checkSubsequence(Sequence seq, double[] expected) {
        return checkSubsequence(seq, expected, 0);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start) {
        return checkSubsequence(seq, expected, start, expected.length-start);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start, int length) {
        TestingUtils.compareSequenceWithArray(seq, expected, true, start, start+length);
        return start+length;
    }

    /**
     * Test first 3 elements of the sequence.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFirst3Elements() {
        checkSubsequence(new IdentitySequence(), EXPECTED, 0, 1);
    }
    
    /**
     * Test the first few elements of the sequence.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceFirst10000() {
        checkSubsequence(new IdentitySequence(), EXPECTED);
    }

    /**
     * toString constant sequence tests.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToString() {
        assertEquals("n", new IdentitySequence().toString());
        assertEquals("n", new IdentitySequence().toString());
    }

    /**
     * Tests independence of separate sequences.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIndependence() {
        Sequence seq1 = new IdentitySequence();
        Sequence seq2 = new IdentitySequence();
        int start1=0;
        int start2=0;
        start1 = checkSubsequence(seq1, EXPECTED, start1, 1);
        start2 = checkSubsequence(seq2, EXPECTED, start2, 1);
        for(int i=0;i<8;i++) {
            start1 = checkSubsequence(seq1, EXPECTED, start1, start2);
            start2 = checkSubsequence(seq2, EXPECTED, start2, start1);
        }
        start1 = checkSubsequence(seq1, EXPECTED, start1);
        start2 = checkSubsequence(seq2, EXPECTED, start2);
    }
}
