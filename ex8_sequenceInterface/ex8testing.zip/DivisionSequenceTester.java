import java.util.Arrays;

import static org.junit.Assert.*;
import il.ac.huji.cs.intro.ex8.Sequence;

import org.junit.runner.RunWith;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.Test;

/**
 * Tests for the sequence adder.
 *
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class DivisionSequenceTester {

    private static final String FUNCTION_NAME = "division";

    private static final double[] EMPTY = new double[0];

    private static int checkSubsequence(Sequence seq, double[] expected) {
        return checkSubsequence(seq, expected, 0);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start) {
        return checkSubsequence(seq, expected, start, expected.length-start);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start, int length) {
        TestingUtils.compareSequenceWithArray(seq, expected, true, start, start+length);
        return start+length;
    }

    private static Sequence getTestedSequence(Sequence seq1, Sequence seq2) {
        return new DivisionSequence(seq1,seq2);
    }

    private static String buildString(String str1, String str2) {
        return FUNCTION_NAME+"("+str1+","+str2+")";
    }

    private static void checkToString(String str1, String str2) {
        Sequence seq1 = getSequence(EMPTY, str1);
        Sequence seq2 = getSequence(EMPTY, str2);
        assertEquals(buildString(str1, str2), getTestedSequence(seq1, seq2).toString());
    }

    private static TestingUtils.MockSequence getSequence(double[] source) {
        return getSequence(source, null, false);
    }

    private static TestingUtils.MockSequence getSequence(double[] source, boolean loop) {
        return getSequence(source, null, loop);
    }

    private static TestingUtils.MockSequence getSequence(double[] source, String str) {
        return getSequence(source, str, false);
    }


    private static TestingUtils.MockSequence getSequence(double[] source, String str, boolean loop) {
        return source==null ? null : new TestingUtils.MockSequence(source, str, loop);
    }

    private static void expectSequence(double[] source1, double[] source2) {
        expectSequence(source1, source2, false, false, Integer.MAX_VALUE);
    }
    
    private static void expectSequence(double[] source1, double[] source2, boolean loop1, boolean loop2) {
        expectSequence(source1, source2, loop1, loop2, Integer.MAX_VALUE);
    }
    
    /**
     * Expects the finite sequence to be the division sequence of the two arrays.
     */
    private static void expectSequence(double[] source1, double[] source2, boolean loop1, boolean loop2, int length) {
        expectSequence(source1, source2, loop1, loop2, 0, 0, length);
    }
    private static void expectSequence(double[] source1, double[] source2, boolean loop1, boolean loop2, int offset1, int offset2) {
        expectSequence(source1, source2, loop1, loop2, offset1, offset2, Integer.MAX_VALUE);
    }

    private static void expectSequence(double[] source1, double[] source2, boolean loop1, boolean loop2, 
                                       int offset1, int offset2, int length) {
        Sequence seq1 = getSequence(source1,loop1);
        Sequence seq2 = getSequence(source2,loop2);
        for(int i=0; i<offset1;i++) {
            seq1.next();
        }
        for(int i=0; i<offset2;i++) {
            seq2.next();
        }
        Sequence seq = getTestedSequence(seq1,seq2);
        source1 = loop1 ? TestingUtils.shiftArray(source1, offset1) : TestingUtils.offsetArray(source1, offset1);
        source2 = loop2 ? TestingUtils.shiftArray(source2, offset2) : TestingUtils.offsetArray(source2, offset2);

        double[] expected = getExpectedSequences(source1, source2, loop1, loop2, length);
        boolean expectMore = source1!=null && source2!=null && source1.length>0 && source2.length>0 &&
            (source1.length>length || loop1) && (source2.length>length || loop2);
        TestingUtils.compareSequenceWithArray(seq, expected, expectMore);
    }
    
    private static double[] getExpectedSequences(double[] source1, double[] source2, boolean loop1, boolean loop2, int length) {
        if(source1 == null || source2 == null || length < 0) {
            length = 0;
        }
        else {
            length = ( (source1.length < length && !loop1) ? source1.length : length);
            length = ( (source2.length < length && !loop2) ? source2.length : length);
        }
        double[] expected = new double[length];
        for(int i=0; i<length; i++) {
            expected[i] = source2[i % source2.length]==0 ? 0 :source1[i % source1.length] / source2[i % source2.length];
        }
        return expected;
    }

    /**
     * Basic sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceBasic1() {
        double[] source1 = new double[] {1, 2.4, 3};
        double[] source2 = new double[] {7.7, 4, 8};
        expectSequence(source1, source2);
    }
    
    /**
     * Basic sequence division test.
     * Advances some indices in the source sequences before checking 
     * the division.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceBasic2() {
        double[] source1 = new double[] {317, 1, 2, 3};
        double[] source2 = new double[] {5.235, 456735.555, 7, 4};
        expectSequence(source1, source2, false, false, 1, 2);
    }

    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDifferentSizes1() {
        double[] source1 = new double[] {1, 2, 3};
        double[] source2 = new double[] {7, 4};
        expectSequence(source1, source2);
    }
    
    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDifferentSizes2() {
        double[] source1 = new double[] {1, 2};
        double[] source2 = new double[] {7, 4, 3};
        expectSequence(source1, source2);
    }
    
    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDifferentSizes3() {
        double[] source1 = new double[] {};
        double[] source2 = new double[] {7, 4, 3, 2345.246, 25};
        expectSequence(source1, source2);
    }

    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDifferentSizes4() {
        double[] source1 = new double[] {7, 4, 3, 2345.246, 25};
        double[] source2 = new double[] {};
        expectSequence(source1, source2);
    }
    
    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDifferentSizes5() {
        double[] source1 = new double[] {};
        double[] source2 = new double[] {};
        expectSequence(source1, source2);
    }

    /**
     * Test null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceNull1() {
        double[] source1 = null;
        double[] source2 = new double[] {1};
        expectSequence(source1, source2);
    }
    
    /**
     * Test null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceNull2() {
        double[] source1 = new double[] {1};
        double[] source2 = null;
        expectSequence(source1, source2);
    }
    
    /**
     * Test null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceNull3() {
        double[] source1 = null;
        double[] source2 = null;
        expectSequence(source1, source2);
    }
    
    /**
     * Test null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceNull4() {
        double[] source1 = null;
        double[] source2 = new double[] {1};
        expectSequence(source1, source2, true, true, 20);
    }
    
    /**
     * Test null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceNull5() {
        double[] source1 = new double[] {1};
        double[] source2 = null;
        expectSequence(source1, source2, true, true, 20);
    }
    
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToString() {
        checkToString("f","g");
        checkToString("ffff","gggg");
        checkToString("fgfg","gfgf");
        checkToString("1234","5678");
        checkToString("ff,ff","gg,gg");
        checkToString("fg(f,g)","gf(g,f)");
    }
    
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToStringNull() {
        checkToString("f",null);
        checkToString(null,"g");
        checkToString("ggg",null);
        checkToString(null,"fff");
        checkToString(null,null);
    }
    
    /**
     * Basic sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite1() {
        double[] source1 = new double[] {1, 2.4, 3};
        double[] source2 = new double[] {7.7, 4, 8};
        expectSequence(source1, source2, true, true, 30);
    }
    
    /**
     * Basic sequence division test.
     * Advances some indices in the source sequences before checking 
     * the division.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite2() {
        double[] source1 = new double[] {317, 1, 2, 3};
        double[] source2 = new double[] {5.235, 456735.555, 7, 4};
        expectSequence(source1, source2, true, true, 1, 2, 30);
    }

    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite3() {
        double[] source1 = new double[] {1, 2, 3};
        double[] source2 = new double[] {7, 4};
        expectSequence(source1, source2, true, true, 30);
    }
    
    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite4() {
        double[] source1 = new double[] {1, 2};
        double[] source2 = new double[] {7, 4, 3};
        expectSequence(source1, source2, true, false);
    }
    
    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite5() {
        double[] source1 = new double[] {1, 2};
        double[] source2 = new double[] {7, 4, 3};
        expectSequence(source1, source2, false, true);
    }
    
    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite6() {
        double[] source1 = new double[] {};
        double[] source2 = new double[] {7, 4, 3, 2345.246, 25};
        expectSequence(source1, source2, false, true);
    }

    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite7() {
        double[] source1 = new double[] {7, 4, 3, 2345.246, 25};
        double[] source2 = new double[] {};
        expectSequence(source1, source2, true, false);
    }
    
    /**
     * Tests division by zero.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDivisionZero1() {
        double[] source1 = new double[] {7, 4, 3, 2345.246, 25};
        double[] source2 = new double[] {0, -0.0, 0, -0.0, 0};
        expectSequence(source1, source2);
    }
    
    /**
     * Tests division by zero.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDivisionZero2() {
        double[] source1 = new double[] {0, 0, -0.0, -0.0, 0};
        double[] source2 = new double[] {0, -0.0, 0, -0.0, 0};
        expectSequence(source1, source2);
    }
    
    /**
     * Tests division by zero.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceDivisionZero3() {
        double[] source1 = new double[] {0, -0.0, 0, -0.0, 0};
        double[] source2 = new double[] {7, 4, 3, 2345.246, 25};
        expectSequence(source1, source2);
    }
    
    /**
     * Tests independence of separate sequences.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIndependence1() {
        double[] source11 = new double[] {1, 2, 3, 4, 5};
        double[] source12 = new double[] {1, 2, 3, 4};

        double[] source21 = new double[] {1, 2, 3};
        double[] source22 = new double[] {1, 2, 3, 4};

        double[] expected1 = getExpectedSequences(source11,source12,true,true,1000);
        double[] expected2 = getExpectedSequences(source21,source22,true,true,1000);

        Sequence seq11 = getSequence(source11,true);
        Sequence seq12 = getSequence(source12,true);
        Sequence seq21 = getSequence(source21,true);
        Sequence seq22 = getSequence(source22,true);

        Sequence seq1 = getTestedSequence(seq11, seq12);
        Sequence seq2 = getTestedSequence(seq21, seq22);

        int start1=0;
        int start2=0;
        start1 = checkSubsequence(seq1, expected1, start1, 1);
        start2 = checkSubsequence(seq2, expected2, start2, 1);
        for(int i=0;i<7;i++) {
            start1 = checkSubsequence(seq1, expected1, start1, start2);
            start2 = checkSubsequence(seq2, expected2, start2, start1);
        }
        start1 = checkSubsequence(seq1, expected1, start1);
        start2 = checkSubsequence(seq2, expected2, start2);
    }

}
