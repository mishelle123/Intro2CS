import static org.junit.Assert.assertEquals;
import il.ac.huji.cs.intro.ex8.Sequence;

import java.util.Arrays;

/**
 * Common utilities for the ex8 testers.
 * 
 * @author intro2cs team
 */
public class TestingUtils {

    /**
     * Accuracy level for double value comparisons.
     */
    public static final double EPSILON = 0.0001;
    
    /**
     * The number of iterations to perform in the stress test.
     */
    private static final int STRESS_TEST_NUMBER_OF_ITERATIONS = 10;
    
    
    /**
     * Checks hasNext() several times.
     * 
     * @param sequence the sequence to test.
     * @param expected the expected result.
     */
    public static void stressTestHasNext(Sequence sequence, 
                                    boolean expected) {
        for (int i = 0; i < STRESS_TEST_NUMBER_OF_ITERATIONS; i++) {
            assertEquals("hasNext() check failed at attempt no. "+i+".",
                    expected, sequence.hasNext());
        }
    }
    
    /**
     * Asserts that the given sequence contains exactly the elements in 
     * the array.
     * @param seq the sequence to test.
     * @param arr the array to compare with.
     */
    public static void compareSequenceWithArray(Sequence seq, double[] arr) {
        compareSequenceWithArray(seq, arr, false);
    }
    
    /**
     * Asserts that the given sequence contains the elements in 
     * the array, and possibly more at the end.
     * @param seq the sequence to test.
     * @param arr the array to compare with.
     * @param expectMoreAtTheEnd whether or not to expect more elements after
     * the array end.
     */
    public static void compareSequenceWithArray(Sequence seq, double[] arr, 
            boolean expectMoreAtTheEnd) {
        compareSequenceWithArray(seq, arr, expectMoreAtTheEnd, 0);
    }
    
    
    /**
     * Asserts that the given sequence contains exactly the elements in 
     * the array.
     * @param seq the sequence to test.
     * @param arr the array to compare with.
     * @param int beginIndex the beginning index, inclusive.
     */
    public static void compareSequenceWithArray(Sequence seq, double[] arr, int beginIndex) {
        compareSequenceWithArray(seq, arr, false, beginIndex);
    }
    
    /**
     * Asserts that the given sequence contains the elements in 
     * the array, and possibly more at the end.
     * @param seq the sequence to test.
     * @param arr the array to compare with.
     * @param expectMoreAtTheEnd whether or not to expect more elements after
     * the array end.
     * @param int beginIndex the beginning index, inclusive.
     */
    public static void compareSequenceWithArray(Sequence seq, double[] arr, 
                                                boolean expectMoreAtTheEnd,  
                                                int beginIndex) {
        compareSequenceWithArray(seq, arr, expectMoreAtTheEnd, beginIndex, arr.length);
    }
    
    
    /**
     * Asserts that the given sequence contains exactly the elements in 
     * the array.
     * @param seq the sequence to test.
     * @param arr the array to compare with.
     * @param beginIndex the beginning index, inclusive.
     * @param endIndex the ending index, exclusive.
     */
    public static void compareSequenceWithArray(Sequence seq, double[] arr, int beginIndex, int endIndex) {
        compareSequenceWithArray(seq, arr, false, beginIndex);
    }
    
    /**
     * Asserts that the given sequence contains the elements in 
     * the array, and possibly more at the end.
     * @param seq the sequence to test.
     * @param arr the array to compare with.
     * @param expectMoreAtTheEnd whether or not to expect more elements after
     * the array end.
     * @param beginIndex the beginning index, inclusive.
     * @param endIndex the ending index, exclusive.
     */
    public static void compareSequenceWithArray(Sequence seq, double[] arr, 
                                                boolean expectMoreAtTheEnd,  
                                                int beginIndex, int endIndex) {
        for(int i = beginIndex; i < endIndex; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(arr[i], seq.next(), TestingUtils.EPSILON);
        }
        TestingUtils.stressTestHasNext(seq, expectMoreAtTheEnd);
    }

    public static double[] shiftArray(double[] arr, int shift) {
        if(arr==null || arr.length<2) return arr;
        double[] copy = new double[arr.length];
        for(int i=0;i<arr.length;i++) {
            copy[i] = arr[(i+shift)%arr.length];
        }
        return copy;
    }
    
    public static double[] offsetArray(double[] arr, int offset) {
        if(arr==null || offset==0 || offset >= arr.length) return arr;
        return Arrays.copyOfRange(arr, offset, arr.length);
    }
    
    static class MockSequence implements Sequence {

        MockSequence(double[] elements) {
            this(elements,null,false);
        }
        
        MockSequence(double[] elements, boolean loop) {
            this(elements,null,loop);
        }
        
        MockSequence(double[] elements, String str) {
            this(elements,str,false);
        }
        
        MockSequence(double[] elements, String str, boolean loop) {
            nextIndex = 0;
            this.elements = elements==null ? new double[0] : elements;
            this.str = (str==null ? "null" : str);
            this.loop = loop && elements!=null && elements.length>0;
        }
        
        private double[] elements;
        private int nextIndex;
        private String str;
        private boolean loop;

        private void setNext(int index) {
            nextIndex = index%elements.length;
        }

        public double get(int index) {
            return loop ? elements[index%elements.length] : elements[index];
        }

        @Override
        public boolean hasNext() {
            return nextIndex < elements.length;
        }

        @Override
        public double next() {
            double res = elements[nextIndex];
            nextIndex++;
            if(loop) nextIndex = nextIndex % elements.length;
            return res;
        }

        @Override
        public String toString() {
            return str;
        }
    }
}
