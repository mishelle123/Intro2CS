import static org.junit.Assert.*;
import il.ac.huji.cs.intro.ex8.Sequence;

import org.junit.runner.RunWith;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.Test;

/**
 * Tests for the SequenceFactory class. 
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class SequenceFactoryTester {

    /**
     * Tests null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryNullInput() {
        Sequence seq = SequenceFactory.sequenceFromString(null);
        assertNull(seq);
    }
    
    /**
     * Tests whitepace handling in input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryWhitespace() {
        //Whitespace characters should all be ignored.
        String seqStr = "               n\t\t+(\r\r\n  \n \t2)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        
        for(double i = 0; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(i+2, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests an identity function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryIdentityFunc() {
        String seqStr = "n";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(i, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals("n", seq.toString());
    }
    
    /**
     * Tests a constant function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantFunc() {
        String seqStr = "4.11";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(4.11, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals("4.11", seq.toString());
    }
    
    /**
     * Tests basic plus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicOperatorPlus() {
        String seqStr = "8 + 2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(10, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals("addition(8.0,2.0)", seq.toString());
    }
    
    /**
     * Tests basic minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicOperatorMinus1() {
        String seqStr = "8 - 2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(6, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals("addition(8.0,multiplication(-1.0,"+
        "2.0))", seq.toString());
    }
    
    /**
     * Tests basic minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicOperatorMinus2() {
        String seqStr = "8 - 2 + 1";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(7, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests basic multiply operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicOperatorMultiply() {
        String seqStr = "8 * 2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(16, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals(
                "multiplication(8.0,2.0)", seq.toString());
    }
    
    /**
     * Tests basic division operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicOperatorDivide() {
        String seqStr = "8 / 2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(4, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals(
                "division(8.0,2.0)", seq.toString());
    }
    
    /**
     * Tests basic division operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicOperatorDivideByZero() {
        //Division by zero is defined as zero in this exercise.
        String seqStr = "8 / 0";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(0, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests basic power operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicOperatorPower() {
        String seqStr = "8 ^ 2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(64, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals("power(8.0,2.0)", seq.toString());
    }
    
    /**
     * Tests basic unary minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantBasicUnaryMinus() {
        String seqStr = "-4";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-4, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals(
                "multiplication(-1.0,4.0)", seq.toString());
    }
    
    /**
     * Tests unary minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantAdvancedUnaryMinus1() {
        String seqStr = "-(-4)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(4, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals(
                "multiplication(-1.0,"+
                "multiplication(-1.0,4.0))", 
                seq.toString());
    }
    
    /**
     * Tests unary minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantAdvancedUnaryMinusTwice() {
        String seqStr = "--4";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(4, seq.next(), TestingUtils.EPSILON);
        }
        assertEquals(
                "multiplication(-1.0,"+
                "multiplication(-1.0,4.0))", 
                seq.toString());
    }
    
    /**
     * Tests unary minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantAdvancedUnaryMinus2() {
        String seqStr = "-4+2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-2, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests unary minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantAdvancedUnaryMinus3() {
        String seqStr = "9*(-9)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-81, seq.next(), TestingUtils.EPSILON);
        }
    }

    /**
     * Tests unary minus operator.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryConstantAdvancedUnaryMinus4() {
        String seqStr = "-4+2-8+0.3";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-9.7, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests parentheses handling.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryParentheses() {
        String seqStr = "( (((n+2))-(n+2)) - (0+(7*19*0)) )";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(0, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePowerAndUnaryMinus1() {
        String seqStr = "-(-1)^n";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((-1)*Math.pow((-1),i), seq.next(), 
                    TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePowerAndUnaryMinus2() {
        String seqStr = "-n^2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((-1)*i*i, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus and power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePowerAndUnaryMinus3() {
        String seqStr = "(-n)^2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(i*i, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePowerAndUnaryMinus4() {
        String seqStr = "n^-2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(1.0/ (i*i), seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePowerAndUnaryMinus5() {
        String seqStr = "-n^-2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-1.0/ (i*i), seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of unary minus and division operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceUnaryMinusAndDivision() {
        String seqStr = "n/-1";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((i / (-1) ), seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of unary minus and multiply operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceUnaryMinusAndMultiply1() {
        String seqStr = "n*-1";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((i * (-1) ), seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of unary minus and multiply operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceUnaryMinusAndMultiply2() {
        String seqStr = "-n*-n";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(i*i, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of plus over multiply operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePlusAndMultiply() {
        String seqStr = "2+10*2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(22, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of plus over division operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePlusAndDivide() {
        String seqStr = "2+10/2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(7, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of plus over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePlusAndPower() {
        String seqStr = "2+10^2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(102, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus over multiply operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceMinusAndMultiply() {
        String seqStr = "2-10*2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-18, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus over division operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceMinusAndDivide() {
        String seqStr = "2-10/2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-3, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of minus over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceMinusAndPower() {
        String seqStr = "2-10^2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-98, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of multiply over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceMultiplyAndPower() {
        String seqStr = "2*10^2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(200, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of division over power operator. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceDivideAndPower() {
        String seqStr = "2/10^2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(0.02, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of multiply and divide operators. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceMultiplyAndDivide() {
        String seqStr = "2*10/2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(10, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of divide and multiply operators.
     * Parsing should be left-to-right in this case. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceDivideAndMultiply() {
        String seqStr = "2/10*2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((2.0/10.0)*2, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of divide and multiply operators.
     * Parsing should be left-to-right in this case. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceDivideAndMultiply2() {
        String seqStr = "2*10/2/2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((((2.0*10.0)/2.0)/2.0), seq.next(), 
                    TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of plus and minus operators. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePlusAndMinus1() {
        String seqStr = "2+10-2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(10, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of plus and minus operators. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedencePlusAndMinus2() {
        String seqStr = "-5 + -6.3";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-11.3, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests precedence of multiple power operators. 
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryPrecedenceManyPowers() {
        String seqStr = "2^3^4";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            // (2^3)^4 = 4096
            assertEquals(4096, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests a simple sequence.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySimpleSequence1() {
        String seqStr = "3+ 1/n";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            double frac = (i == 0) ? 0 : (1.0/i);
            assertEquals((3.0 + frac), seq.next(), TestingUtils.EPSILON);
        }
        assertEquals("addition(3.0,division(1.0,n))", 
                seq.toString());
    }
    
    
    /**
     * Tests a simple sequence.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySimpleSequence2() {
        String seqStr = "(3+2*n)/(5+n)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((3 + 2*i) / (double)(5 + i), seq.next(), 
                    TestingUtils.EPSILON);
        }
        
        assertEquals("division(addition(3.0,"+
                "multiplication(2.0,n)),addition(5.0,n))",
                seq.toString());
    }
    
    /**
     * Tests a simple sequence.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySimpleSequence3() {
        String seqStr = "1 - (-1)^n";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals((1 - Math.pow(-1, i)), seq.next(), 
                    TestingUtils.EPSILON);
        }
        
        assertEquals("addition(1.0,multiplication("+
                    "-1.0,power(multiplication("+
                    "-1.0,1.0),n)))", 
                    seq.toString());
    }
    
    /**
     * Tests a simple sequence.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySimpleSequence4() {
        String seqStr = "n+n+n+n+n-n-(-n)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 1000; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(5*i, seq.next(), TestingUtils.EPSILON);
        }
        
        assertEquals("addition(addition(addition(addition(addition(addition("+
                "n,n),n),n),n),multiplication(-1.0,n)),"+
                "multiplication(-1.0,multiplication("+
                "-1.0,n)))", 
                seq.toString());
    }
    
    /**
     * Tests a big sequence.
     */
    @Test(timeout=5000) @TestPenalty(penalty=-10)
    public void testFactoryBigSequence1() {
        String seqStr = "(3*n)+(21.123*n^(1/2*2))-23*18*n-(-17)+n^(11/33)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            double expected = (3*i)+(21.123*i)-
                    23*18*i-(-17)+Math.pow(i,(11.0/33.0));
            assertEquals(expected, seq.next(), TestingUtils.EPSILON);
        }
        String exp1 = 
            "addition(addition(addition(addition(multiplication("+
            "3.0,n),multiplication(21.123,"+
            "power(n,multiplication(division(1.0,"+
            "2.0),2.0)))),multiplication("+
            "multiplication(multiplication(-1.0,"+
            "23.0),18.0),n)),multiplication("+
            "-1.0,multiplication(-1.0,"+
            "17.0))),power(n,division(11.0,"+
            "33.0)))";
        String exp2 = 
            "addition(addition(addition(addition(multiplication("+
            "3.0,n),multiplication(21.123,"+
            "power(n,multiplication(division(1.0,"+
            "2.0),2.0)))),multiplication("+
            //"multiplication(multiplication(-1.0,"+
            "-1.0,multiplication(multiplication("+
            //"23.0),18.0),n)),multiplication("+
            "23.0,18.0),n))),multiplication("+
            "-1.0,multiplication(-1.0,"+
            "17.0))),power(n,division(11.0,"+
            "33.0)))";
        String output = seq.toString();
        assertTrue("Bad output for input: '(3*n)+(21.123*n^(1/2*2))-23*18*n-(-17)+n^(11/33)'",
                   exp1.equals(output) || exp2.equals(output));
    }
    
    /**
     * Tests a BIG sequence.
     */
    @Test(timeout=5000) @TestPenalty(penalty=-10)
    public void testFactoryBigSequence2() {
        String basicSeqStr = "(3*n)+(21.123*n^(1/2*2))-23*18*n-(-17)+n^(11/33)";
        String seqStr = "0";
        // Add that string a bunch of times to get a really long string:
        int numOfAdditions = 200;
        for(int i = 0; i < numOfAdditions; i++) {
            seqStr += "+ "+basicSeqStr;
        }
        
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            double singleExpected = (3*i)+(21.123*i)-
                                23*18*i-(-17)+Math.pow(i,(11.0/33.0));
            assertEquals(numOfAdditions*singleExpected, seq.next(), 
                    TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the sum() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySum1() {
        String seqStr = "sum(1)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(i, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the sum() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySum2() {
        String seqStr = "sum(2)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(2*i, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the sum() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySum3() {
        String seqStr = "sum(n) + sum(n)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        double sum = 0;
        for(double i = 0; i < 100; i++) {
            sum += i;
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(2*sum, seq.next(), TestingUtils.EPSILON);
        }
        
        assertEquals("addition(cumulativeSum(n),cumulativeSum(n))", 
                seq.toString());
    }
    
    /**
     * Tests the sum() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySum4() {
        String seqStr = "2^sum(n)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        double sum = 0;
        for(double i = 0; i < 100; i++) {
            sum += i;
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(Math.pow(2,sum), seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the sum() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySum5() {
        String seqStr = "-sum(n+5^2)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        double sum = 0;
        for(double i = 0; i < 100; i++) {
            sum += i + 25;
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(-sum, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the sum() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactorySum6() {
        String seqStr = "sum(sum(n))";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        double sum1 = 0;
        double sum2 = 0;
        for(double i = 0; i < 100; i++) {
            sum1 += i;
            sum2 += sum1;
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(sum2, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the fib() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryFib1() {
        String seqStr = "fib()";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        FibonacciSequence fib = new FibonacciSequence();
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            TestingUtils.stressTestHasNext(fib, true);
            assertEquals(fib.next(), seq.next(), TestingUtils.EPSILON);
        }
    }

    /**
     * Tests the fib() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryFib2() {
        String seqStr = "fib() - fib()";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            assertEquals(0, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the fib() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryFib3() {
        String seqStr = "2^fib() + 1/(fib()+1)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        FibonacciSequence fib = new FibonacciSequence();
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            TestingUtils.stressTestHasNext(fib, true);
            double next = fib.next();
            assertEquals(Math.pow(2, next) + 1.0/(next+1), seq.next(), 
                    TestingUtils.EPSILON);
        }
        
        assertEquals("addition(power(2.0,fib()),division("+
                "1.0,addition(fib(),1.0)))",seq.toString());
    }
    
    /**
     * Tests the fib() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryFib4() {
        String seqStr = "-(-(-fib())) - fib()";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        FibonacciSequence fib = new FibonacciSequence();
        for(double i = 1; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            TestingUtils.stressTestHasNext(fib, true);
            assertEquals(-2*fib.next(), seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the fib() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryFib5() {
        String seqStr = "n^2 -4*(fib()^2)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        FibonacciSequence fib = new FibonacciSequence();
        for(double i = 0; i < 100; i++) {
            TestingUtils.stressTestHasNext(seq, true);
            TestingUtils.stressTestHasNext(fib, true);
            double nextFib = fib.next();
            assertEquals(i*i -4*(nextFib*nextFib), seq.next(), 
                    TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the ratio() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryRatio1() {
        String seqStr = "ratio(1)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 1; i < 100; i++) {
            assertEquals(1, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the ratio() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryRatio2() {
        String seqStr = "ratio(n)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            double frac = (i == 0) ? 0 : ((i+1)/i);
            assertEquals(frac, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the ratio() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryRatio3() {
        String seqStr = "ratio((1 + n^2 / 15 + 27.462))";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            double next = 1 + ((i+1)*(i+1) / 15) + 27.462;
            double prev = 1 + (i*i / 15) + 27.462;
            assertEquals(next/prev, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the ratio() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryRatio4() {
        String seqStr = "ratio(sum(n^2) + 0 + 0 -1 +1 -1 + 1)";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        double sum = 0;
        double prev = 0;
        for(double i = 1; i < 100; i++) {
            prev = sum;
            sum += i*i;
            double frac = (prev == 0) ? 0 : (sum/prev);
            assertEquals(frac, seq.next(), TestingUtils.EPSILON);
        }
    }
    
    /**
     * Tests the ratio() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryRatio5() {
        String seqStr = "ratio(ratio(n))";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            assertEquals(((i+2)/(i+1)) / ((i+1)/i), seq.next(), 
                    TestingUtils.EPSILON);
        }
        
        assertEquals("ratio(ratio(n))", seq.toString());
    }
    
    /**
     * Tests the ratio() function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFactoryRatio6() {
        String seqStr = "ratio(ratio(n))^2";
        Sequence seq = SequenceFactory.sequenceFromString(seqStr);
        for(double i = 0; i < 100; i++) {
            double val = ((i+2)/(i+1)) / ((i+1)/i);
            val *= val;
            assertEquals(val, seq.next(), TestingUtils.EPSILON);
        }
    }
}
