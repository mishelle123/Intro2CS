public class SequenceFactoryToText {
    public static void main (String[] args) {
        java.util.Scanner scan = new java.util.Scanner(System.in);
        
        while(scan.hasNext()) {
            System.out.println(SequenceFactory.sequenceFromString(scan.nextLine()));
        }
    }
}
