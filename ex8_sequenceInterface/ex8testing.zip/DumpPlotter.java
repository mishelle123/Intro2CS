import il.ac.huji.cs.intro.ex8.SequencePlotter;
import il.ac.huji.cs.intro.ex8.MockPlotter;

public class DumpPlotter {

    private static final String USAGE_STRING = 
        "Usage: DumpPlotter <inputFile> <outputFile>";    

    public static void main(String[] args) {
        if(args.length != 2) {
            System.out.println(USAGE_STRING);
            return;
        }
        String input = args[0];
        String output = args[1];

        SequencePlotter.startTestMode();
        SequenceViewer.main(new String[]{input});
        MockPlotter plotter = (MockPlotter)SequencePlotter.getPlotter();
        plotter.dump(output);
    }
}
