import static org.junit.Assert.*;
import il.ac.huji.cs.intro.ex8.Sequence;

import org.junit.runner.RunWith;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.Test;

/**
 * Tests for the sum sequence.
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class CumulativeSumSequenceTester {

    private static final String FUNCTION_NAME = "cumulativeSum";

    private static final double[] EMPTY = new double[0];

    private static int checkSubsequence(Sequence seq, double[] expected) {
        return checkSubsequence(seq, expected, 0);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start) {
        return checkSubsequence(seq, expected, start, expected.length-start);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start, int length) {
        TestingUtils.compareSequenceWithArray(seq, expected, true, start, start+length);
        return start+length;
    }

    private static Sequence getTestedSequence(Sequence seq) {
        return new CumulativeSumSequence(seq);
    }
    
    private static String buildString(String str) {
        return FUNCTION_NAME+"("+str+")";
    }

    private static void checkToString(String str) {
        Sequence seq = getSequence(EMPTY, str);
        assertEquals(buildString(str), getTestedSequence(seq).toString());
    }

    private static TestingUtils.MockSequence getSequence(double[] source) {
        return getSequence(source, null, false);
    }

    private static TestingUtils.MockSequence getSequence(double[] source, boolean loop) {
        return getSequence(source, null, loop);
    }

    private static TestingUtils.MockSequence getSequence(double[] source, String str) {
        return getSequence(source, str, false);
    }


    private static TestingUtils.MockSequence getSequence(double[] source, String str, boolean loop) {
        return source==null ? null : new TestingUtils.MockSequence(source, str, loop);
    }

    private static void expectSequence(double[] source) {
        expectSequence(source, false, Integer.MAX_VALUE);
    }
    
    private static void expectSequence(double[] source, boolean loop) {
        expectSequence(source, loop, Integer.MAX_VALUE);
    }
    
    /**
     * Expects the finite sequence to be the addition sequence of the two arrays.
     */
    private static void expectSequence(double[] source, boolean loop, int length) {
        expectSequence(source, loop, 0, length);
    }
    private static void expectSequence(double[] source, boolean loop, int offset, boolean extra) {
        expectSequence(source, loop, offset, Integer.MAX_VALUE);
    }

    private static void expectSequence(double[] source, boolean loop, 
                                       int offset, int length) {
        Sequence innerSeq = getSequence(source,loop);
        for(int i=0; i<offset;i++) {
            innerSeq.next();
        }
        Sequence seq = getTestedSequence(innerSeq);
        source = loop ? TestingUtils.shiftArray(source, offset) : TestingUtils.offsetArray(source, offset);

        double[] expected = getExpectedSequences(source, loop, length);
        boolean expectMore = source!=null && source.length>0 && (source.length>length || loop);
        TestingUtils.compareSequenceWithArray(seq, expected, expectMore);
    }
    
    private static double[] getExpectedSequences(double[] source, boolean loop, int length) {
        if(source == null || length < 0) {
            length = 0;
        }
        else {
            length = ( (source.length < length && !loop) ? source.length : length);
        }
        double[] expected = new double[length];
        double sum=0;
        for(int i=0; i<length; i++) {
            sum += source[i % source.length];
            expected[i] = sum;
        }
        return expected;
    }


    /**
     * Basic sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceBasic1() {
        double[] source = new double[] {1, 2.4, 3};
        expectSequence(source);
    }
    
    /**
     * Basic sequence addition test.
     * Advances some indices in the source sequences before checking 
     * the addition.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceBasic2() {
        double[] source = new double[] {317, 1, 2, 3};
        expectSequence(source, false, 1);
    }

    /**
     * Basic sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceBasic3() {
        double[] source = new double[] {7.7, 4, 8};
        expectSequence(source);
    }
    
    /**
     * Basic sequence addition test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceEmpty() {
        double[] source = new double[] {};
        expectSequence(source);
    }

    /**
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceLength1() {
        double[] source = new double[] {1};
        expectSequence(source);
    }

    /**
     * Test null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceNull1() {
        double[] source = null;
        expectSequence(source);
    }
    
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToString() {
        checkToString("f");
        checkToString("ffff");
        checkToString("fgfg");
        checkToString("1234");
        checkToString("ff,ff");
        checkToString("fg(f,g)");
    }
    
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToStringNull() {
        checkToString(null);
        checkToString(null);
    }
    
    /**
     * Basic sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite1() {
        double[] source = new double[] {1, 2.4, 3};
        expectSequence(source, true, 30);
    }
    
    /**
     * Basic sequence addition test.
     * Advances some indices in the source sequences before checking 
     * the addition.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite2() {
        double[] source = new double[] {317, 1, 2, 3};
        expectSequence(source, true, 1, 30);
    }

    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite3() {
        double[] source = new double[] {1, 2, 3};
        expectSequence(source, true, 30);
    }
    
    /**
     * Basic sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite4() {
        double[] source = new double[] {7.7, 4, 8};
        expectSequence(source, true, 30);
    }
    
    /**
     * Basic sequence addition test.
     * Advances some indices in the source sequences before checking 
     * the addition.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite5() {
        double[] source = new double[] {5.235, 456735.555, 7, 4};
        expectSequence(source, true, 2, 30);
    }

    /**
     * Tests two sources of different size.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceInfinite6() {
        double[] source = new double[] {7, 4};
        expectSequence(source, true, 30);
    }
    





    /**
     * Basic sum sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceBasic4() {
        double[] source = new double[] {1, 2, 3, -4, 7, -14};
        expectSequence(source);
    }
    
    /**
     * Basic sum sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testSequenceBasic5() {
        double[] source =   new double[] { Math.PI, Math.PI, (1.0/Math.PI) };
        expectSequence(source);
    }
    
    
    /**
     * Tests independence of separate sequences.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testIndependence1() {
        double[] source1 = new double[] {1, 2, 3, 4, 5};

        double[] source2 = new double[] {1, 2, 3, 4};

        double[] expected1 = getExpectedSequences(source1,true,1000);
        double[] expected2 = getExpectedSequences(source2,true,1000);

        Sequence innerSeq1 = getSequence(source1,true);
        Sequence innerSeq2 = getSequence(source2,true);

        Sequence seq1 = getTestedSequence(innerSeq1);
        Sequence seq2 = getTestedSequence(innerSeq2);

        int start1=0;
        int start2=0;
        start1 = checkSubsequence(seq1, expected1, start1, 1);
        start2 = checkSubsequence(seq2, expected2, start2, 1);
        for(int i=0;i<7;i++) {
            start1 = checkSubsequence(seq1, expected1, start1, start2);
            start2 = checkSubsequence(seq2, expected2, start2, start1);
        }
        start1 = checkSubsequence(seq1, expected1, start1);
        start2 = checkSubsequence(seq2, expected2, start2);
    }
  
    /**
     * Basic sum sequence test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testFakeIdentitySequence() {
        double[] source =   new double[] { 1 };
        expectSequence(source, true, 100);
    }
}
