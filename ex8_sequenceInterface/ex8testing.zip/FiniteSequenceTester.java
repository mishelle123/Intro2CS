import static org.junit.Assert.assertEquals;
import il.ac.huji.cs.intro.ex8.Sequence;

import org.junit.runner.RunWith;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.Test;

import java.util.Arrays;

/**
 * Tests the FiniteSequence class.
 * 
 * @author intro2cs team
 *
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class FiniteSequenceTester {
    
    private static final String FUNCTION_NAME = "finiteSequence";

    private static void checkToString(double[] source) {
        String arrString = source==null ? "" : Arrays.toString(source).replaceAll("[ \\[\\]]","");
        assertEquals(FUNCTION_NAME+"("+arrString+")",
                     new FiniteSequence(source).toString());
    }

    private static final double[] EMPTY = new double[0];
  
    private static int checkSubsequence(Sequence seq, double[] expected) {
        return checkSubsequence(seq, expected, 0);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start) {
        return checkSubsequence(seq, expected, start, expected.length-start);
    }

    private static int checkSubsequence(Sequence seq, double[] expected, int start, int length) {
        TestingUtils.compareSequenceWithArray(seq, expected, true, start, start+length);
        return start+length;
    }

    private static void expectSequence(double[] source) {
        expectSequence(source, false);
    }

    private static void expectSequence(double[] source, boolean modify) {
        double[] copy = (source == null) ? null : Arrays.copyOf(source,source.length);
        Sequence seq = new FiniteSequence(copy);
        if(modify) {
            for(int i=0; i<copy.length;i++) copy[i]=Double.NaN;
        }
        TestingUtils.compareSequenceWithArray(seq, source==null ? EMPTY : source);
    }

    /**
     * Basic functionality test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBasicFiniteSequenceSimple1() {
        double[] source = { 4 };
        expectSequence(source);
    }
    
    /**
     * Basic functionality test.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBasicFiniteSequenceSimple2() {
        double[] source = { 1, 0, 2, 3, 7, -12.15 };
        expectSequence(source);
    }
    
    /**
     * Tests an empty sequence.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBasicFiniteSequenceEmpty() {
        double[] source = { };
        expectSequence(source);
    }
    
    /**
     * Tests an empty sequence - null input.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBasicFiniteSequenceNull() {
        double[] source = null;
        expectSequence(source);
    }

    /**
     * toString sequence tests.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToString1() {
        checkToString(new double[]{ 4 });
        checkToString(new double[]{ 1, 0, 2, 3, 7, -12.15 });
    }

    /**
     * toString sequence tests.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testToString2() {
        checkToString(new double[]{  });
        checkToString(null);
    }

    
    /**
     * Tests that the sequence does not point at the source array.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-10)
    public void testBasicFiniteSequenceChangeArrayFromOutside() {
        double[] source = { 2, 4, 8, 16, 32, 64 };
        expectSequence(source,true);
    }

}
