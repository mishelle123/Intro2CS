import org.junit.Test;
import org.junit.After;
import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.util.InterruptibleOutputStream;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

/**
 * Tester for Ex2a
 * @author Intro2cs Team
 *
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class Ex2bTester {

	/**
	 * Original System.out
	 */
        private static final java.io.PrintStream sysout=System.out;
	/**
	 * Original System.in
	 */
        private static final java.io.InputStream sysin=System.in;

	/**
	 * A cross-platform new line.
	 */
	private static final String NEWLINE = String.format("%n");

	/**
	 * Builds the expected output given the coefficients 
	 * (not including the result of the calculation).
	 * 
	 * @param a the coefficient for x^2.
	 * @param b the coefficient for x.
	 * @param c the constant.
	 * @return the expected output (not including the result of 
	 * the calculation).
	 */
	private static String buildCommonOutput(double a, double b, double c) {
		return "This program solves a quadratic equation."+NEWLINE+
		"Enter the coefficients a b c: "+
		String.format("Equation: %.2f*x^2 + %.2f*x + %.2f = 0%n", a, b, c);
	}

	/**
	 * Builds the expected result line.
	 * 
	 * @param sols the number of solutions.
	 * @param x1 the first solution.
	 * @param x2 the second solution.
	 * @return the expected solution.
	 */
	private static String buildSolutionOutput(int sols, double x1, double x2) {
		switch (sols) {
			case 0: return "There are no real solutions."+NEWLINE;
			case 1: return String.format(
					"There is one real solution: %.2f.%n", x1);
			case 2: return String.format(
					"There are two real solutions: %.2f, %.2f.%n", x1,x2);
			default: return "All real numbers are solutions."+NEWLINE;
		}
	}

	/**
	 * Runs Ex2b with inputs and outputs, and compares Ex2b output 
	 * to the expected output.
	 * 
	 * @param input the user's input.
	 * @param a the coefficient for x^2.
	 * @param b the coefficient for x.
	 * @param c the constant.
	 * @param sols the number of solutions.
	 * @param x1 the first solution.
	 * @param x2 the second solution.
	 * @throws InterruptedException
	 */
	private static void commonTest(String input,
			double a,double b,double c,
			int sols,double x1,double x2)
	throws InterruptedException {

		ByteArrayOutputStream baosOut = new ByteArrayOutputStream();
		System.setOut(new PrintStream(new InterruptibleOutputStream(baosOut)));
		System.setIn(new ByteArrayInputStream(input.getBytes()));
		Ex2b.main(new String[0]);
		String output=baosOut.toString();
		assertEquals("Wrong output for input "+input+".",
				buildCommonOutput(a,b,c)+buildSolutionOutput(sols,x1,x2),
				output);
	}

	/**
	 * Tests when all solutions are possible.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-4)
	@Test(timeout=1000) public void testAllSolutions() 
	throws InterruptedException {
		commonTest("0 0 0",0,0,0,-1,0,0);
		commonTest("0.00 -0 0",0,-0.0,0,-1,0,0);
		commonTest("0.00 -0 -0",0.0,-0.0,-0.0,-1,0,0);
	}

	/**
	 * Tests no real solutions, a>0.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-4)
	@Test(timeout=1000) public void testNonlinearNoSolutions() 
	throws InterruptedException {
		commonTest("1 2 3",1,2,3,0,0,0);
		commonTest("1.0 2.0 3.0",1,2,3,0,0,0);
		commonTest("1 1 1",1,1,1,0,0,0);
		commonTest("-1 -1 -3",-1,-1,-3,0,0,0);
		commonTest("-1 1.5 -3",-1,1.5,-3,0,0,0);
		commonTest("-0.25 0 -1",-0.25,0,-1,0,0,0);
	}

	/**
	 * Tests when no solutions, a=0.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-4)
	@Test(timeout=1000) public void testLinearNoSolutions() 
	throws InterruptedException {
		commonTest("0 0 3",0,0,3,0,0,0);
		commonTest("0.0 0.0 -3.5",0,0,-3.5,0,0,0);
	}

	/**
	 * Tests when there is one solution, a>0.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-4)
	@Test(timeout=1000) public void testNonlinearOneSolution() 
	throws InterruptedException {
		commonTest("1 2 1",1,2,1,1,-1,0);
		commonTest("1 -2 1",1,-2,1,1,1,0);
		commonTest("-1 2 -1",-1,2,-1,1,1,0);
		commonTest("2 -10.0 12.5",2,-10,12.5,1,2.5,0);
		commonTest("0.25 0 0",0.25,0,0,1,0,0);
	}

	/**
	 * Tests when there is one solution, a=0.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-4)
	@Test(timeout=1000) public void testLinearOneSolution() 
	throws InterruptedException {
		commonTest("0 1 2",0,1,2,1,-2,0);
		commonTest("0.0 -2.0 1.5",0,-2,1.5,1,0.75,0);
		commonTest("0 5 0",0,5,0,1,0,0);
	}

	/**
	 * Tests when there are two solutions 1.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-4)
	@Test(timeout=1000) public void testTwoSolutions1() 
	throws InterruptedException {
		commonTest("1 3 2",1,3,2,2,-2,-1);
		commonTest("8.0 0.0 -4.0",8,0,-4,2,-0.71,0.71);
	}

	/**
	 * Tests when there are two solutions 2.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-4)
	@Test(timeout=1000) public void testTwoSolutions2() 
	throws InterruptedException {
		commonTest("1 -3 0",1,-3,0,2,0,3);
		commonTest("5 -4 0",5,-4,0,2,0,0.8);
		commonTest("5.0 4.0 0.0",5,4,0,2,-0.8,0);
		commonTest("4.0 -4.0 0.0",4,-4,0,2,0,1);
		commonTest("4.0 4.0 0.0",4,4,0,2,-1,0);
	}

	/**
	 * Resets System.out and System.in back to default.
	 */
	@After public void reset() {
		System.setOut(sysout);
		System.setIn(sysin);
	}
}


