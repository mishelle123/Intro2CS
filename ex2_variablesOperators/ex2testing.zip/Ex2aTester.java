import org.junit.Test;
import org.junit.After;
import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.util.InterruptibleOutputStream;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;


/**
 * Tester for Ex2a
 * @author Intro2cs Team
 *
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class Ex2aTester {

	/**
	 * Original System.out
	 */
        private static final java.io.PrintStream sysout=System.out;
	/**
	 * Original System.in
	 */
        private static final java.io.InputStream sysin=System.in;

	/**
	 * A cross-platform new line.
	 */
	private static final String NEWLINE = String.format("%n");
	
	/**
	 * Builds the expected ouput given the minimum and maximum
	 * heart rate.
	 * 
	 * @param exMin the minimum heart rate.
	 * @param exMax the maximum heart rate.
	 * @return the expected ouput.
	 */
	private static String buildOutput(int exMin,int exMax) {
		return 
		"This program calculates your target heart rate while exercising."
		+NEWLINE+"Enter your age: "+
		"Your estimated target heart rate zone is " + exMin +
		" - " + exMax + " beats per minute."+NEWLINE;
	}

	/**
	 * Runs Ex2a with inputs and outputs, and compares Ex2a output 
	 * to the expected output.
	 * 
	 * @param age the user's age.
	 * @param exMin the minimum heart rate based on age.
	 * @param exMax the maximum heart rate based on age.
	 * @throws InterruptedException
	 */
	private static void commonTest(int age,int exMin,int exMax) 
	throws InterruptedException {

		ByteArrayOutputStream baosOut = new ByteArrayOutputStream();
		System.setOut(new PrintStream(new InterruptibleOutputStream(baosOut)));
		System.setIn(
				new ByteArrayInputStream(Integer.toString(age).getBytes()));
		Ex2a.main(new String[0]);
		String output=baosOut.toString();
		assertEquals("Wrong output for input "+age+".",
				buildOutput(exMin,exMax),
				output);
	}

	/**
	 * Tests Ex2a with age = 17.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testEx2aInputIs17() 
	throws InterruptedException {

		commonTest(17,132,173);
	}

	/**
	 * Tests Ex2a with age = 20.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testEx2aInputIs20() 
	throws InterruptedException {

		commonTest(20,130,170);
	}

	/**
	 * Tests Ex2a with age = 100.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testEx2aInputIs100() 
	throws InterruptedException {

		commonTest(100,78,102);
	}

	/**
	 * Tests Ex2a with age = 0.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testEx2aInputIs0() 
	throws InterruptedException {

		commonTest(0,143,187);
	}
	
	/**
	 * Resets System.out and System.in back to default.
	 */
	@After public void reset() {
		System.setOut(sysout);
		System.setIn(sysin);
	}

}


