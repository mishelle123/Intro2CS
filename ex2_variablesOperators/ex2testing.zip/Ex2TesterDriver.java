import org.junit.runner.Result;

import org.junit.runner.JUnitCore;
import il.ac.huji.cs.intro.junit.internal.IntroListener;

/**
 * Driver for Ex2 testers
 * 
 * @author Intro2cs Team
 *
 */
public class Ex2TesterDriver {

	/**
	 * Runs the three testers
	 * @param args not used
	 */
	public static void main(String[] args) {
		JUnitCore junit = new JUnitCore();
		junit.addListener(new IntroListener(System.out));
		Result res=junit.run(Ex2aTester.class,
				Ex2bTester.class,
				Ex2cTester.class
		);
		System.exit(res.wasSuccessful() ? 0 : 1);
	}

}
