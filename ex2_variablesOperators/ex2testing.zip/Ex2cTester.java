import org.junit.Test;
import org.junit.After;
import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.util.InterruptibleOutputStream;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

/**
 * Tester for Ex2c
 * 
 * @author Intro2cs Team
 *
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class Ex2cTester {

	/**
	 * Original System.out
	 */
        private static final java.io.PrintStream sysout=System.out;
	/**
	 * Original System.in
	 */
        private static final java.io.InputStream sysin=System.in;

	/**
	 * A cross-platform new line.
	 */
	private static final String NEWLINE = String.format("%n");

	/**
	 * Enter sentence line.
	 */
	private static final String START="Please enter a sentence:" + NEWLINE;
	
	/**
	 * Menu.
	 */
	private static final String MENU=
		"1) Number of characters" + NEWLINE +
		"2) Remove vowels" + NEWLINE +
		"3) Replace a string" + NEWLINE +
		"4) First and last word" + NEWLINE +
		"5) Remove following characters" + NEWLINE +
		"6) Middle characters" + NEWLINE +
		"7) Convert to upper/lower case" + NEWLINE +
		"Choose option to execute:"+ NEWLINE;
	
	/**
	 * Result line.
	 */
	private static final String RESULT="The result is: ";

	/**
	 * Different inputs to test.
	 */
	private static final String[] INPUTS={
		"To be or not to be",
		"Twas brillig and the slithy toves Did gyre and gimble " +
		"in the wabe All mimsy were the borogoves And the mome raths outgrabe",
		"Ash nazg durbatuluk ash nazg gimbatul Ash nazg thrakatuluk " +
		"agh burzum ishi krimpatul",
		"Honorificabilitudinitatibus",
		"a e",
		"x",
		"be or not to be",
		"a a",
		"asd fGhjk"
	};

	/**
	 * Builds the expected output by combining the start line, menu,
	 * output lines depending on user's choice and the result.

	 * @param specificLines output lines that are added depending 
	 * on user's choice.
	 * @param result the result line.
	 * @return the expected output.
	 */
	private static String buildOutput(String specificLines, String result) {
		return START + MENU + specificLines + RESULT + result + NEWLINE;
	}

	/**
	 * Runs Ex2c with inputs and outputs, and compares Ex2c output 
	 * to the expected output.
	 *
	 * @param input the user's input sentence and the menu choice.
	 * @param specificLines output lines that are added depending 
	 * on user's choice.
	 * @param result the result line.
	 * @throws InterruptedException
	 */
	private static void commonTest(String input,
			String specificLines,
			String result)
	throws InterruptedException {

		ByteArrayOutputStream baosOut = new ByteArrayOutputStream();
		System.setOut(new PrintStream(new InterruptibleOutputStream(baosOut)));
		System.setIn(new ByteArrayInputStream(input.getBytes()));
		Ex2c.main(new String[0]);
		String output=baosOut.toString().
                    replaceAll("Remove first and last words","First and last word");
		assertEquals("Wrong output for input "+input+".",
				buildOutput(specificLines,result),
				output);
	}

	/**
	 * Tests option 1.
	 * 
	 * @param input the index of the input sentence.
	 * @param output the expected result output.
	 * @throws InterruptedException
	 */
	private static void tNumChars(int input,int output) 
	throws InterruptedException {
		commonTest(INPUTS[input]+NEWLINE+"1"+NEWLINE,"",
				Integer.toString(output)); 
	}

	/**
	 * Tests option 1.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testNumOfChars()
	throws InterruptedException {
		tNumChars(0,18);
		tNumChars(1,122);
		tNumChars(2,84);
		tNumChars(5,1);
	}

	/**
	 * Tests option 2.
	 * 
	 * @param input the index of the input sentence.
	 * @param output the expected result output.
	 * @throws InterruptedException
	 */
	private static void tRemoveVowels(int input, String output) 
	throws InterruptedException {
		commonTest(INPUTS[input]+NEWLINE+"2"+NEWLINE,"",output);
	}

	/**
	 * Tests option 2.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testRemoveVowels()
	throws InterruptedException {
		tRemoveVowels(0,"T b r nt t b");
		tRemoveVowels(1,"Tws brllg nd th slthy tvs Dd gyr nd gmbl " +
				"n th wb All mmsy wr th brgvs And th mm rths tgrb");
		tRemoveVowels(2,"Ash nzg drbtlk sh nzg gmbtl Ash nzg " +
				"thrktlk gh brzm sh krmptl");
		tRemoveVowels(4," ");
	}

	/**
	 * Tests option 3.
	 * 
	 * @param input the index of the input sentence.
	 * @param oldString the string to replace.
	 * @param newString the new string to replace old string.
	 * @param output the expected result output.
	 * @throws InterruptedException
	 */
	private static void tReplaceString(int input,String oldString,
			String newString, String output) throws InterruptedException {
		commonTest(INPUTS[input]+NEWLINE+"3"+NEWLINE+oldString+
				NEWLINE+newString+NEWLINE,
				"String to replace:"+NEWLINE+"New string:"+NEWLINE,
				output);
	}

	/**
	 * Tests option 3.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testReplaceString()
	throws InterruptedException {
		tReplaceString(0,"be","me","To me or not to me");
		tReplaceString(2,"be","me","Ash nazg durbatuluk ash nazg " +
				"gimbatul Ash nazg thrakatuluk agh burzum ishi krimpatul");
		tReplaceString(5,"x","z","z");
	}

	/**
	 * Tests option 4.
	 * 
	 * @param input the index of the input sentence.
	 * @param output the expected result output.
	 * @throws InterruptedException
	 */
	private static void tFirstLastWord(int input, String output) 
	throws InterruptedException {
		commonTest(INPUTS[input]+NEWLINE+"4"+NEWLINE,"",output);
	}

	/**
	 * Tests option 4.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testFirstLastWord()
	throws InterruptedException {
		tFirstLastWord(0,"To be or not to be");
		tFirstLastWord(1,"Twas brillig and the slithy toves Did gyre " +
				"and gimble in the wabe All mimsy were the borogoves And the mome raths outgrabe");
		tFirstLastWord(2,"Ash nazg durbatuluk ash nazg gimbatul Ash " +
				"nazg thrakatuluk agh burzum ishi krimpatul");
		tFirstLastWord(4,"a e");
		tFirstLastWord(5,"");
		tFirstLastWord(6,"or not to");
		tFirstLastWord(7,"");
	}

	/**
	 * Tests option 5.
	 * 
	 * @param input the index of the input sentence.
	 * @param choice the input word to remove its following characters.
	 * @param output the expected result output.
	 * @throws InterruptedException
	 */
	private static void tRemoveFollowingChars(int input,String choice, 
			String output) throws InterruptedException {
		commonTest(INPUTS[input]+NEWLINE+"5"+NEWLINE+choice+NEWLINE,
				"Enter a string:"+NEWLINE,output);
	}

	/**
	 * Tests option 5.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testRemoveFollowingChars()
	throws InterruptedException {
		tRemoveFollowingChars(0,"be","To ber not to be");
		tRemoveFollowingChars(0,"Be","To be or not to be");
		tRemoveFollowingChars(1,"outgrabe","Twas brillig and the slithy " +
				"toves Did gyre and gimble in the wabe All mimsy were " +
				"the borogoves And the mome raths outgrabe");
		tRemoveFollowingChars(2,"ABCDEFGHI","Ash nazg durbatuluk ash nazg " +
				"gimbatul Ash nazg thrakatuluk agh burzum ishi krimpatul");
		tRemoveFollowingChars(3,"dinitati","Honorificabilitudinitati");
	}

	/**
	 * Tests option 5.
	 * 
	 * @param input the index of the input sentence.
	 * @param output the expected result output.
	 * @throws InterruptedException
	 */
	private static void tMiddleChars(int input, String output) 
	throws InterruptedException {
		commonTest(INPUTS[input]+NEWLINE+"6"+NEWLINE,"",output);
	}

	/**
	 * Tests option 6.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testMiddleChars()
	throws InterruptedException {
		tMiddleChars(0,"rno");
		tMiddleChars(1,"wa");
		tMiddleChars(2,"na");
		tMiddleChars(3,"lit");
		tMiddleChars(4,"ae");
		tMiddleChars(5,"x");
	}

	/**
	 * Tests option 7. 
	 * 
	 * @param input the index of the input sentence.
	 * @param output the expected result output.
	 * @throws InterruptedException
	 */
	private static void tConvertUpperLower(int input, String output) 
	throws InterruptedException {
		commonTest(INPUTS[input]+NEWLINE+"7"+NEWLINE,"",output);
	}

	/**
	 * Tests option 7.
	 * 
	 * @throws InterruptedException
	 */
	@TestPenalty(penalty=-6)
	@Test(timeout=1000) public void testConvertUpperLower()
	throws InterruptedException {
		tConvertUpperLower(0,"to be or not to be");
		tConvertUpperLower(1,"twas brillig and the slithy toves did gyre " +
				"and gimble in the wabe all mimsy were the borogoves and " +
				"the mome raths outgrabe");
		tConvertUpperLower(2,"ash nazg durbatuluk ash nazg gimbatul ash " +
				"nazg thrakatuluk agh burzum ishi krimpatul");
		tConvertUpperLower(3,"honorificabilitudinitatibus");
		tConvertUpperLower(4,"A E");
		tConvertUpperLower(5,"X");
		tConvertUpperLower(6,"BE OR NOT TO BE");
		tConvertUpperLower(7,"A A");
		tConvertUpperLower(8,"asd fghjk");
	}

	/**
	 * Resets System.out and System.in back to default.
	 */
	@After public void reset() {
		System.setOut(sysout);
		System.setIn(sysin);
	}

}
