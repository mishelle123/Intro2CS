package il.ac.huji.cs.intro.mastermind;

import org.easymock.EasyMock;
import static org.easymock.EasyMock.*;

/**
 * Recorder for Mastermind sessions.
 * @author Intro2cs Team
 */
public class MastermindRecorder {

    private final MastermindUI mastermindUI;
    private final CodeGenerator generator;

    /**
     * Creates a new recorder.
     */
    public MastermindRecorder() {
	mastermindUI=createStrictMock(MastermindUI.class);
	generator=new CodeGenerator();
    }

    /**
     * starts replay mode.
     * Obviously not thread-safe from this point.
     */
    public void replay() {
	EasyMock.replay(mastermindUI);
	MastermindUIFactory.setMastermindUI(mastermindUI);
	generator.setDefaultGenerator();
    }

    /**
     * verifies replay.
     */
    public void verify() {
	EasyMock.verify(mastermindUI);
    }

    /**
     * Records a single mastermind game.
     * @param game the game to record.
     */
    private int recordGame(Game game) {
	int length=game.turns[0].guess.getLength();
	generator.offerCode(game.code);
	Turn[] turns=game.turns;
	for(int i=0 ; i < turns.length ; i++) {
	    expect(mastermindUI.askGuess(anyObject(String.class),eq(length))).andReturn(turns[i].guess);
	    mastermindUI.showGuessResult(turns[i].guess,turns[i].bulls,turns[i].cows); expectLastCall();
	}
	return turns[turns.length-1].bulls == length  ?  turns.length  :  0;
    }

    /**
     * Records a series of games.
     * @param series the game series to record.
     * @param last is this the last series in the session.
     */
    private void recordSeries(Series series,
			      boolean last) {
	int[] options=series.options;
	int length=0;
	int vals=0;
	int turns=0;
	int index=0;
	while(length<=0) {
	    length=options[index++];
	    expect(mastermindUI.askNumber(matches(".*[lL]ength.*"))).andReturn(length);
	    if(length<=0)
		{ mastermindUI.displayErrorMessage(anyObject(String.class)); expectLastCall(); }
	}

	while(vals<=0) {
	    vals=options[index++];
	    expect(mastermindUI.askNumber(anyObject(String.class))).andReturn(vals);
	    if(vals<=0)
		{ mastermindUI.displayErrorMessage(anyObject(String.class)); expectLastCall(); }
	}

	while(turns<=0) {
	    turns=options[index++];
	    expect(mastermindUI.askNumber(anyObject(String.class))).andReturn(turns);
	    if(turns<=0)
		{ mastermindUI.displayErrorMessage(anyObject(String.class)); expectLastCall(); }
	}

	mastermindUI.reset(length,vals,turns); expectLastCall();
	int wins=0;
	int turnsTotal=0;
	for(int i=0;i<series.games.length;i++) {
	    int res=recordGame(series.games[i]);
	    if(res>0) { wins++; turnsTotal+=res; }
	    mastermindUI.displayMessage(matches(".*"+(res>0 ? "[Ww]on.* "+res : "[Ll]ost")+".*")); expectLastCall();
	    mastermindUI.showStats(i+1,wins,wins/(double)(i+1),turnsTotal/(double)wins); expectLastCall();
	    expect(mastermindUI.askYesNo(anyObject(String.class))).andReturn(i<series.games.length-1 || !last);  // Another game?
	    if(i<series.games.length-1 || !last) {
		expect(mastermindUI.askYesNo(anyObject(String.class))).andReturn(i==series.games.length-1);  // Change options?
	    }
	    if(i<series.games.length-1) {
		mastermindUI.clear(); expectLastCall(); 
	    }
	}
    }
    
    /**
     * Records a complete mastermind session.
     * @param series the list of game series in this session.
     */
    public void recordSession(Series[] series) {
	for(int i=0;i<series.length;i++) {
	    recordSeries(series[i],
			 i==series.length-1);
	}
	mastermindUI.close(); expectLastCall();
    }

    /**
     * A mastermind turn.
     */
    public static class Turn {

	private Code guess;
	private int bulls;
	private int cows;

	private Turn(Code guess,int bulls,int cows) {
	    this.guess=guess;
	    this.bulls=bulls;
	    this.cows=cows;
	}
    }

    /**
     * A mastermind game.
     */
    public static class Game {
	private Code code;
	private Turn[] turns;

	private Game(Code code,Turn[] turns) {
	    this.code=code;
	    this.turns=turns;
	}

    }

    /**
     * A mastermind game series.
     */
    public static class Series {
	
	private int[] options;
	private Game[] games;
	
	private Series(int[] options,Game[] games) {
	    this.options=options;
	    this.games=games;
	}
    }

    /**
     * Creates arbitrary game turn.
     * @param guess the guess for this turn as an array.
     * @param bulls the bulls response for this turn.
     * @param cows the cows response for this turn.
     * @return the turn specified.
     */
    public static Turn createTurn(int[] guess,int bulls,int cows) {
	return new Turn(new Code(guess),bulls,cows);
    }

    /**
     * Creates a game where the player wins in one move.
     * @param code the code as represented by an array.
     * @return the game specified.
     */
    public static Game oneMoveWin(int[] code) {
	return new Game(new Code(code),
			new Turn[]{new Turn(new Code(code),code.length,0)});
    }

    /**
     * Creates a game where the player wins in two move.
     * @param code the code as represented by an array.
     * @param guess the wrong guess as represented by an array.
     * @param bulls the bulls response for wrong answer.
     * @param cows the cows response for wrong answer.
     * @return the game specified.
     */
    public static Game twoMoveWin(int[] code,int[] guess,int bulls,int cows) {
	return new Game(new Code(code),
			new Turn[]{
			    new Turn(new Code(guess),bulls,cows),
			    new Turn(new Code(code),code.length,0)});
    }
    
    /**
     * Creates a game where the player wins in several moves.
     * @param code the code as represented by an array.
     * @param guess the wrong guesses as represented by an array.
     * @param bulls the bulls response for wrong answer.
     * @param cows the cows response for wrong answer.
     * @param numTurns the number of turns in the game.
     * @param win did the user win the game?
     * @return the game specified.
     */
    public static Game multimoveGame(int[] code,int[] guess,int bulls,int cows, int numTurns, boolean win) {
	Turn[] turns=new Turn[numTurns];
	for(int i=0;i<turns.length-1;i++)
	    turns[i]=new Turn(new Code(guess),bulls,cows);
	turns[turns.length-1]=win ? new Turn(new Code(code),code.length,0) : new Turn(new Code(guess),bulls,cows);
	return new Game(new Code(code),
			turns);
    }

    /**
     * Creates a game with an arbitrary turn order.
     * @param code the code for this game as an array.
     * @param turns the turns of this game.
     * @return the game specified.
     */
    public static Game createGame(int[] code,Turn[] turns) {
	return new Game(new Code(code),turns);
    }

    /**
     * Creates a game series with alternating codes.
     * @param options the game options for this series.
     * @param code1 the first code used in series.
     * @param code2 the second code used in series.
     * @param bulls the bulls response for wrong answers.
     * @param cows the cows response for wrong answers.
     * @param maxTurns the maximum number of turns in a game in this series.
     * @param turns the number of turns it took the player to win  each game, 0 for a loss.
     * @return the series specified.
     */
    public static Series createSeries(int[] options, int[] code1,int[] code2,int bulls,int cows, int maxTurns, int[] turns) {
	int[][] codes=new int[][] {code1,code2};
	Game[] games=new Game[turns.length];
	for(int i=0;i<turns.length;i++)
	    games[i]=multimoveGame(codes[i%2],codes[1-i%2],bulls,cows,turns[i]==0?maxTurns:turns[i],turns[i]>0);
	return new Series(options,games);
    }

    /**
     * Creates a game series with an arbitrary game sequence.
     * @param options the game options for this series.
     * @param games the gamesin this sequence.
     * @return the series specified.
     */
    public static Series createSeries(int[] options, Game[] games) {
	return new Series(options,games);
    }




}
