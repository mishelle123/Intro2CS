import il.ac.huji.cs.intro.mastermind.*;
import static il.ac.huji.cs.intro.mastermind.MastermindRecorder.*;

import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

/**
 * Tester for Ex3 - Mastermind.
 * @author Intro2cs Team
 */
@RunWith(IntroJUnit4ClassRunner.class) 
public class MastermindTester  {

    private MastermindRecorder recorder;

    @Before
    public void setUp() {
	recorder=new MastermindRecorder();
    }

    private void run() {
	recorder.replay();
	Mastermind.main(null);
	recorder.verify();
    }


    /** win in one turn */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurn1234() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }
    /** win in one turn - repeated val in code */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurn0305() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{0,3,0,5}) }) });
	run();
    }
    /** win in one turn - single val in code */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurn2222() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{2,2,2,2}) }) });
	run();
    }
    /** win in one turn - out of 1 max */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurn1234_1t() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,1},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }
    /** win in one turn - large vals */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurnLargeVals() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,20,15},
			     new Game[] { 
				 oneMoveWin(new int[]{11,12,13,14}) }) });
	run();
    }
    /** win in one turn - large vals */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurnSmallVals() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,1,15},
			     new Game[] { 
				 oneMoveWin(new int[]{0,0,0,0}) }) });
	run();
    }
    /** win in one turn - long code */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurnLongCode() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {10,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4,0,5,0,5,0,5})  }) });
	run();
    }
    /** win in one turn - short code */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameOneTurnShortCode() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {1,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1}) }) });
	run();
    }
    /** win in one turn - illegal input code length */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalLength1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {0,4,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }

    /** win in one turn - illegal input code vals */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalVals1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,0,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }

    /** win in one turn - illegal input max turns */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalTurns1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,0,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }
    /** win in one turn - illegal input code length */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalLength2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {-1,4,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }

    /** win in one turn - illegal input code length */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalVals2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,-1,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }

    /** win in one turn - illegal input max turns */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalTurns2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,-1,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }

    /** win in one turn - illegal input code length */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalLength3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {-1,-2,4,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }

    /** win in one turn - illegal input vals */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalVals3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,-1,-2,6,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }

    /** win in one turn - illegal input max turns */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalTurns3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,-1,-2,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }


    /** win in one turn - illegal input - all */
    @Test(timeout=1000) @TestPenalty(penalty=-4) 
    public void testOneGameOneTurnIllegalMany() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {-1,-2,-3,4,-1,-2,-3,6,-1,-2,-3,15},
			     new Game[] { 
				 oneMoveWin(new int[]{1,2,3,4}) }) });
	run();
    }


    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns1234_1235() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1,2,3,4},
					    new int[]{1,2,3,5},
					    3,0) }) });
	run();
    }

    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns1234_1232() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1,2,3,4},
					    new int[]{1,2,3,2},
					    3,0) }) });
	run();
    }

    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns1232_1234() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1,2,3,2},
					    new int[]{1,2,3,4},
					    3,0) }) });
	run();
    }

    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns1232_2234() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1,2,3,2},
					    new int[]{2,2,3,4},
					    2,1) }) });
	run();
    }

    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns2222_2234() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{2,2,2,2},
					    new int[]{2,2,3,4},
					    2,0) }) });
	run();
    }

    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns2223_2232() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{2,2,2,3},
					    new int[]{2,2,3,2},
					    2,2) }) });
	run();
    }

    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns1234_1342() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1,2,3,4},
					    new int[]{1,3,4,2},
					    1,3) }) });
	run();
    }

    /** win in two turns - code and guess are in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns1234_4321() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1,2,3,4},
					    new int[]{4,3,2,1},
					    0,4) }) });
	run();
    }

    /** win in two turns - short code */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns1_2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {1,6,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1},
					    new int[]{2},
					    0,0) }) });
	run();
    }

    /** win in two turns - long codes */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameTwoTurns123456789_135791357() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {9,12,15},
			     new Game[] { 
				 twoMoveWin(new int[]{1,2,3,4,5,6,7,8,9},
					    new int[]{1,3,5,7,9,1,3,5,7},
					    1,4) }) });
	run();
    }

    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsWin10_15() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,10,true) }) });
	run();
    }

    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsWin1_15() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,1,true) }) });
	run();
    }

    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsWin15_15() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,true) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsWin10_20() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,20},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,10,true) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsWin18_20() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,20},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,18,true) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsWin20_20() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,20},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,20,true) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsLose15() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,false) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsLose20() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,20},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,20,false) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsLose10() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,10},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,10,false) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsLose2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,2},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,2,false) }) });
	run();
    }


    /** multimove game - result and length in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testOneGameMultiTurnsLose1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,1},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,1,false) }) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesLoseLose() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,false),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,15,false)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesLoseWin10() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,false),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,10,true)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesLoseWin15() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,false),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,15,true)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesWin10Lose() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,10,true),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,15,false)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesWin15Lose() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,true),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,15,false)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesWin10Win10() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,10,true),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,10,true)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesWin10Win15() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,10,true),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,15,true)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesWin15Win10() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,true),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,10,true)}) });
	run();
    }

    /** two games diff codes - results in method name */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testTwoGamesDifferentCodesWin15Win15() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new Game[] { 
				 multimoveGame(new int[]{1,2,3,4},
					       new int[]{4,3,2,1},
					       0,4,15,true),
				 multimoveGame(new int[]{2,2,0,0},
					       new int[]{1,1,2,0},
					       1,1,15,true)}) });
	run();
    }

    
    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesNoWins5() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{0,0,0,0,0}  )  } );
	run();
    }
    
    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesNoWins3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{0,0,0}  )  } );
	run();
    }
    
    /** single series - this will pass with int division*/
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesNoLosses1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4,4,4,4,4,4,4}  )  } );
	run();
    }
    

    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesNoLosses2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,3,10,4,14,1}  )  } );
	run();
    }
    

    /** single series - will pass with int division*/
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesNoLosses3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{1,1,1,1,11}  )  } );
	run();
    }
    

    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesNoLosses4() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{5,7,3,11,15,11,9}  )  } );
	run();
    }
    
    
    
    /** single series - this will pass with int division*/
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesSomeLosses1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,0,0,4,4,4,0,0,4,4,0,4,4}  )  } );
	run();
    }
    

    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesSomeLosses2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,0,0,0,0,0,0,0,0,3,10,0,0,0,0,0,4,14,1}  )  } );
	run();
    }
    

    /** single series - will pass with int division*/
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesSomeLosses3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{1,0,1,1,0,1,11,0}  )  } );
	run();
    }
    

    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesSomeLosses4() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{5,7,3,11,15,11,9,0,0,0,0,0,0,0}  )  } );
	run();
    }
    
    
    /** single series - this will pass with int division*/
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesStartLosses1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{0,0,0,0,4,4,4,4,4,4,4,4}  )  } );
	run();
    }
    

    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesStartLosses2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,3,10,4,14,1}  )  } );
	run();
    }
    

    /** single series - will pass with int division*/
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesStartLosses3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{0,1,1,1,1,11,0,0,0,0,0,0,0,0,0,0,0,0}  )  } );
	run();
    }
    

    /** single series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testSeriesStartLosses4() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{0,5,7,3,0,0,11,15,0,0,0,11,9,0,0,0}  )  } );
	run();
    }
    
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4}  ),
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{2,2}  ),
	    } );
	run();
    }
    
    
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,0}  ),
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{0,2}  ),
	    } );
	run();
    }
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4}  ),
		createSeries(new int[] {4,6,17},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{2,2}  ),
	    } );
	run();
    }
    
    
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession4() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4}  ),
		createSeries(new int[] {4,8,15},
			     new int[]{1,2,7,4},
			     new int[]{1,2,2,7},
			     2,1,15,
			     new int[]{2,2}  ),
	    } );
	run();
    }
    
    
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession5() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4}  ),
		createSeries(new int[] {5,6,15},
			     new int[]{1,2,3,4,0},
			     new int[]{1,2,2,3,5},
			     2,1,15,
			     new int[]{2,2}  ),
	    } );
	run();
    }
    
    
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession6() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4}  ),
		createSeries(new int[] {0,4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{2,2}  ),
	    } );
	run();
    }
    
    
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession7() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4}  ),
		createSeries(new int[] {4,0,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{2,2}  ),
	    } );
	run();
    }
    
    /** multi series */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testFullSession8() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{4,4}  ),
		createSeries(new int[] {4,6,0,15},
			     new int[]{1,2,3,4},
			     new int[]{1,2,2,3},
			     2,1,15,
			     new int[]{2,2}  ),
	    } );
	run();
    }


    /** long game different guesses */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testLongGame1() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},new Game[]{
			createGame(new int[]{4,1,2,2},
				   new Turn[]{
				       createTurn(new int[]{0,1,2,3},2,0),
				       createTurn(new int[]{1,2,3,4},0,3),
				       createTurn(new int[]{2,3,4,5},0,2),
				       createTurn(new int[]{0,1,2,4},2,1),
				       createTurn(new int[]{2,2,2,2},2,0),
				       createTurn(new int[]{1,2,2,4},1,3),
				       createTurn(new int[]{4,1,2,2},4,0)
				   })
		    })
	    });
	run();
    }
	
    /** long game different guesses */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testLongGame2() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},new Game[]{
			createGame(new int[]{0,1,2,0},
				   new Turn[]{
				       createTurn(new int[]{0,1,2,3},3,0),
				       createTurn(new int[]{2,3,4,5},0,1),
				       createTurn(new int[]{4,4,5,5},0,0),
				       createTurn(new int[]{0,0,1,1},1,2),
				       createTurn(new int[]{0,1,0,3},2,1),
				       createTurn(new int[]{0,1,2,0},4,0)
				   })
		    })
	    });
	run();
    }
	
    /** long game different guesses */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testLongGame3() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},new Game[]{
			createGame(new int[]{2,2,2,2},
				   new Turn[]{
				       createTurn(new int[]{0,1,2,3},1,0),
				       createTurn(new int[]{1,2,3,4},1,0),
				       createTurn(new int[]{3,4,5,0},0,0),
				       createTurn(new int[]{2,2,2,2},4,0)
				   })
		    })
	    });
	run();
    }

    /** long game different guesses */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testLongGame4() {
	recorder.recordSession(new Series[] {
		createSeries(new int[] {4,6,15},new Game[]{
			createGame(new int[]{3,3,3,5},
				   new Turn[]{
				       createTurn(new int[]{0,1,2,3},0,1),
				       createTurn(new int[]{1,2,3,4},1,0),
				       createTurn(new int[]{2,3,4,5},2,0),
				       createTurn(new int[]{1,3,5,5},2,0),
				       createTurn(new int[]{5,2,5,5},1,0),
				       createTurn(new int[]{1,5,1,1},0,1),
				       createTurn(new int[]{3,3,5,3},2,2),
				       createTurn(new int[]{3,3,3,5},4,0)
				   })
		    })
	    });
	run();
    }
}
