import org.junit.runner.Result;

import org.junit.runner.JUnitCore;
import il.ac.huji.cs.intro.junit.internal.IntroListener;
import org.junit.internal.TextListener;

/**
 * Driver for Ex3 testers
 * 
 * @author Intro2cs Team
 *
 */
public class Ex3TesterDriver {

	/**
	 * Runs the three testers
	 * @param args not used
	 */
	public static void main(String[] args) {
		JUnitCore junit = new JUnitCore();
		junit.addListener(new IntroListener(System.out));
		Result res=junit.run(
				     MastermindTester.class
		);
		System.exit(res.wasSuccessful() ? 0 : 1);
	}

}
