import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

/**
 * Automatic tests for the Point class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class PointTester {

    private static int failedTests=0;

    private static void addFailedTest() {
	failedTests++;
    }

    private static void passTest() {
	failedTests--;
    }

    static int getFailedTests() {
	return failedTests;
    }
	
    /**
     * Helper function: Checks the value of a point.
     * @param p the point to check.  
     * @param x the expected X value of point.
     * @param y the expected Y value of point.
     * @param epsilon an epsilon value to use for double comparison.
     */
    private static void expectPointEquals(Point p, double x, double y, double epsilon) {
        if(Double.isNaN(x) || Double.isNaN(y)) {
            assertNull(p);
        }
        else {
            assertNotNull(p);
            double pX = p.getX();
            double pY = p.getY();
            assertEquals("X values of two points are not equal.",
                    x, pX, epsilon);
            assertEquals("Y values of two points are not equal.", 
                    y, pY, epsilon);
        }
    }
    
    /**
     * Tests default Point constructor.
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testDefaultConstructor() {
	addFailedTest();
        Point p = new Point();
	expectPointEquals(p, 0, 0, TesterUtils.EPSILON);
	expectPointEquals(p, p.getX(), p.getY(), 0);
	passTest();
    }

    /**
     * Tests basic point creation. (0.0,0.0)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointCreation1() {
	addFailedTest();
        Point p = new Point(0.0, 0.0);
	expectPointEquals(p, 0, 0, TesterUtils.EPSILON);
	expectPointEquals(p, p.getX(), p.getY(), 0);
	passTest();
    }
    
    /**
     * Tests basic point creation. (777,-87.11)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointCreation2() {
	addFailedTest();
        Point p = new Point(777, -87.11);
	expectPointEquals(p, 777, -87.11, TesterUtils.EPSILON);
	expectPointEquals(p, p.getX(), p.getY(), 0);
	passTest();
    }
    
    /**
     * Helper function: Checks point multiplication.
     * @param x the X value of point to test.
     * @param y the Y value of point to test.
     * @param multiplier the multiplier to test.
     * @param resX the X value of expected result.
     * @param resX the Y value of expected result.
     */
    private static void checkMultiplication(double x, double y, double multiplier, 
					    double resX, double resY) {
	Point p = new Point(x, y);

        expectPointEquals(p, x, y, TesterUtils.EPSILON);

	// get exact original x,y
	x = p.getX();
	y = p.getY();

        expectPointEquals(p.multiply(multiplier), resX ,resY, TesterUtils.EPSILON);

        //Make sure p remains untouched:
        expectPointEquals(p, x, y, 0);
    }
    
    /**
     * Tests point multiplication. 500*(0,0).
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointMultiply1() {
	checkMultiplication(0, 0, 500, 0, 0);
    }
    
    /**
     * Tests point multiplication. -8*(1.5,2.3)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointMultiply2() {
	checkMultiplication(1.5, 2.3, -8, -12 ,-18.4);
    }
    
    /**
     * Tests point multiplication. 0*(1.5,2.3)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointMultiply3() {
	checkMultiplication(1.5, 2.3, 0, 0 ,0);
    }
    
    /**
     * Helper function: Checks point addition.
     * @param p1 the first operand. (p1.plus(p2)).
     * @param p2 the second operand. (p1.plus(p2)).
     * @param resX the X value of expected result.
     * @param resX the Y value of expected result.
     */
    private static void checkAddition(Point p1, Point p2,
				      double resX, double resY) {
	
	// get exact original x,y
	double x1 = p1.getX();
	double y1 = p1.getY();
	double x2 = p2.getX();
	double y2 = p2.getY();

	expectPointEquals(p1.plus(p2), resX ,resY, TesterUtils.EPSILON);
	
        //Make sure operands remain untouched:
        expectPointEquals(p1, x1, y1, 0);
        expectPointEquals(p2, x2, y2, 0);
    }

    /**
     * Tests point addition. (0,0)+(1.5,2.3)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointPlus1() {
        Point p1 = new Point();
        Point p2 = new Point(1.5, 2.3);

        expectPointEquals(p1, 0  , 0  , TesterUtils.EPSILON);
        expectPointEquals(p2, 1.5, 2.3, TesterUtils.EPSILON);

	checkAddition(p1, p2, 1.5, 2.3);
    }



    /**
     * Tests point addition. (0,0)+-1*(1.5,2.3)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointPlus2() {
        Point p1 = new Point();
        Point p2 = new Point(1.5, 2.3).multiply(-1);

        expectPointEquals(p1,  0  ,  0  , TesterUtils.EPSILON);
        expectPointEquals(p2, -1.5, -2.3, TesterUtils.EPSILON);

	checkAddition(p1, p2, -1.5, -2.3);
    }



    /**
     * Tests point addition. (1.5,2.3)+(1.5,1)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointPlus3() {
        Point p1 = new Point(1.5, 2.3);
        Point p2 = new Point(1.5, 1  );

        expectPointEquals(p1, 1.5, 2.3, TesterUtils.EPSILON);
        expectPointEquals(p2, 1.5, 1  , TesterUtils.EPSILON);

	checkAddition(p1, p2, 3, 3.3);
    }



    /**
     * Tests point addition with same reference. (1.5,2.3)+(1.5,2.3)
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointPlus4() {
        Point p = new Point(1.5, 2.3);

        expectPointEquals(p, 1.5, 2.3, TesterUtils.EPSILON);

	checkAddition(p, p, 3, 4.6);
    }

    /**
     * Tests point addition with null. (1.5,2.3)+null
     */
    @Test (timeout=1000) @TestPenalty(penalty=-3)
    public void testPointPlusNull() {
        Point p = new Point(1.5, 2.3);

        expectPointEquals(p, 1.5, 2.3, TesterUtils.EPSILON);
        double x = p.getX();
        double y = p.getY();

        assertNull("p.plus(null) should return null", p.plus(null));
        expectPointEquals(p, x, y, 0);
    }
}
