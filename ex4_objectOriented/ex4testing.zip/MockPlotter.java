import java.awt.Color;
import java.util.List;


/**
 * A mock plotter object for testing purposes. Does not open windows.
 * 
 * @author intro2cs team
 *
 */
public class MockPlotter extends Plotter {
    
    private static final String ERROR_WINDOW_ALREADY_OPEN = 
            "Plotter window may only be opened once.";
    
    /**
     * Counts the number of times a window open operation was attempted.
     */
    private boolean isWindowOpen;
    
    /**
     * Default constructor.
     */
    public MockPlotter() {
        isWindowOpen = false;
    }
    
    @Override
    public void openWindow() {
        //We don't open windows in the mock plotter!
        
        if(isWindowOpen) {
            throw new RuntimeException(ERROR_WINDOW_ALREADY_OPEN);
        }
        isWindowOpen = true;
    }
    
    /**
     * Returns all curves created by this plotter.
     * 
     * @return all curves created by this plotter.
     */
    public List<List<Point>> getCurves() {
        return this.curves;
    }
    
    /**
     * Returns all curve colors used by this plotter.
     * 
     * @return all curve colors used by this plotter.
     */
    public List<Color> getCurveColors() {
        return this.curvesColor;
    }
    
    /**
     * Returns true if a call to {@link #openWindow() openWindow()}
     *  was made.
     *  
     * @return Whether or not a window was opened.
     */
    public boolean isWindowOpen() {
        return this.isWindowOpen;
    }
    
    
}
