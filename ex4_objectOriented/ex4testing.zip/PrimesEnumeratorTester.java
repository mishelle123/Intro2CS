import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.Before;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

/**
 * Automatic tests for the PrimesEnumerator class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class PrimesEnumeratorTester {

    private static int failedTests=0;

    private static void passTest() {
	failedTests--;
    }

    /**
     * @return the number of important tests
     */
    static int getFailedTests() {
	return failedTests;
    }

    /**
     *
     */
    @Before
    public void addFailedTest() {
	failedTests++;
    }

    /**
     * Helper function: checks hasNext() several times.
     * 
     * @param enumerator the enumerator to test.
     */
    private static void stressTestHasNext(PrimesEnumerator enumerator, 
                                    boolean expected) {
        for (int i = 0; i < 50; i++) {
            assertEquals("hasNext() check failed at attempt no. "+i+".",
                    expected, enumerator.hasNext());
        }
    }

    /**
     * Helper function: checks that the PrimesEnumerator returns the expected 
     * sequence of numbers.
     * 
     * @param enumerator the enumerator to test.
     * @param expected the expected sequence of numbers.
     */
    private static void validatePrimesEnumerator(PrimesEnumerator enumerator,
                                            int[] expected) {
        for (int i = 0; i < expected.length; i++) {
            stressTestHasNext(enumerator, true);
            assertEquals(
                    "PrimesEnumerator failed to generated an expected number.", 
                    expected[i], enumerator.next());
        }
        stressTestHasNext(enumerator, false);
    }

    /**
     * Basic tests for the PrimesEnumerator class. (-10)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPrimesEnumeratorBasic_n10() {
     // Basic tests:
        PrimesEnumerator enumerator = new PrimesEnumerator(-10);
        stressTestHasNext(enumerator, false);
	passTest();
    }

    /**
     * Basic tests for the PrimesEnumerator class. (51,52)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPrimesEnumeratorBasic_51_52() {
     // Basic tests:
        PrimesEnumerator enumerator = new PrimesEnumerator(51, 52);
        stressTestHasNext(enumerator, false);
	passTest();
    }

    /**
     * Basic tests for the PrimesEnumerator class. (2)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPrimesEnumeratorBasic_2() {
     // Basic tests:
        PrimesEnumerator enumerator = new PrimesEnumerator(2);
        validatePrimesEnumerator(enumerator, new int[] { 2 });
	passTest();
    }

    /**
     * Basic tests for the PrimesEnumerator class. (3,3)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPrimesEnumeratorBasic_3_3() {
     // Basic tests:
        PrimesEnumerator enumerator = new PrimesEnumerator(3,3);
        validatePrimesEnumerator(enumerator, new int[] { 3 });
	passTest();
    }

    /**
     * Basic tests for the PrimesEnumerator class. (6,13)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPrimesEnumeratorBasic_6_13() {
     // Basic tests:
        PrimesEnumerator enumerator = new PrimesEnumerator(6, 13);
        validatePrimesEnumerator(enumerator, new int[] { 7, 11, 13 });
	passTest();
    }

    /**
     * Basic tests for the PrimesEnumerator class. (6,16)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPrimesEnumeratorBasic_6_16() {
     // Basic tests:
        PrimesEnumerator enumerator = new PrimesEnumerator(6, 16);
        validatePrimesEnumerator(enumerator, new int[] { 7, 11, 13 });
	passTest();
    }

    /**
     * Basic tests for the PrimesEnumerator class. (6,16)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPrimesEnumeratorBasic_n10_10() {
     // Basic tests:
        PrimesEnumerator enumerator = new PrimesEnumerator(-10, 10);
        validatePrimesEnumerator(enumerator, new int[] { 2, 3, 5, 7 });
	passTest();
    }

    /**
     * Tests PrimesEnumerator around the one-millionth prime number.
     */
    @Test(timeout=60000) @TestPenalty(penalty=-5)
    public void testMillionthPrime() {
	passTest(); // Allow testing even if this fails.
        assertTrue(PrimesEnumerator.isPrime(TesterUtils.MILLIONTH_PRIME));

        PrimesEnumerator enumerator = new PrimesEnumerator(
                TesterUtils.MILLIONTH_PRIME - 1, TesterUtils.MILLIONTH_PRIME);
        validatePrimesEnumerator(enumerator,
                new int[] { TesterUtils.MILLIONTH_PRIME });
        enumerator = new PrimesEnumerator(TesterUtils.MILLIONTH_PRIME,
                TesterUtils.MILLIONTH_PRIME);
        validatePrimesEnumerator(enumerator,
                new int[] { TesterUtils.MILLIONTH_PRIME });
        enumerator = new PrimesEnumerator(TesterUtils.MILLIONTH_PRIME,
                TesterUtils.MILLIONTH_PRIME + 1);
        validatePrimesEnumerator(enumerator,
                new int[] { TesterUtils.MILLIONTH_PRIME });
        enumerator = new PrimesEnumerator(TesterUtils.MILLIONTH_PRIME - 1,
                TesterUtils.MILLIONTH_PRIME + 1);
        validatePrimesEnumerator(enumerator,
                new int[] { TesterUtils.MILLIONTH_PRIME });

    }
    
    /**
     * Tests the first 1000 prime numbers.
     */
    @Test(timeout=60000) @TestPenalty(penalty=-4)
    public void testFirst1000Primes() {
        PrimesEnumerator enumerator = new PrimesEnumerator(7920);
        validatePrimesEnumerator(enumerator, TesterUtils.FIRST_1000_PRIMES);

        enumerator = new PrimesEnumerator(72, 7920);
        validatePrimesEnumerator(enumerator, 
                Arrays.copyOfRange(TesterUtils.FIRST_1000_PRIMES, 20, 
                        TesterUtils.FIRST_1000_PRIMES.length));

	passTest();
    }

    /**
     * Tests isPrime functionality.
     */
    @Test(timeout=60000) @TestPenalty(penalty=-7)
    public void testIsPrime() {
        int nextPrimeIndex = 0;
        for (int i = -100; 
                nextPrimeIndex < TesterUtils.FIRST_1000_PRIMES.length; i++) {
            // String to display in case of failure:
            String failStr = "isPrime() failed on input: "+i+".";
            
            if (i == TesterUtils.FIRST_1000_PRIMES[nextPrimeIndex]) {
                assertTrue(failStr, PrimesEnumerator.isPrime(i));
                nextPrimeIndex++;
            } else {
                assertFalse(failStr, PrimesEnumerator.isPrime(i));
            }
        }
	passTest();
    }

}
