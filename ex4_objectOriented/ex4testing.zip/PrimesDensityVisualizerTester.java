import static org.junit.Assert.*;
import static org.junit.Assume.*;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Arrays;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestRank;
import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

/**
 * Automatic tester for the PrimesDensityVisualizer class.
 * 
 * @author intro2cs team
 * 
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class PrimesDensityVisualizerTester {

    /**
     * The expected "usage" string to be presented by the main function.
     */
    private static final String USAGE_STRING = 
            "Usage: PrimesDensityVisualizer x, "
            + "where x is a natural number greater than 1.";
    
    /**
     * Stream redirection variables. Stdout will be redirected here.
     */
    private ByteArrayOutputStream out;
    private PrintStream sysout;
   
    /**
     * The mock plotter used for testing.
     */
    private MockPlotter mockPlotter;

    private static boolean piPrereqPassed = false;
    private static boolean plottingPrereqPassed = false;

    /**
     * Called before the tests. 
     */
    @Before
    public void setUp() {
        // Redirect stdout:
        out = new ByteArrayOutputStream();
        sysout = System.out;
        System.setOut(new PrintStream(out));
        
        resetMockPlotter();
    }

    /**
     * Called after the tests.
     */
    @After
    public void tearDown() {
        // Reset stream redirection:
        System.setOut(sysout);
    }
    
    /**
     * Resets the mock plotter.
     */
    private void resetMockPlotter() {
        mockPlotter = new MockPlotter();
        PrimesDensityVisualizer.setPlotter(mockPlotter);
    }
    
    /**
     * Checks that prerequisites for calculating pi function passed tests.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-6) @TestRank(rank=-1)
    public void testPiPrerequisites() {
	piPrereqPassed = PrimesEnumeratorTester.getFailedTests() == 0;
	assertTrue("Prerequisite tests for calculating pi function failed.",
		   piPrereqPassed);
    }

    /**
     * Checks that prerequisites for plotting prime densities passed.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-20) @TestRank(rank=-1)
    public void testPointPassed() {
	plottingPrereqPassed = 
	    PointTester.getFailedTests() == 0 && 
	    PrimesEnumeratorTester.getFailedTests() == 0;
	assertTrue("Prerequisite tests for plotting prime densities failed.",
		   plottingPrereqPassed);
    }

    /**
     * Test the pi function.
     */
    @Test(timeout=60000) @TestPenalty(penalty=-6)
    public void testPiFunction() {
	assumeTrue(piPrereqPassed);
        int nextPrimeIndex = 0;
        for (int i = -100; 
                nextPrimeIndex < TesterUtils.FIRST_1000_PRIMES.length; i++) {
            if (i == TesterUtils.FIRST_1000_PRIMES[nextPrimeIndex]) {
                nextPrimeIndex++;
            }
            int numBelow = PrimesDensityVisualizer.numberOfPrimesBelow(i);
            // The number of primes below i should be nextPrimeIndex.
            assertEquals("numberOfPrimesBelow("+i+") failed.",
                    nextPrimeIndex, numBelow);
        }
    }
    
    /**
     * Test the approximation function.
     */
    @Test(timeout=1000) @TestPenalty(penalty=-6)
    public void testApproximationFunction() {
        for (int i = 0; i < 100; i++) {
            assertEquals("approximateNumOfPrimesBelow("+i+") failed.",
                    TesterUtils.APPROX_FOR_0_TO_1000[i], 
                    PrimesDensityVisualizer.approximateNumOfPrimesBelow(i),
                    TesterUtils.EPSILON);
        }
    }

    /**
     * Tests command-line argument handling. Illegal parameter "1".
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testCmdLine_1() {
        PrimesDensityVisualizer.main(new String[] { "1" });
        assertEquals("Usage instructions string was wrong, upon illegal input '1'."
                ,USAGE_STRING, out.toString().trim());
    }
    
    /**
     * Tests command-line argument handling. Illegal parameter "-100".
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testCmdLine_100() {
        PrimesDensityVisualizer.main(new String[] { "-100" });
        assertEquals("Usage instructions string was wrong, upon illegal input '-100'.",
                USAGE_STRING, out.toString().trim());
    }
    
    /**
     * Tests command-line argument handling. Legal parameter "10".
     */
    @Test(timeout=1000) @TestPenalty(penalty=-4)
    public void testCmdLine_10() {
        PrimesDensityVisualizer.main(new String[] { "10" });
        assertEquals("Standard output was not empty with legal input.",
                "", out.toString());
    }
    
    /**
     * Tests the plotter usage for legal parameters using drawPrimesCountingFunction. (2)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-3)
    public void testPlotterUseDraw_2() {
        testPlotterUseForNumber(2, false);
    }
    
    /**
     * Tests the plotter usage for legal parameters using drawPrimesCountingFunction. (10)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-3)
    public void testPlotterUseDraw_10() {
        testPlotterUseForNumber(10, false);
    }
    
    /**
     * Tests the plotter usage for legal parameters using drawPrimesCountingFunction. (100)
     */
    @Test(timeout=60000) @TestPenalty(penalty=-3)
    public void testPlotterUseDraw_100() {
        testPlotterUseForNumber(100, false);
    }
    
    /**
     * Tests the plotter usage for legal parameters using drawPrimesCountingFunction. (1000)
     */
    @Test(timeout=60000) @TestPenalty(penalty=-3)
    public void testPlotterUseDraw_1000() {
        testPlotterUseForNumber(1000, false);
    }
    
    /**
     * Tests the plotter usage for legal parameters using main. (2)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPlotterUseMain_2() {
        testPlotterUseForNumber(2, true);
    }
    
    /**
     * Tests the plotter usage for legal parameters using main. (10)
     */
    @Test(timeout=1000) @TestPenalty(penalty=-2)
    public void testPlotterUseMain_10() {
        testPlotterUseForNumber(10, true);
    }
    
    /**
     * Tests the plotter usage for legal parameters using main. (100)
     */
    @Test(timeout=60000) @TestPenalty(penalty=-2)
    public void testPlotterUseMain_100() {
        testPlotterUseForNumber(100, true);
    }
    
    /**
     * Tests the plotter usage for legal parameters using main. (1000)
     */
    @Test(timeout=60000) @TestPenalty(penalty=-2)
    public void testPlotterUseMain_1000() {
        testPlotterUseForNumber(1000, true);
    }
    
    private void testPlotterUseForNumber(int numToTest, boolean useMain) {
	assumeTrue(plottingPrereqPassed);

        // Now test:
        if(useMain) {
            PrimesDensityVisualizer.main(new String[] { Integer.toString(numToTest) });
        }
        else {
            PrimesDensityVisualizer.drawPrimesCountingFunction(numToTest);
        }
        List<List<Point>> curves = mockPlotter.getCurves();
        List<Color> curveColors = mockPlotter.getCurveColors();
        
        // Verify exactly one call to openWindow() was made:
        assertTrue("Window should have opened", mockPlotter.isWindowOpen());
        
        // Check that 2 curves were created, with the correct colors.
        assertEquals("Exactly 2 curves must be created.", 2, curves.size());
        assertEquals("Curves should be in 2 different colors.",
                2, curveColors.size());
        assertTrue("No red curve was created.", 
                curveColors.contains(Color.red));
        assertTrue("No green curve was created.", 
                curveColors.contains(Color.green));

        // Get the curves according to their colors:
        List<Point> piCurve = null, approxCurve = null;
        for(int i = 0; i < curveColors.size(); i++) {
            Color color = curveColors.get(i);
            List<Point> curve = curves.get(i);
            
            // We already verified that red, green are the only options:
            if(color.equals(Color.red)) {
                piCurve = curve;
            } else if(color.equals(Color.green)) {
                approxCurve = curve;
            } 
        }

        // Test pi function curve contents:
        assertEquals(numToTest-1, piCurve.size());
        for(int i = 0; i < piCurve.size(); i++) {
            Point p = piCurve.get(i);
            int actualIndex = i+2; // We start at 2, not 0.
	    int primesBelow = Arrays.binarySearch(TesterUtils.FIRST_1000_PRIMES, actualIndex) + 1;
	    if(primesBelow <= 0) {
		primesBelow = -primesBelow;
	    }
            assertEquals("Bad X value for a point in the exact curve.", 
			 actualIndex, p.getX(), TesterUtils.EPSILON);
            assertEquals("Bad Y value for a point in the exact curve.",
			 primesBelow, p.getY(), TesterUtils.EPSILON);
        }
        
        // Test approximation function curve contents:
        assertEquals(numToTest-1, approxCurve.size());
        for(int i = 0; i < approxCurve.size(); i++) {
            Point p = approxCurve.get(i);
            int actualIndex = i+2; // We start at 2, not 0.
	    double primesBelow = TesterUtils.APPROX_FOR_0_TO_1000[actualIndex];
            assertEquals("Bad X value for a point in the approximation curve.", 
			 actualIndex, p.getX(), TesterUtils.EPSILON);
            assertEquals("Bad Y value for a point in the approximation curve.",
			 primesBelow, p.getY(), TesterUtils.EPSILON);
        }
    }
}
