import org.junit.Test; // for @Test
import org.junit.Before; // for @Test

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Collections;
import java.util.Random;
/**
 * Tester for class SkipiList
 * 
 * @author Intro2cs Team
 *
 */
@RunWith(IntroJUnit4ClassRunner.class) public class SkipiListTester{

    private static class ListView extends SkipiList {
	
	private ArrayList<SkipiList.Node> view;

	private ListView() {
	    refresh(1);
	}

	private ArrayList<SkipiList.Node> getView() {
	    return view;
	}

	private void refresh() {    
	    refresh(Integer.MAX_VALUE);
	}

	private void refresh(int limit) {	    
	    view = new ArrayList<SkipiList.Node>();
	    for(SkipiList.Node cur=head; cur!=null; cur=cur.getNext()) {
		if(limit--<=0) return;
		view.add(cur);
	    }
	}
    }

    private static ListView fromStringArray(String[] sList) {
	return fromStringArray(null, sList, false);
    }

    private static ListView fromStringArray(String desc, String[] sList) {
	return fromStringArray(desc, sList, false);
    }

    private static ListView fromStringArray(String[] sList, boolean testAll) {
	return fromStringArray(null, sList, testAll);
    }

    private static ListView fromStringArray(String desc, String[] sList, boolean testAll) {
	if(sList==null) return null;
	desc = desc==null ? "" : desc;
	ListView list = new ListView();
	for(int i=0; i<sList.length; i++) {
	    if(testAll) {
		list.refresh(i+1);
		assertListDataEquals(desc+"["+i+"]", list.getView(), sList, sList.length-i);
		assertListEquals(desc+"["+i+"]", list, list.getView());
	    }
	    list.addFirst(sList[sList.length-i-1]);
	}
	list.refresh(sList.length+1);
	assertListDataEquals(desc, list.getView(), sList);
	assertListEquals(desc, list, list.getView());
	return list;
    }
    
    private static void assertListEquals(SkipiList list,ArrayList<SkipiList.Node> view) {
	assertListEquals(null,list,view);
    }

    private static boolean assertListNulls(String desc, SkipiList list,ArrayList<SkipiList.Node> view) {
	if(view==null) {
	    assertNull(desc,list);
	    return true;
	}
	if(list==null) {
	    assertNull(desc,view);
	    return true;
	}
	if(view.size()==0) { 
	    assertNull(desc,list.head);
	    assertNull(desc,list.tail);
	    return true;
	}
	if(list.head==null) {
	    assertEquals(desc,0,view.size());
	    assertNull(desc,list.tail);
	    return true;
	}
	if(list.tail==null) {
	    assertEquals(desc,0,view.size());
	    assertNull(desc,list.head);
	    return true;
	}
	return false;
    }

    private static void assertListEquals(String desc, SkipiList list,ArrayList<SkipiList.Node> view) {
	if(assertListNulls(desc,list,view))
	    return;
	desc = desc==null ? "" : desc;
	assertSame(desc+"(idx=0,++)",view.get(0),list.head);
	for(int i=1;i<view.size();i++) {
	    assertSame(desc+"(idx="+i+",++)",view.get(i),view.get(i-1).getNext());
	}
	assertNull(desc+"(idx="+view.size()+",++)",view.get(view.size()-1).getNext());

	assertSame(desc+"(idx="+(view.size()-1)+",--)",view.get(view.size()-1),list.tail);
	for(int i=2;i<view.size();i++) {
	    assertSame(desc+"(idx="+i+",++)",view.get(i-2),view.get(i).getSkipBack());
	}
	if(view.size()>1)
	    assertNull(desc+"(idx=1,--)",view.get(1).getSkipBack());
	assertNull(desc+"(idx=0,--)",view.get(0).getSkipBack());
    }


    private static void assertListDataEquals(ArrayList<SkipiList.Node> view, String[] dList) {
	assertListDataEquals(null, view, dList);
    }

    private static void assertListDataEquals(ArrayList<SkipiList.Node> view, String[] dList, int start) {
	assertListDataEquals(null, view, dList, start);
    }

    private static void assertListDataEquals(String desc, ArrayList<SkipiList.Node> view, String[] dList) {
	assertListDataEquals(desc, view, dList, 0);
    }

    private static void assertListDataEquals(String desc, ArrayList<SkipiList.Node> view, String[] dList, int start) {
	assertListDataEquals(desc, view, dList, start, dList.length);
    }

    private static void assertListDataEquals(String desc, ArrayList<SkipiList.Node> view, String[] dList, int start, int end) {
	desc = desc==null ? "" : desc;
	assertEquals(desc+"(length)", end-start, view.size());
	for(int i=start;i<end;i++) {
	    assertSame(desc+"("+i+")",dList[i],view.get(i-start).getData());
	}
    }

    /**
     * Some random tests to try to make sure we can count on
     * SkipiList.Node.
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-100)
    public void testNode()  {
	Random rand = new Random(2345);
	SkipiList.Node[] nodes = new SkipiList.Node[20];
	String[] data = new String[nodes.length];
	int[] nexts = new int[nodes.length];
	int[] backs = new int[nodes.length];
	for(int j=1;j<nodes.length;j++) {
	    data[j] = Integer.toString(j);
	    nexts[j] = rand.nextInt(j);
	    backs[j] = rand.nextInt(j);
	    nodes[j] = new SkipiList.Node(data[j],nodes[nexts[j]],nodes[backs[j]]);
	}
	for(int i=0;i<10000;i++) {
	    int src = rand.nextInt(nodes.length);
	    if(src==0) {
		for(int j=1;j<nodes.length;j++) {
		    assertSame(data[j],nodes[j].getData());
		    assertSame(nodes[nexts[j]],nodes[j].getNext());
		    assertSame(nodes[backs[j]],nodes[j].getSkipBack());
		}
	    }
	    else {
		int trg = rand.nextInt(nodes.length);
		boolean action = rand.nextBoolean();
		if(action) {
		    nodes[src].setNext(nodes[trg]);
		    nexts[src] = trg;
		}
		else {
		    nodes[src].setSkipBack(nodes[trg]);
		    backs[src] = trg;
		}
	    }
	}
    }

    private static void assertEmptyList(ListView list) {
	assertNull(list.head);
	assertNull(list.tail);
    }

    @Test(timeout=1000) @TestPenalty(penalty=-20)
    public void testListConstructor() {
	ListView list = new ListView();
	ArrayList<SkipiList.Node> view = list.getView();
	assertEmptyList(list);
	ListView list2 = new ListView();
	list2.tail = new SkipiList.Node("b",null,null);
	list2.head = new SkipiList.Node("a",list2.tail,null);
    }

    @Test(timeout=1000) @TestPenalty(penalty=-20)
    public void testAddFirst() {
	String[] sList1 = new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	ListView list1 = fromStringArray(sList1, true); // includes verification
	String[] sList2 = new String[]{"0","1","2","3","4","5","6","7","8","9"};
	ListView list2 = fromStringArray(sList2, true); // includes verification
	assertListDataEquals(list1.getView(),sList1);
	assertListEquals(list1, list1.getView());
	assertListDataEquals(list2.getView(),sList2);
	assertListEquals(list2, list2.getView());
    }

    @Test(timeout=1000) @TestPenalty(penalty=-20)
    public void testAddLast() {
	String[] sList = new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	ListView list = new ListView();
	for(int i=0; i<sList.length; i++) {
	    list.refresh(i+1);
	    assertListDataEquals("["+i+"]", list.getView(), sList, 0, i);
	    assertListEquals("["+i+"]", list, list.getView());
	    list.addLast(sList[i]);
	}
	list.refresh(sList.length+1);
	assertListDataEquals(list.getView(), sList);
	assertListEquals(list, list.getView());
    }

    @Test(timeout=1000) @TestPenalty(penalty=-20)
    public void testRemoveFirst() {
	String[] sList = new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	ListView list = new ListView();
	assertEmptyList(list);
	assertNull(list.removeFirst());
	assertEmptyList(list);
	list = fromStringArray(sList);
	ArrayList<SkipiList.Node> view = list.getView();
	for(int i=0; i<sList.length; i++) {
	    String expected = view.remove(0).getData();
	    assertSame("wrong returned value "+"["+i+"]",expected,list.removeFirst());
	    assertListDataEquals("["+i+"]", view, sList, i+1);
	    assertListEquals("["+i+"]", list, view);
	}
	assertEmptyList(list);
	assertNull(list.removeFirst());
	assertEmptyList(list);
    }

    @Test(timeout=1000) @TestPenalty(penalty=-20)
    public void testRemoveLast() {
	String[] sList = new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};

	ListView list = new ListView();
	assertEmptyList(list);
	assertNull(list.removeLast());
	assertEmptyList(list);
	list = fromStringArray(sList);
	ArrayList<SkipiList.Node> view = list.getView();
	for(int i=0; i<sList.length; i++) {
	    String expected = view.remove(view.size()-1).getData();
	    assertSame("wrong returned value "+"["+i+"]",expected,list.removeLast());
	    assertListDataEquals("["+i+"]", view, sList, 0,sList.length-i-1);
	    assertListEquals("["+i+"]", list, view);
	}
	assertEmptyList(list);
	assertNull(list.removeLast());
	assertEmptyList(list);
    }


    private static void checkRemoveElementNode(String[] sList, int[] order) {
	ListView list = fromStringArray(sList);
	ArrayList<SkipiList.Node> view = list.getView();
	SkipiList.Node[] nodes = view.toArray(new SkipiList.Node[sList.length]);
	for(int i=0; i<sList.length; i++) {
	    String expected = nodes[order[i]].getData();
	    assertTrue(view.remove(nodes[order[i]]));
	    assertSame("wrong returned value "+"["+i+"]",expected,list.removeElement(nodes[order[i]]));
	    assertListEquals("["+i+"]", list, view);
	}
	assertEmptyList(list);
    }
    
    @Test(timeout=1000) @TestPenalty(penalty=-20)
    public void testRemoveElementNode1() {
	String[] sList = new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	int[] order = new int[]{18,9,13,23,5,1,16,20,10,25,3,22,19,14,21,11,24,7,2,15,4,0,12,6,17,8};


	checkRemoveElementNode(sList,order);
    }

    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testRemoveElementNode2() {
	String[] sList = new String[]{"a","b","c"};
	int[] order = new int[]{1,0,2};
	checkRemoveElementNode(sList,order);
	order = new int[]{2,0,1};
	checkRemoveElementNode(sList,order);
    }

    @Test(timeout=1000) @TestPenalty(penalty=-20)
    public void testRemoveElementDataUnique() {
	String[] sList = new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	int[] order = new int[]{18,9,13,23,5,1,16,20,10,25,3,22,19,14,21,11,24,7,2,15,4,0,12,6,17,8};
	

	ListView list = fromStringArray(sList);
	ArrayList<SkipiList.Node> view = list.getView();
	SkipiList.Node[] nodes = view.toArray(new SkipiList.Node[sList.length]);
	for(int i=0; i<sList.length; i++) {
	    for(int j=0;j<i;j++) {
		assertFalse("element '"+sList[order[j]]+"' should not be in list",list.removeElement(sList[order[j]]));
		assertListEquals("["+i+","+j+",modified]", list, view);
	    }
	    assertTrue(view.remove(nodes[order[i]]));
	    assertTrue("could not find element "+"["+sList[order[i]]+"]",list.removeElement(new String(sList[order[i]])));
	    assertListEquals("["+i+"]", list, view);
	}
	assertEmptyList(list);
	for(int j=0;j<sList.length;j++) {
	    assertFalse("element '"+sList[order[j]]+"' should not be in list",list.removeElement(sList[order[j]]));
	    assertEmptyList(list);
	}
    }

    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testRemoveElementDataRepeated() {
	int vals = 3;
	String[] sList = new String[]{new String("a"),new String("b"),new String("c"),
				      new String("a"),new String("b"),new String("c"),
				      new String("a"),new String("b"),new String("c"),
				      new String("a"),new String("b"),new String("c")};
	int[] order = new int[]{2,0,1,4,5,3,8,6,9,11,7,10};
	ListView list = fromStringArray(sList);
	ArrayList<SkipiList.Node> view = list.getView();
	SkipiList.Node[] nodes = view.toArray(new SkipiList.Node[sList.length]);
	for(int i=0; i<sList.length; i++) {
	    assertTrue(view.remove(nodes[order[i]]));
	    assertTrue("could not find element "+"["+sList[order[i]]+"]",list.removeElement(sList[order[i]%vals+vals]));
	    assertListEquals("["+i+"]", list, view);

	    if(order[i]+vals >= sList.length) {
		assertFalse("element '"+sList[order[i]]+"' should not be in list",list.removeElement(sList[order[i]%vals+vals]));
		assertListEquals("["+i+",modified]", list, view);
	    }
	}
	assertEmptyList(list);
    }

    private static void assertToString(String[] source, String expected) {
	ListView list = fromStringArray(source);
	assertEquals(expected,list.toString()); 
    }

    private static void assertBackString(String[] source, String expected) {
	ListView list = fromStringArray(source);
	assertEquals(expected,list.backString()); 
    }

    /**
     * tests toString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testToString1() {
	assertToString(new String[]{"Baby","Doni","Zan","Dan","Ann"},
		       "[Baby,Doni,Zan,Dan,Ann]");
    }
	
    /**
     * tests backString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testBackString1() {
	assertBackString(new String[]{"Baby","Doni","Zan","Dan","Ann"},
		       "[Ann,Dan,Zan,Doni,Baby]");
    }
	
    /**
     * tests toString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testToString2() {
	assertToString(new String[]{"Baby","Doni"},
		       "[Baby,Doni]");
    }
	
    /**
     * tests backString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testBackString2() {
	assertBackString(new String[]{"Baby","Doni"},
		       "[Doni,Baby]");
    }
	
    /**
     * tests toString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testToString3() {
	assertToString(new String[]{"Baby"},
		       "[Baby]");
    }
	
    /**
     * tests backString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testBackString3() {
	assertBackString(new String[]{"Baby"},
		       "[Baby]");
    }
	
    /**
     * tests toString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testToString4() {
	assertToString(new String[]{},
		       "[]");
    }
	
    /**
     * tests backString()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testBackString4() {
	assertBackString(new String[]{},
		       "[]");
    }
}
