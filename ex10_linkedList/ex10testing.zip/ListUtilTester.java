import org.junit.Test; // for @Test

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Collections;

/**
 * Tester for class ListUtil
 * 
 * @author Intro2cs Team
 *
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class ListUtilTester{

    private static class ListView extends List {
	
	private ArrayList<List.Node> view;

	private ListView() {
	    refresh();
	}

	private ArrayList<List.Node> getView() {
	    return view;
	}

	private void refresh() {    
	    refresh(Integer.MAX_VALUE);
	}

	private void refresh(int limit) {	    
	    view = new ArrayList<List.Node>();
	    for(List.Node cur=head; cur!=null; cur=cur.getNext()) {
		if(limit--<=0) return;
		view.add(cur);
	    }
	}
    }
    
    private static class NodeComparator implements Comparator<List.Node> {

	public int compare(List.Node n1, List.Node n2) {
	    return n1.getData().compareTo(n2.getData());
	}
    }

    private static ListView fromStringArray(String[] sList) {
	if(sList==null) return null;
	ListView list = new ListView();
	for(int i=sList.length-1; i>=0; i--) {
	    list.addFirst(sList[i]);
	}
	list.refresh();
	return list;
    }

    private static void addCycle(ListView list, int index) {
	ArrayList<List.Node> view = list.getView();
	view.get(view.size()-1).setNext(view.get(index));
    }

    private static void addIntersection(ListView list1, ListView list2, int index) {
	ArrayList<List.Node> view1 = list1.getView();
	ArrayList<List.Node> view2 = list2.getView();
	if(view1.size()==0) {
	    list1.head=view2.get(index);
	}
	else {
	    view1.get(view1.size()-1).setNext(view2.get(index));
	}
	list1.refresh();
    }

    private static void assertListEquals(List list,ArrayList<List.Node> view) {
	assertListEquals(null,list,view,null);
    }

    private static void assertListEquals(List list,ArrayList<List.Node> view,List.Node next) {
	assertListEquals(null,list,view,next);
    }
    
    private static void assertListEquals(String desc, List list,ArrayList<List.Node> view) {
	assertListEquals(desc,list,view,null);
    }

    private static boolean assertListNulls(String desc, List list,ArrayList<List.Node> view) {
	if(view==null) {
	    assertNull(desc,list);
	    return true;
	}
	if(list==null) {
	    assertNull(desc,view);
	    return true;
	}
	if(view.size()==0) { 
	    assertNull(desc,list.head);
	    return true;
	}
	if(list.head==null) {
	    assertEquals(desc,0,view.size());
	    return true;
	}
	return false;
    }

    private static void assertListEquals(String desc, List list,ArrayList<List.Node> view,List.Node next) {
	if(assertListNulls(desc,list,view))
	    return;
	desc = desc==null ? "" : desc;
	assertSame(desc+"(idx=0)",view.get(0),list.head);
	for(int i=1;i<view.size();i++) {
	    assertSame(desc+"(idx="+i+")",view.get(i),view.get(i-1).getNext());
	}
	assertSame(desc+"(idx="+view.size()+")",next,view.get(view.size()-1).getNext());
    }

    private static void assertListReversed(List list,ArrayList<List.Node> view) {
	assertListReversed(null,list,view);
    }

    private static void assertListReversed(String desc, List list,ArrayList<List.Node> view) {
	if(assertListNulls(desc,list,view))
	    return;
	desc = desc==null ? "" : desc;
	assertSame(desc+"(idx=0)",view.get(view.size()-1),list.head);
	for(int i=1;i<view.size();i++) {
	    assertSame(desc+"(idx="+i+")",view.get(view.size()-i-1),view.get(view.size()-i).getNext());
	}
	assertSame(desc+"(idx="+view.size()+")",null,view.get(0).getNext());
    }

    private static void assertListDataEquals(String desc, List list,ArrayList<List.Node> view) {
	if(assertListNulls(desc,list,view))
	    return;
	desc = desc==null ? "" : desc;
	List.Node cur = list.head;
	for(int i=0;i<view.size();i++) {
	    assertEquals(desc+"(idx="+i+")",view.get(i).getData(),cur.getData());
	    //assertSame(desc+"(idx="+i+")",view.get(i).getData(),cur.getData());
	    cur = cur.getNext();
	}
	assertNull(desc+"(idx="+view.size()+")",cur);
    }

    private static void assertContainsCycle(ListView list, boolean expected) {
	ArrayList<List.Node> view = list.getView();
	List.Node loop = expected ? view.get(view.size()-1).getNext() : null;
	assertEquals("containsCycle() returned wrong result",expected,ListUtil.containsCycle(list));
	assertListEquals("containsCycle() modified original list",list,view,loop);
    }
			
    private static void checkReverse(ListView list) {
	ArrayList<List.Node> view = list.getView();
	ListUtil.reverse(list);
	assertListReversed(list,view);
	ListUtil.reverse(list);
	assertListEquals(list,view);
    }
	
    private static void assertIsPalindrome(ListView list, boolean expected) {
	ArrayList<List.Node> view = list.getView();
	boolean result = ListUtil.isPalindrome(list);
	assertEquals("isPalindrome() returned wrong result",expected,ListUtil.isPalindrome(list));
	assertListEquals("isPalindrome() modified original list",list,view);
    }
			
    private static void assertHaveIntersection(ListView list1, ListView list2, boolean expected) {
	ArrayList<List.Node> view1 = list1.getView();
	ArrayList<List.Node> view2 = list2.getView();
	assertEquals("haveIntersection() returned wrong result",expected,ListUtil.haveIntersection(list1,list2));
	assertListEquals("haveIntersection() modified original list",list1,view1);
	assertListEquals("haveIntersection() modified original list",list2,view2);
	assertEquals("haveIntersection() returned wrong result",expected,ListUtil.haveIntersection(list2,list1));
	assertListEquals("haveIntersection() modified original list",list1,view1);
	assertListEquals("haveIntersection() modified original list",list2,view2);
    }
    
    private static void checkMergeSort(ListView list) {
	ArrayList<List.Node> view = list.getView();
	Collections.sort(view,new NodeComparator());
	ListUtil.mergeSort(list);
	assertListEquals(list,view);
    }

    private static void checkMergeLists(ListView list1, ListView list2) {
	ArrayList<List.Node> view1 = list1.getView();
	ArrayList<List.Node> view2 = list2.getView();
	ArrayList<List.Node> sorted = new ArrayList<List.Node>(view1);
	sorted.addAll(view2);
	Collections.sort(sorted,new NodeComparator());
	List res = ListUtil.mergeLists(list1,list2);
	assertListEquals("mergeLists() modified original list",list1,view1);
	assertListEquals("mergeLists() modified original list",list2,view2);
	assertListDataEquals("mergeLists() did not sort correctly",res,sorted);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseEmpty()  {
	assertContainsCycle(new ListView(),false);
    }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLength1()  {
	assertContainsCycle(fromStringArray(new String[]{"abc"}),false);
    }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLength2()  {
	assertContainsCycle(fromStringArray(new String[]{"abc","def"}),false);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLength5a()  {
	assertContainsCycle(fromStringArray(new String[]{"abc","def","ghi","jkl","mno"}),false);
    }


    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLength5b()  {
	assertContainsCycle(fromStringArray(new String[]{"abc","def","abc","def","abc"}),false);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLength6a()  {
	assertContainsCycle(fromStringArray(new String[]{"abc","def","ghi","jkl","mno","pqr"}),false);
    }


    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLength6b()  {
	assertContainsCycle(fromStringArray(new String[]{"abc","def","abc","def","abc","def"}),false);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLongEven()  {
	String[] arr = new String[1000];
	Arrays.fill(arr,"abc");
	assertContainsCycle(fromStringArray(arr),false);
    }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleFalseLongOdd()  {
	String[] arr = new String[1001];
	Arrays.fill(arr,"");
	assertContainsCycle(fromStringArray(arr),false);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLength1()  {	
	ListView list = fromStringArray(new String[]{"defg"});
	addCycle(list,0);
	assertContainsCycle(list,true);
    }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLength2a()  {
	ListView list = fromStringArray(new String[]{"abc","def"});
	addCycle(list,0);
	assertContainsCycle(list,true);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLength2b()  {
	ListView list = fromStringArray(new String[]{"abc","def"});
	addCycle(list,1);
	assertContainsCycle(list,true);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLength5()  {
	ListView list = fromStringArray(new String[]{"abc","def","ghi","jkl","mno"});
	addCycle(list,1);
	assertContainsCycle(list,true);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLength6()  {
	ListView list = fromStringArray(new String[]{"abc","def","abc","def","abc","def"});
	addCycle(list,4);
	assertContainsCycle(list,true);
    }

    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLongEven1()  {
	String[] arr = new String[1000];
	Arrays.fill(arr,"abc");
	ListView list = fromStringArray(arr);
	addCycle(list,0);
	assertContainsCycle(list,true);
    }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLongOdd1()  {
	String[] arr = new String[1001];
	Arrays.fill(arr,"");
	ListView list = fromStringArray(arr);
 	addCycle(list,0);
	assertContainsCycle(list,true);
   }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLongEven2()  {
	String[] arr = new String[1000];
	Arrays.fill(arr,"abc");
	ListView list = fromStringArray(arr);
 	addCycle(list,999);
	assertContainsCycle(list,true);
   }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLongOdd2()  {
	String[] arr = new String[1001];
	Arrays.fill(arr,"");
	ListView list = fromStringArray(arr);
	addCycle(list,1000);
	assertContainsCycle(list,true);
    }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLongEven3()  {
	String[] arr = new String[1000];
	Arrays.fill(arr,"abc");
	ListView list = fromStringArray(arr);
 	addCycle(list,500);
	assertContainsCycle(list,true);
   }
    
    /**
     * tests containsCycle()
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testContainsCycleTrueLongOdd3()  {
	String[] arr = new String[1001];
	Arrays.fill(arr,"");
	ListView list = fromStringArray(arr);
	addCycle(list,500);
	assertContainsCycle(list,true);
    }
    
    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseEmpty()  {
	checkReverse(new ListView());
    }

    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseLength1()  {	
	checkReverse(fromStringArray(new String[]{"hij"}));
    }
    
    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseLength2a()  {
	checkReverse(fromStringArray(new String[]{"abc","hij"}));
    }

    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseLength2b()  {
	checkReverse(fromStringArray(new String[]{"abc","hij"}));
    }

    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseLength3a()  {
	checkReverse(fromStringArray(new String[]{"a","b","c"}));
    }


    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseLength3b()  {
	checkReverse(fromStringArray(new String[]{"b","c","a"}));
    }



    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseLengthLong1()  {
	int n=1000;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,n/3,"b");
	Arrays.fill(arr,n/3,n/2,"c");
	Arrays.fill(arr,n/2,n,"d");
	checkReverse(fromStringArray(arr));
    }

    /**
     * tests reverse(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testReverseLengthLong2()  {
	int n=1001;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,n/3,"b");
	Arrays.fill(arr,n/3,n/2,"c");
	Arrays.fill(arr,n/2,n,"d");
	checkReverse(fromStringArray(arr));
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeEmpty()  {
	assertIsPalindrome(new ListView(),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength1()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd"}),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength2a()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","abcd"}),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength2b()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","efgh"}),false);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength3a()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","efgh","ijkl"}),false);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength3b()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","efgh","efgh"}),false);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength3c()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","efgh","abcd"}),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength3d()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","abcd","abcd"}),true);
    }


    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength4a()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","efgh","ijkl","abcd"}),false);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength4b()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","efgh","efgh","ijkl"}),false);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength4c()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","efgh","efgh","abcd"}),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLength4d()  {
	assertIsPalindrome(fromStringArray(new String[]{"abcd","abcd","abcd","abcd"}),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLengthLongE1()  {
	int n=1000;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,3*n/4,"b");
	Arrays.fill(arr,3*n/4,n,"a");
	assertIsPalindrome(fromStringArray(arr),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLengthLongE2()  {
	int n=1000;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,3*n/4,"b");
	Arrays.fill(arr,3*n/4,n,"a");
	arr[n/2]="a";
	assertIsPalindrome(fromStringArray(arr),false);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLengthLongE3()  {
	int n=1000;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,3*n/4,"b");
	Arrays.fill(arr,3*n/4,n,"a");
	arr[n/4]="a";
	assertIsPalindrome(fromStringArray(arr),false);
    }

    /** 
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLengthLongO1()  {
	int n=1001;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,3*n/4+1,"b");
	Arrays.fill(arr,3*n/4+1,n,"a");
	assertIsPalindrome(fromStringArray(arr),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLengthLongO2()  {
	int n=1001;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,3*n/4+1,"b");
	Arrays.fill(arr,3*n/4+1,n,"a");
	arr[n/2]="a";
	assertIsPalindrome(fromStringArray(arr),true);
    }

    /**
     * tests isPalindrome(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testIsPalindromeLengthLongO3()  {
	int n=1001;
	String[] arr = new String[n];
	Arrays.fill(arr,0,n/4,"a");
	Arrays.fill(arr,n/4,3*n/4+1,"b");
	Arrays.fill(arr,3*n/4+1,n,"a");
	arr[3*n/4]="a";
	assertIsPalindrome(fromStringArray(arr),false);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionSameEmpty()  {
        ListView list = new ListView();
	assertHaveIntersection(list, list, false);
    }
	
    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionSameNonEmpty()  {
        ListView list = fromStringArray(new String[]{"a","b","c","d"});
	assertHaveIntersection(list, list, true);
    }
	
    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionEmptyEmpty()  {
	assertHaveIntersection(new ListView(), new ListView(), false);
    }
	
    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionEmptyNonEmpty()  {
	assertHaveIntersection(new ListView(), fromStringArray(new String[]{"a","b","c","d"}), false);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionFalse1()  {
	assertHaveIntersection(
				 fromStringArray(new String[]{"a","b","c","d"}), 
				 fromStringArray(new String[]{"a","b","c","d"}), 
				 false);
    }


    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionFalse2()  {
	assertHaveIntersection(
				 fromStringArray(new String[]{"a","b","c","d"}), 
				 fromStringArray(new String[]{"b","c","d"}), 
				 false);
    }


    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionFalse3()  {	
	assertHaveIntersection(
				 fromStringArray(new String[]{"a"}), 
				 fromStringArray(new String[]{"a","b","c","d"}), 
				 false);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionFalse4()  {
	String[] arr1 = new String[100];
	String[] arr2 = new String[100];
	Arrays.fill(arr1,"a");
	Arrays.fill(arr2,"a");
	assertHaveIntersection(fromStringArray(arr1), fromStringArray(arr2), false);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionFalse5()  {
	String[] arr1 = new String[100];
	String[] arr2 = new String[200];
	Arrays.fill(arr1,"a");
	Arrays.fill(arr2,"b");
	assertHaveIntersection(fromStringArray(arr1), fromStringArray(arr2), false);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionFalse6()  {
	String[] arr1 = new String[100];
	String[] arr2 = new String[200];
	Arrays.fill(arr1,"a");
	Arrays.fill(arr2,"a");
	assertHaveIntersection(fromStringArray(arr1), fromStringArray(arr2), false);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionHead1()  {
	ListView list1 = new ListView();
	ListView list2 = fromStringArray(new String[]{"a","b","c","d"});
	addIntersection(list1,list2,0);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionHead2()  {
	ListView list1 = new ListView();
	ListView list2 = fromStringArray(new String[]{"a","b","c","d"});
	addIntersection(list1,list2,2);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionHead3()  {
	ListView list1 = new ListView();
	ListView list2 = fromStringArray(new String[]{"a","b","c","d"});
	addIntersection(list1,list2,3);
	assertHaveIntersection(list1,list2,true);
    }


    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionTrue1()  {
	ListView list1 = fromStringArray(new String[]{"a","b","c","d"});
	ListView list2 = fromStringArray(new String[]{"e","f","g","h"});
	addIntersection(list1,list2,1);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionTrue2()  {
	ListView list1 = fromStringArray(new String[]{"a"});
	ListView list2 = fromStringArray(new String[]{"e","f","g","h"});
	addIntersection(list1,list2,1);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionTrue3()  {	
	ListView list1 = fromStringArray(new String[]{"a"});
	ListView list2 = fromStringArray(new String[]{"e","f","g","h"});
	addIntersection(list1,list2,3);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionTrue4()  {
	String[] arr1 = new String[100];
	String[] arr2 = new String[100];
	Arrays.fill(arr1,"a");
	Arrays.fill(arr2,"a");
	ListView list1 = fromStringArray(arr1);
	ListView list2 = fromStringArray(arr2);
	addIntersection(list1,list2,30);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionTrue5()  {
	String[] arr1 = new String[100];
	String[] arr2 = new String[200];
	Arrays.fill(arr1,"a");
	Arrays.fill(arr2,"b");
	ListView list1 = fromStringArray(arr1);
	ListView list2 = fromStringArray(arr2);
	addIntersection(list1,list2,190);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests  intersect(List first, List second)
     */		 
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testHaveIntersectionTrue6()  {
	String[] arr1 = new String[200];
	String[] arr2 = new String[100];
	Arrays.fill(arr1,"a");
	Arrays.fill(arr2,"a");
	ListView list1 = fromStringArray(arr1);
	ListView list2 = fromStringArray(arr2);
	addIntersection(list1,list2,20);
	assertHaveIntersection(list1,list2,true);
    }

    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortEmpty()  {
	checkMergeSort(fromStringArray(new String[0]));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortSingle() {
	checkMergeSort(fromStringArray(new String[]{"abc"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength2ordered() {
	checkMergeSort(fromStringArray(new String[]{"abc","def"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength2unordered() {
	checkMergeSort(fromStringArray(new String[]{"def","abc"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength2stability() {
	checkMergeSort(fromStringArray(new String[]{"abc","abc"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3a() {
	checkMergeSort(fromStringArray(new String[]{"a","b","c"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3b() {
	checkMergeSort(fromStringArray(new String[]{"a","c","b"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3c() {
	checkMergeSort(fromStringArray(new String[]{"a","b","b"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3d() {
	checkMergeSort(fromStringArray(new String[]{"b","b","c"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3e() {
	checkMergeSort(fromStringArray(new String[]{"a","b","a"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3f() {
	checkMergeSort(fromStringArray(new String[]{"c","b","c"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3g() {
	checkMergeSort(fromStringArray(new String[]{"c","b","a"}));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLength3h() {
	checkMergeSort(fromStringArray(new String[]{"a","c","b"}));
    }

    //String.format("%03d", num);

    private static String[] fillArray(String[] arr, int start, int mult, int add, int mod, int width) {
	for(int i=0; i<arr.length; i++) {
	    arr[i]=String.format("%0"+width+"d",start);
	    start = (start+mult*i+add)%mod;
	}
	return arr;
    }

    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLong1() {
	checkMergeSort(fromStringArray(fillArray(new String[100],333,0,1,1000,3)));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLong2() {
	checkMergeSort(fromStringArray(fillArray(new String[128],444,0,0,1000,3)));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLong3() {
	checkMergeSort(fromStringArray(fillArray(new String[100],555,0,-1,1000,3)));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLong4() {
	checkMergeSort(fromStringArray(fillArray(new String[100],666,0,31,1000,3)));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLong5() {
	checkMergeSort(fromStringArray(fillArray(new String[100],66,0,31,100,2)));
    }
	
    /**
     * tests mergeSort(List list)
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeSortLong6() {
	checkMergeSort(fromStringArray(fillArray(new String[100],66,1,31,100,2)));
    }
	
    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsEmpty()  {
	checkMergeLists(new ListView(),
			new ListView());
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsFirstEmpty()  {
	checkMergeLists(new ListView(),
		       fromStringArray(new String[]{"abc","def"}));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsSecondEmpty()  {
	checkMergeLists(fromStringArray(new String[]{"abc","def"}),
		       new ListView());
    }


    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsShort1()  {
	checkMergeLists(fromStringArray(new String[]{"a","b"}),
		       fromStringArray(new String[]{"c","d"}));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsShort2()  {
	checkMergeLists(fromStringArray(new String[]{"a","c"}),
		       fromStringArray(new String[]{"b","d"}));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsShort3()  {
	checkMergeLists(fromStringArray(new String[]{"a","d"}),
		       fromStringArray(new String[]{"b","c"}));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsShort4()  {
	checkMergeLists(fromStringArray(new String[]{"a","b"}),
		       fromStringArray(new String[]{"b","c"}));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsShort5()  {
	checkMergeLists(fromStringArray(new String[]{"a","b"}),
		       fromStringArray(new String[]{"a","b"}));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsShort6()  {
	checkMergeLists(fromStringArray(new String[]{"a","c"}),
		       fromStringArray(new String[]{"b","c"}));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsLong1() {
	checkMergeLists(fromStringArray(fillArray(new String[100],123,0,1,1000,3)),
			fromStringArray(fillArray(new String[100],223,0,1,1000,3)));
    }
	
    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsLong2() {
	checkMergeLists(fromStringArray(fillArray(new String[100],223,0,1,1000,3)),
			fromStringArray(fillArray(new String[100],123,0,1,1000,3)));
    }
	
    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsLong3() {
	checkMergeLists(fromStringArray(fillArray(new String[10],173,0,1,1000,3)),
			fromStringArray(fillArray(new String[100],123,0,1,1000,3)));
    }
	
    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsLong4() {
	checkMergeLists(fromStringArray(fillArray(new String[100],123,0,1,1000,3)),
			fromStringArray(fillArray(new String[100],123,0,1,1000,3)));
    }
	
    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsLong5() {
	checkMergeLists(fromStringArray(fillArray(new String[100],123,0,4,1000,3)),
			fromStringArray(fillArray(new String[10],223,0,2,1000,3)));
    }
	
    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsLong6() {
	checkMergeLists(fromStringArray(fillArray(new String[100],123,0,4,1000,3)),
			fromStringArray(fillArray(new String[10],224,0,2,1000,3)));
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsSelf1() {
        ListView list = fromStringArray(fillArray(new String[100],123,0,4,1000,3));
        checkMergeLists(list,list);
    }

    /**
     * tests mergeLists(List first, List second)
     * creates a specific world and check the result against a given (hard-code defined) string
     */		
    @Test(timeout=1000) @TestPenalty(penalty=-5)
    public void testMergeListsSelf2() {
        ListView list = new ListView();
        checkMergeLists(list,list);
    }
}
