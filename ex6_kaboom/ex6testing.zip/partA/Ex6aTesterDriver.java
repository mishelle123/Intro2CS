import org.junit.runner.Result;

import org.junit.runner.JUnitCore;
import il.ac.huji.cs.intro.junit.internal.IntroListener;
import org.junit.internal.TextListener;

/**
 * Driver for Ex6 testers.
 * 
 * @author Intro2cs team
 */
public class Ex6aTesterDriver {

    /**
     * Runs the three testers.
     * @param args ignored.
     */
    public static void main(String[] args) {
        
        JUnitCore junit = new JUnitCore();
        junit.addListener(new IntroListener(System.out));
        Result res=junit.run(PointTester.class,GameTester.class,SelfTester.class);
        System.exit(res.wasSuccessful() ? 0 : 1);
    }
}
