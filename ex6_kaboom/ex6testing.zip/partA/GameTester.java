import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import java.util.Random;

/**
 * Automatic tests for the Point class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class GameTester {

    private static final double EPSILON = 0.001;

    private static final int LEFT = -1;
    private static final int RIGHT = 1;

    private static final double GAME_WIDTH = 300;
    private static final double GAME_HEIGHT = 500;
    
    private static final double BOMBER_WIDTH = 20;
    private static final double BOMBER_HEIGHT = 15;
    private static final double BOMBER_TOP_LEFT_Y = GAME_HEIGHT/10;	
    private static final double BOMBER_STARTING_TOP_LEFT_X = (GAME_WIDTH-BOMBER_WIDTH)/4;
    private static final double BOMBER_STEP_SIZE = 3;
	
    private static final double BUCKET_WIDTH = 140;	
    private static final double BUCKET_HEIGHT = 40;
    private static final double BUCKET_STARTING_TOP_LEFT_X = (GAME_WIDTH-BUCKET_WIDTH)/4;
    private static final double BUCKET_TOP_LEFT_Y = GAME_HEIGHT - BUCKET_HEIGHT - GAME_HEIGHT/22;
    private static final double BUCKET_STEP_SIZE = 5;
	
    private static final double BOMBS_RADIUS = 27;
	
    private static final int TICKS_FOR_NEW_BOMB = 10;
    private static final int MIN_TICKS_FOR_DIRECTION_CHANGE = 30;
    private static final int MAX_TICKS_FOR_DIRECTION_CHANGE = 150;

    private static final int POINTS_PER_BOMB = 15;

    private static final double BOMBS_STARTING_Y = BOMBER_TOP_LEFT_Y+BOMBER_HEIGHT;

    private static final double BOMB_STEP = 2;

    private static int failedTests=0;
    private Game game1;
    GameParams params;

    private static void addFailedTest() {
        failedTests++;
    }
        
    private static void passTest() {
        failedTests--;
    }

    static int getFailedTests() {
        return failedTests;
    }


    
    @Before
    public void setUp() {
        
        params = new GameParams();
        params.setGameHeight(GAME_HEIGHT);
        params.setGameWidth(GAME_WIDTH);
                    
        params.setBomberHeight(BOMBER_HEIGHT);
        params.setBomberWidth(BOMBER_WIDTH);		
        params.setBomberSpeed(BOMBER_STEP_SIZE);
        params.setBomberInitialTopLeftX(BOMBER_STARTING_TOP_LEFT_X);
        params.setBomberTopLeftY(BOMBER_TOP_LEFT_Y);
        
        params.setBombsRadius(BOMBS_RADIUS);
        params.setBombsInitialY(BOMBS_STARTING_Y);
        params.setBombsSpeed(BOMB_STEP);
        
        params.setBucketHeight(BUCKET_HEIGHT);
        params.setBucketWidth(BUCKET_WIDTH);		
        params.setBucketInitialTopLeftX(BUCKET_STARTING_TOP_LEFT_X);
        params.setBucketTopLeftY(BUCKET_TOP_LEFT_Y);
        params.setBucketSpeed(BUCKET_STEP_SIZE);		
        
        params.setMaxStepsTillDirectionChange(MAX_TICKS_FOR_DIRECTION_CHANGE);
        params.setMinStepsTillDirectionChange(MIN_TICKS_FOR_DIRECTION_CHANGE);
        params.setPointsPerBomb(POINTS_PER_BOMB);
        params.setBombsFrequency(TICKS_FOR_NEW_BOMB);
        
        game1 = new Game(params);       
    }
    

    /**
     * Tests the bucket's dimensions and movment
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testBucket() {
	addFailedTest();

        Rectangle bucket1 = game1.getBucket();
        double x = bucket1.getTopLeft().getX();
        double y = bucket1.getTopLeft().getY();
        assertEquals("Bucket's starting position, x coordinate, is wrong",BUCKET_STARTING_TOP_LEFT_X, x,EPSILON);
        assertEquals("Bucket's starting position, y coordinate, is wrong",BUCKET_TOP_LEFT_Y, y,EPSILON);

        game1.moveBucketLeft(); game1.moveBucketLeft();
        bucket1 = game1.getBucket();
        x = bucket1.getTopLeft().getX();
        y = bucket1.getTopLeft().getY();
        assertEquals("Bucket's position (x) after moving left is wrong",BUCKET_STARTING_TOP_LEFT_X-2*BUCKET_STEP_SIZE, x,EPSILON);
        assertEquals("Bucket's position (y) after moving left is wrong",BUCKET_TOP_LEFT_Y, y,EPSILON);

        double w = bucket1.getWidth();
        double h = bucket1.getHeight();
        assertEquals("Bucket's width is wrong",w, BUCKET_WIDTH,EPSILON);
        assertEquals("Bucket's height is wrong",h, BUCKET_HEIGHT,EPSILON);

        game1.moveBucketRight(); game1.moveBucketRight(); game1.moveBucketRight();
        bucket1 = game1.getBucket();
        x = bucket1.getTopLeft().getX();
        y = bucket1.getTopLeft().getY();
        assertEquals("Bucket's position (x) after moving right is wrong",BUCKET_STARTING_TOP_LEFT_X+BUCKET_STEP_SIZE, x,EPSILON);
        assertEquals("Bucket's position (y) after moving right is wrong",BUCKET_TOP_LEFT_Y, y,EPSILON);

        passTest();
    }

    /**
     * Tests the bombers dimensions and movement
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testBomber() {
	addFailedTest();

        Rectangle bomber = game1.getBomber();
        double x = bomber.getTopLeft().getX();
        double y = bomber.getTopLeft().getY();
        assertEquals("Bomber's starting position, x coordinate, is wrong",BOMBER_STARTING_TOP_LEFT_X, x,EPSILON);
        assertEquals("Bomber's starting position, y coordinate, is wrong",BOMBER_TOP_LEFT_Y, y,EPSILON);

        game1.step(); game1.step();
        bomber = game1.getBomber();
        x = bomber.getTopLeft().getX();
        y = bomber.getTopLeft().getY();
        // we know that the bomber must move left
        assertEquals("Bomber's position (x) after two steps is wrong",BOMBER_STARTING_TOP_LEFT_X-2*BOMBER_STEP_SIZE, x,EPSILON);
        assertEquals("Bomber's position (y) after two steps is wrong",BOMBER_TOP_LEFT_Y, y,EPSILON);

        double w = bomber.getWidth();
        double h = bomber.getHeight();
        assertEquals("Bomber's width is wrong",w, BOMBER_WIDTH,EPSILON);
        assertEquals("Bomber's height is wrong",h, BOMBER_HEIGHT,EPSILON);
        passTest();
    }


    /**
     * Tests that the bomber changes its direction when it hits the wall
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testDirectonChange() {
	addFailedTest();

        int repNum = 10;
        int ticksToWall = (int) (BOMBER_STARTING_TOP_LEFT_X/BOMBER_STEP_SIZE) + 1;
        int ticksToSecondWall = (int) ((GAME_WIDTH-BOMBER_WIDTH)/BOMBER_STEP_SIZE);
        params.setMinStepsTillDirectionChange(10*ticksToWall);
        params.setMaxStepsTillDirectionChange(20*ticksToWall);
        for (int i=0; i<repNum; ++i) {
            Game g = new Game(params);
            for (int t=0; t<ticksToWall; ++t, g.step());
            Rectangle bomber = g.getBomber();
            double x1 = bomber.getTopLeft().getX();
            g.step(); g.step();
            bomber = g.getBomber();
            double x2 = bomber.getTopLeft().getX();
            assertTrue("The bomber's direction wasn't changed when it got to the left border of the game (or was changed before the right time)",x2>x1);
            for (int t=0; t<ticksToSecondWall-5; ++t, g.step());
            bomber = g.getBomber();
            x1 = bomber.getTopLeft().getX();
            g.step();             
            bomber = g.getBomber();
            x2 = bomber.getTopLeft().getX();
            assertTrue("Problem in the bomber's movement to the right wall",x2>x1);
            for (int t=0; t<5; ++t, g.step());
            bomber = g.getBomber();
            x1 = bomber.getTopLeft().getX();
            g.step();             
            bomber = g.getBomber();
            x2 = bomber.getTopLeft().getX();
            assertTrue("The bomber's direction wasn't changed when it got to the right border of the game (or was changed before the right time)",x1>x2);
        }
        passTest();
    }

    /**
     * Tests that the bomber change its direction (randomly) within the right range 
     **/
    @Test (timeout=1000) @TestPenalty(penalty=3)
    public void testRandomDirectionChange() {
	addFailedTest();

        int repNum = 10;
        int curMinTicksForDirectionChange = 5;
        int curMaxTicksForDirectionChange = 10;
        int direction = LEFT;
        int ticksFromLastChange = 0;
        int dirChangeCount = 0;
        params.setMinStepsTillDirectionChange(curMinTicksForDirectionChange);
        params.setMaxStepsTillDirectionChange(curMaxTicksForDirectionChange);
        params.setGameWidth(curMaxTicksForDirectionChange*BOMBER_WIDTH*(repNum*2));        
        Game g = new Game(params);
        Rectangle bomber = g.getBomber();
        double x1 = bomber.getTopLeft().getX();

        while (dirChangeCount<repNum) {
            g.step();
            bomber = g.getBomber();
            double x2 = bomber.getTopLeft().getX();
            ticksFromLastChange++;
            if ((direction==LEFT && x2>=x1) || (direction==RIGHT && x2<=x1)) {
                assertTrue("Number of ticks for the bomber's direction change was not in the right interval (change occurred after " 
                           + ticksFromLastChange + " ticks)", 
                           ticksFromLastChange>=(curMinTicksForDirectionChange-2) && 
                           ticksFromLastChange<=(curMaxTicksForDirectionChange+2));
                direction *= -1;
                ticksFromLastChange = 0;
                dirChangeCount++;
            }
            x1 = x2;
        }
        passTest();
    }

    /**
     * Test that the direction change of the bomber is indeed random by comparing two game instances
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testRandomDirectonChange2() {
	addFailedTest();
        int curMinTicksForDirectionChange = 5;
        int curMaxTicksForDirectionChange = 10;
        int repNum =curMaxTicksForDirectionChange*100;
        int direction = LEFT;
        boolean sameDirChanges = true;
        params.setMinStepsTillDirectionChange(curMinTicksForDirectionChange);
        params.setMaxStepsTillDirectionChange(curMaxTicksForDirectionChange);
        params.setGameWidth(curMaxTicksForDirectionChange*BOMBER_WIDTH*(repNum*2));        
        Game g = new Game(params), g2 = new Game(params);        
        Rectangle bomber1 = g.getBomber(), bomber2 = g2.getBomber();
        double x11 = bomber1.getTopLeft().getX();
        double x21 = bomber2.getTopLeft().getX();

        int curItr = 0;
        while (sameDirChanges && curItr<repNum) {
            curItr++;
            g.step(); g2.step();
            bomber1 = g.getBomber(); bomber2 = g2.getBomber();
            double x12 = bomber1.getTopLeft().getX();
            double x22 = bomber2.getTopLeft().getX();

            if ((direction==LEFT && x12>=x11) || (direction==RIGHT && x12<=x11)) {
                // bomber of game change direction, now we check if also the bomber of game2 changed direction
                if ((direction==LEFT && x22>=x21) || (direction==RIGHT && x22<=x21)) {
                    direction *= -1;
                }
                else {
                    sameDirChanges = false;
                }
            }
            x11 = x12; x21 = x22;
        }
        assertFalse("Bombers changed direction at the same time in two different games (many times)",
                    sameDirChanges);
        passTest();
    }


    /**
     * Tests the score starts from 0 and get updated correctly
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testScore() {
	addFailedTest();

        params.setBucketInitialTopLeftX(BOMBER_STARTING_TOP_LEFT_X);
        int ticksNeeded = (int)((params.getBucketTopLeftY()-params.getBombsInitialY())/params.getBombsSpeed());
        params.setBombsFrequency(ticksNeeded+10);
        Game g = new Game(params);
        assertEquals("Starting score wasn't 0",g.getScore(),0);
        for (int t=0; t<ticksNeeded+2; ++t, g.step());
        assertEquals("Score after catching first bomb wasn't correct",g.getScore(),params.getPointsPerBomb());

        passTest();
    }

    /**
     * Test game is over only when a bomb reaches the floor
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testGameOver() {
	addFailedTest();

        params.setGameWidth(params.getBomberInitialTopLeftX()+params.getBomberWidth()+100);
        params.setBucketInitialTopLeftX(params.getBomberInitialTopLeftX()+params.getBomberWidth()+10);
        int ticksNeeded = (int)((params.getGameHeight()-params.getBombsInitialY())/params.getBombsSpeed());
        params.setBombsFrequency(ticksNeeded+10);
        Game g = new Game(params);
        assertFalse("Game is over after creation",g.isOver());
        for (int t=0; t<ticksNeeded+2; ++t, g.step());
        assertTrue("Game isn't over after a bomb reached the ground",g.isOver());

        params.setBucketInitialTopLeftX(BOMBER_STARTING_TOP_LEFT_X);
        Game g2 = new Game(params);
        assertFalse("Game is over after creation",g2.isOver());
        for (int t=0; t<ticksNeeded+2; ++t, g2.step());
        assertFalse("Game is over after a bomb was caught",g2.isOver());
    }


    /**
     * Tests the number of bombs increases in the right time and decreases after they are caught
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testBombs() {
	addFailedTest();

        int curTicksForNewBomb = 10;
        params.setBucketInitialTopLeftX(params.getBomberInitialTopLeftX());
        params.setBomberTopLeftY(0);
        params.setBombsInitialY(50);
        params.setGameHeight(1000);
        params.setBombsSpeed(10);
        params.setBucketTopLeftY(905);
        params.setBombsFrequency(10);
        Game g = new Game(params);
        g.step();
        assertEquals("More or less than one bomb after game was just started",g.numberOfBombs(),1);
        Circle bomb0 = g.getBomb(0);
        assertEquals("Bomb's radius isn't as was set in the GameParams",bomb0.getRadius(),params.getBombsRadius(),EPSILON);


        int ticksNeeded = (int)((params.getBucketTopLeftY()-params.getBombsInitialY())/params.getBombsSpeed());
        int expectedNumOfBombs = 0;
        for (int t=1; t<ticksNeeded-2; ++t, g.step()) {
            if ((t-2)%curTicksForNewBomb==0) {
                assertEquals("Number of bombs is wrong after several iterations of the game",g.numberOfBombs(),++expectedNumOfBombs);
            }
        }
        for (int t=0; t<5; ++t, g.step());
        assertEquals("Number of bombs is wrong after several iterations of the game",g.numberOfBombs(),expectedNumOfBombs-1);

        passTest();
    }

    
    /**
     * Checks that the game doesn't return its internal state
     **/ 
    @Test (timeout=1000) @TestPenalty(penalty=-8)
    public void testEncapsulation() {
	addFailedTest();

        Rectangle bucket = game1.getBucket(), bucket2 = game1.getBucket(), bucket3;
        Rectangle bomber = game1.getBomber(), bomber2  = game1.getBomber(), bomber3;
        Circle bomb = game1.getBomb(0), bomb2 = game1.getBomb(0), bomb3;
        
        assertFalse("Problem with the encapsulation of the bucket in the game",bucket==bucket2);
        assertFalse("Problem with the encapsulation of the bomber in the game",bomber==bomber2);
        assertFalse("Problem with the encapsulation of the first bomb in the game",bomb==bomb2);

        bucket.setWidth(params.getBucketWidth()+10);
        bucket3 = game1.getBucket();
        assertEquals("Problem with the encapsulation of the bucket in the game", 
                     bucket3.getWidth(), params.getBucketWidth(),EPSILON); 
        bomber.setWidth(params.getBomberWidth()+10);
        bomber3 = game1.getBomber();
        assertEquals("Problem with the encapsulation of the bomber in the game", 
                     bomber3.getWidth(), params.getBomberWidth(),EPSILON); 

        bomb.setRadius(params.getBombsRadius()+10);
        bomb3 = game1.getBomb(0);
        assertEquals("Problem with the encapsulation of the first bomb in the game", 
                     bomb3.getRadius(), params.getBombsRadius(),EPSILON); 

        passTest();
    }
}
