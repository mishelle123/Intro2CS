import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.runner.JUnitCore;

/**
 * Automatic tests for the Point class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class SelfTester {

    @Test (timeout=1000) @TestPenalty(penalty=-20)
    public void testSelfCircle() {
        assertTrue("Your Circle class did not pass your testers.", JUnitCore.runClasses(CircleTester.class).wasSuccessful());
    }

    @Test (timeout=1000) @TestPenalty(penalty=-20)
    public void testSelfRectangle() {
        assertTrue("Your Rectangle class did not pass your testers.", JUnitCore.runClasses(RectangleTester.class).wasSuccessful());
    }
}
