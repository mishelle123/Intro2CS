import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.runner.JUnitCore;

/**
 * Automatic tests for the Point class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class CircleTesterTester {

    @Test (timeout=5000) @TestPenalty(penalty=-25)
    public void testCircleOK() {
        Circle.setType(0);
        assertTrue("Correct Circle class should pass your testers.", JUnitCore.runClasses(CircleTester.class).wasSuccessful());
    }

    private static void expectBadClass(int i) {
        Circle.setType(i);
        assertFalse("Incorrect Circle class should not pass your testers.", JUnitCore.runClasses(CircleTester.class).wasSuccessful());
    }
   
    @Test (timeout=5000) @TestPenalty(penalty=-9)                                                  
    public void testCircleCenterCtor() {
        expectBadClass(1);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-9)                                                  
    public void testCircleCopyCtorCenter() {
        expectBadClass(2);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-9)                                                  
    public void testCircleCopyCtorRadius() {
        expectBadClass(3);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-9)                                                  
    public void testCircleCtor() {
        expectBadClass(4);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-9)                                                  
    public void testCircleRadiusCtor() {
        expectBadClass(5);
    }
}


