import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import org.junit.runner.JUnitCore;

/**
 * Automatic tests for the Point class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class RectangleTesterTester {

    @Test (timeout=5000) @TestPenalty(penalty=-25)
    public void testRectangleOK() {
        Rectangle.setType(0);
        assertTrue("Correct Rectangle class should pass your testers.", JUnitCore.runClasses(RectangleTester.class).wasSuccessful());
    }

    private static void expectBadClass(int i) {
        Rectangle.setType(i);
        assertFalse("Incorrect Rectangle class should not pass your testers.", JUnitCore.runClasses(RectangleTester.class).wasSuccessful());
    }
   
    @Test (timeout=5000) @TestPenalty(penalty=-6)                                                  
    public void testRectangleCopyCtor() {
        expectBadClass(1);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-6)                                                  
    public void testRectangleGetCornersCounterClockwise() {
        expectBadClass(2);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-6)                                                  
    public void testRectangleGetCornersYaxis() {
        expectBadClass(3);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-6)                                                  
    public void testRectangleIsPointInside() {
        expectBadClass(4);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-6)                                                  
    public void testRectangleWidthHeight() {
        expectBadClass(5);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-6)                                                  
    public void testRectangleXaxis() {
        expectBadClass(6);
    }

    @Test (timeout=5000) @TestPenalty(penalty=-6)                                                  
    public void testRectangleYaxis() {
        expectBadClass(7);
    }
}


