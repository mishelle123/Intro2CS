import il.ac.huji.cs.intro.ex1.*;

import java.util.Iterator;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.TestRank;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import static org.junit.Assume.*;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

@RunWith(IntroJUnit4ClassRunner.class)
public class TurtleTester {

    /**
     * The maximal 
     * distance between two points that will be considered as one.
     */
    public static final double EPSILON = 0.1;

    private static PrintStream logger=null;

    /**
     * Optional log target for more information
     */
    public static void setLog(String logFile) {
        if(logFile != null) {
            try {
                logger = new PrintStream(new FileOutputStream(logFile,true));
            } catch (IOException e) {
                System.err.println("Couldn't open log file for writing");
            }
        }
    }


    /**
     * The expected line of the body.
     */
    @SuppressWarnings("serial")
    public static final TurtleLineSet EXPECTED_BODY_LINES = new TurtleLineSet() {
            {
                add(new TurtleLine(100.0, 0.0, 100.0, 100.0, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(-100.0, 0.0, -100.0, 100.0, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(0.0, -80.0, 0.0, 0.0, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(100.0, 50.0, 180.0, 50.0, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(-180.0, 50.0, -100.0, 50.0, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(-100.0, 100.0, 100.0, 100.0, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(0.0, 100.0, 0.0, 180.0, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(-100.0, 0.0, 100.0, 0.0, 2, IntroTurtle.Color.WHITE));
            }
        };

    /**
     * The expected line of the head.
     */
    @SuppressWarnings("serial")
    public static final TurtleLineSet EXPECTED_HEAD_LINES = new TurtleLineSet() {
            {
                add(new TurtleLine(85.9, -14.1, 124.5, -24.5, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(85.9, -14.1, 114.1, 14.1, 2, IntroTurtle.Color.WHITE));
                add(new TurtleLine(114.1, 14.1, 124.5, -24.5, 2, IntroTurtle.Color.WHITE));
            }
        };

    /**
     * The expected line of the tail.
     */
    @SuppressWarnings("serial")
    public static final TurtleLineSet EXPECTED_TAIL_LINES = new TurtleLineSet() {
            {
                add(new TurtleLine(-175.5, 193.3, -100.0, 100.0, 5, IntroTurtle.Color.GREEN));
                add(new TurtleLine(-168.8, 198.3, -100.0, 100.0, 5, IntroTurtle.Color.VIOLET));
                add(new TurtleLine(-181.8, 187.8, -100.0, 100.0, 5, IntroTurtle.Color.ORANGE));
                add(new TurtleLine(-172.2, 195.8, -100.0, 100.0, 5, IntroTurtle.Color.BLUE));
                add(new TurtleLine(-184.9, 184.9, -100.0, 100.0, 5, IntroTurtle.Color.RED));
                add(new TurtleLine(-178.7, 190.6, -100.0, 100.0, 5, IntroTurtle.Color.YELLOW));
            }
        };

    @SuppressWarnings("serial")
    public static final TurtleLineSet ENTIRE_PICTURE= new TurtleLineSet() {
            {
                addAll(EXPECTED_BODY_LINES);
                addAll(EXPECTED_HEAD_LINES);
                addAll(EXPECTED_TAIL_LINES);
            }
        };

    /**
     * Run the students' program without GUI.
     */
    @BeforeClass
    public static void runHelloTurtle() {
        IntroTurtle.setGui(false);
    }

    /**
     * Checks if all the lines in subset are contains in set. 
     * If not all lines in subset are contains in set - print a message about the first one that isn't found.
     * 
     * @param msg the message to print.
     * @param set lines set.
     * @param subset lines subset.
     */
    private void checkApproximatlyContained(String msg, TurtleLineSet set, TurtleLineSet subset) {
        for (TurtleLine line : subset) {
            assertTrue(msg + ": " + line, approximatlyContained(set, line));
        }
    }	

    /**
     * Check if set contains a line with the same color and width as the given line 
     and with coordinates very close to those of the given line.
     * 
     * @param line the given line.
     * @param set the given set.
     * @return true iff this set contains the given line approximately.
     */
    private boolean approximatlyContained(TurtleLineSet set, TurtleLine line) {
        Iterator<TurtleLine> iter = set.iterator();
        while (iter.hasNext()) {
            if (approximatelyEquals(iter.next(), line)){
                return true;   
            }
        }
        return false;
    }

    /**
     * Return true iff both lines have the same color and width and very close coordinates.
     * 
     * @param one the first line to compare.
     * @param two the other line to compare.
     * @return true iff both lines have the same color and width and very close coordinates.
     */
    private boolean approximatelyEquals(TurtleLine one, TurtleLine two) {
        if (Math.abs(one.getBeginX()-two.getBeginX()) > EPSILON)
            return false;
        if (Math.abs(one.getBeginY()-two.getBeginY()) > EPSILON)
            return false;
        if (Math.abs(one.getEndX()-two.getEndX()) > EPSILON)
            return false;
        if (Math.abs(one.getEndY()-two.getEndY()) > EPSILON)
            return false;
        if (one.getColor() != two.getColor())
            return false;
        if (one.getWidth() != two.getWidth())
            return false;
        return true;
    }

    private static boolean skipAll=false;

    /**
     * Checks if main completes
     */
    @TestRank(rank=-100)
    @TestPenalty(penalty=-100)
    @Test(timeout=1000)
    public void testCompletes() {
        skipAll=true;
        HelloTurtle.main(null);
        if(logger!=null) {
            logger.println("Expected:");
            logger.println(ENTIRE_PICTURE);
            logger.println("Actual:");
            logger.println(IntroTurtle.getLineSet());
        }
        skipAll=false;
    }
    
    /**
     * Checks if all the body lines are found in the students' picture.
     */
    @TestPenalty(penalty=-20)
    @Test(timeout=1000)
    public void testBody() {
        assumeTrue(!skipAll);
        checkApproximatlyContained("Missing body line", IntroTurtle.getLineSet(), EXPECTED_BODY_LINES);
    }

    /**
     * Checks if all the tail lines are found in the students' picture.
     */
    @TestPenalty(penalty=-20)
    @Test(timeout=1000)
    public void testTail() {
        assumeTrue(!skipAll);
        checkApproximatlyContained("Missing tail line", IntroTurtle.getLineSet(), EXPECTED_TAIL_LINES);
    }

    /**
     * Checks if all the head lines are found in the students' picture.
     */
    @TestPenalty(penalty=-20)
    @Test(timeout=1000)
    public void testHead() {
        assumeTrue(!skipAll);
        checkApproximatlyContained("Missing head line", IntroTurtle.getLineSet(), EXPECTED_HEAD_LINES);
    }

    /**
     * Check if there are no additional lines in the students' picture.
     */
    @TestPenalty(penalty=-20)
    @Test(timeout=1000)
    public void testNoExtraLines() {
        assumeTrue(!skipAll);
        TurtleLineSet userLineSet = IntroTurtle.getLineSet();
        checkApproximatlyContained("Unexpected line drawn", ENTIRE_PICTURE, userLineSet);
        assertTrue("too many lines, possibly duplicated line", userLineSet.size()==ENTIRE_PICTURE.size());
    }

    /**
     * Checks that the turtle was hidden in the end of the program.
     */
    @TestPenalty(penalty=-20)
    @Test(timeout=1000)
    public void testHidden() {
        assumeTrue(!skipAll);
        assertTrue("Turtle isn't hidden", IntroTurtle.isHidden());
    }

}
