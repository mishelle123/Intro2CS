import org.junit.runner.Result;

import org.junit.runner.JUnitCore;
import il.ac.huji.cs.intro.junit.internal.IntroListener;




public class Ex1TesterDriver {

    public static void main(String[] args) {
	JUnitCore junit = new JUnitCore();
	junit.addListener(new IntroListener(System.out));
        if(args.length>0) {
            TurtleTester.setLog(args[0]);
        }
	Result res=junit.run(TurtleTester.class);
	System.exit(res.wasSuccessful() ? 0 : 1);
    }

}
