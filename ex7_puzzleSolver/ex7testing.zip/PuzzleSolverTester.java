import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;


/**
 * Automatic tests for the TetrisSolver class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class PuzzleSolverTester {
    

    private static PuzzlePiece[] getRepeatedSinglePiece(int num) {
	PuzzlePiece[] arr=new PuzzlePiece[num];
	for(int i=0;i<num;i++) arr[i]=new PuzzlePiece(new boolean[][]{{true}});
	return arr;
    }

    private static void checkSolving(int width, int height, PuzzlePiece[] pieces, BlackPair[] black, boolean solvable, boolean unsolvable) {
	int[][] grid = new int[height][width];
	PuzzleData data = new PuzzleData(width,height,pieces);
	for(BlackPair b : black) {
	    grid[b.y][b.x]=-1;
	    data.setSquare(b.x,b.y,-1);
	}
	boolean res=solve(data);
	assertTrue("Could not solve board.",res || unsolvable);
	assertTrue("Solved unsolvable board.",! res || solvable);
	if(res) {
	    assertTrue("Illegal solution",isSolutionLegal(data,grid));
	}
	else {
	    assertArrayEquals("Board in wrong state after failed solve.",grid,data.getBoard());
	}
    }

    private static void assertSolvable(int width, int height, PuzzlePiece[] pieces, BlackPair[] black) {
	checkSolving(width, height, pieces, black, true, false);
    }


    private static void assertUnsolvable(int width, int height, PuzzlePiece[] pieces, BlackPair[] black) {
	checkSolving(width, height, pieces, black, false, true);
    }

    private static void assertOptionalSolve(int width, int height, PuzzlePiece[] pieces, BlackPair[] black) {
	checkSolving(width, height, pieces, black, true, true);
    }

    /**
     * Tests Tetris Solver, board 1
     **/
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleSolverStops() {
	assertSolvable(8,8,
		       getRepeatedSinglePiece(64),
		       new BlackPair[0]);
    }

    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleSolverStopsOptionally() {
	assertOptionalSolve(8,8,
		       getRepeatedSinglePiece(54),
		       new BlackPair[0]);
    }

    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleSolverStopsWithBlackCorners() {
	assertSolvable(9,10,
		       getRepeatedSinglePiece(86),
		       new BlackPair[]{
			   new BlackPair(0,0),
			   new BlackPair(8,0),
			   new BlackPair(0,9),
			   new BlackPair(8,9),
		       });
    }


    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleSolverStopsWithBlackMiddle() {
	assertSolvable(10,8,
		       getRepeatedSinglePiece(76),
		       new BlackPair[]{
			   new BlackPair(1,1),
			   new BlackPair(2,3),
			   new BlackPair(9,4),
			   new BlackPair(5,6),
		       });
    }


    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleTetrominoes4x5() {
	assertUnsolvable(4,5,
		       new PuzzlePiece[]{
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('L')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('O')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('S')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('T')[0][0]))
		       },
		       new BlackPair[0]);
    }
    
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleTetrominoes4x6Black() {
	assertSolvable(4,6,
		       new PuzzlePiece[]{
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('L')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('O')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('S')[0][0])),
			   new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('T')[0][0]))
		       },
		       new BlackPair[]{
			   new BlackPair(0,0),
			   new BlackPair(0,3),
			   new BlackPair(0,4),
			   new BlackPair(1,3),
		       });
    }
    
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleTetrominoes4x6Optional() {
	assertOptionalSolve(4,6,
			    new PuzzlePiece[]{
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('L')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('O')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('S')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('T')[0][0]))
			    },
			    new BlackPair[]{
			    });
    }
    

    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleTetrominoesIsNoRoom1() {
	assertUnsolvable(1,19,
			    new PuzzlePiece[]{
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][0])),
			    },
			    new BlackPair[]{
			    });
    }
    
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleTetrominoesIsNoRoom2() {
	assertUnsolvable(1,19,
			    new PuzzlePiece[]{
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][1])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][1])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][1])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][1])),
				new PuzzlePiece(PuzzleTesterUtils.int2bool(PuzzleTesterUtils.getTetromino('I')[0][1])),
			    },
			    new BlackPair[]{
			    });
    }
    
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleNotPolyominoes() {
	assertSolvable(3,3,
		       new PuzzlePiece[]{
			   new PuzzlePiece(new boolean[][]{{true,false,true},{false,true,false},{true,false,true}}),
			   new PuzzlePiece(new boolean[][]{{false,true,false},{true,false,true},{false,true,false}})
		       },
		       new BlackPair[]{
		       });
    }
    
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleLargePieceUnsolvable1dim() {
	assertUnsolvable(3,3,
			 new PuzzlePiece[]{
			     new PuzzlePiece(new boolean[][]{{true,true,true},{true,true,true},{true,true,true},{true,true,true}}),
			 },
			 new BlackPair[]{
			 });
    }
    
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleLargePieceUnsolvable2dim() {
	assertUnsolvable(3,3,
			 new PuzzlePiece[]{
			     new PuzzlePiece(new boolean[][]{{true,true,true,true},{true,true,true,true},{true,true,true,true},{true,true,true,true}}),
			 },
			 new BlackPair[]{
			 });
    }
    
    @Test (timeout=3000) @TestPenalty(penalty=-8)
    public void testPuzzleLargePieceSolvable() {
	assertSolvable(3,4,
			 new PuzzlePiece[]{
			     new PuzzlePiece(new boolean[][]{{true,true,true},{true,true,true},{true,true,true},{true,true,true}}),
			 },
			 new BlackPair[]{
			 });
    }
    



    private static boolean isSolutionLegal(PuzzleData data, int [][] blackSquares) {

	// check black squares
	if (blackSquares != null && blackSquares.length>0) {
	    for (int i=0;i<blackSquares.length ;i++)  {
		for (int j=0;j<blackSquares[0].length ;j++)  {
		    if ((data.getSquare(j,i)==-1) != (blackSquares[i][j]==-1)) {
			return false;
		    }
		}
	    }
	}
	// check all pieces are in place
	PuzzlePiece[] pieces=data.getPieces();
	for (int i=0; i<pieces.length; i++) {
	    if (!isThePieceLegal(data,i+1))
		return false;
	}
	return true;
    }

    private static boolean isThePieceLegal(PuzzleData data, int p) {
	boolean [][] temp = new boolean[data.getBoardHeight()][data.getBoardWidth()];
	int startX=data.getBoardWidth(), startY=data.getBoardHeight(), endX=0, endY=0;
	for (int i=0; i<data.getBoardHeight(); i++) {
	    for (int j=0; j<data.getBoardWidth(); j++) {
		if (data.getSquare(j,i) == p) {
		    temp[i][j] = true;
		    startX = Math.min(startX, j);
		    startY = Math.min(startY, i);
		    endX = Math.max(endX, j);
		    endY = Math.max(endY, i);
		}
		else {
		    temp[i][j] = false;
		}
	    }
	}
	boolean [][] boardPiece = new boolean[endY-startY+1][endX-startX+1];	
	for (int i=0; i<boardPiece.length; i++) { 
	    for (int j=0; j<boardPiece[0].length; j++) {
		boardPiece[i][j] = temp[startY+i][startX+j];
	    }
	}
	
	PuzzlePiece pieceList = data.getPiece(p-1);
	for (int i=0; i<pieceList.getNumberOfConformations(); i++) {
	    if (equals(pieceList.getConformation(i),boardPiece))
		return true;
	}
	
	return false;
    }

	private static boolean equals(boolean [][] p1, boolean [][] p2) {
		boolean same = false;
		int rStart = p1.length;
		int cStart = p1[0].length;
		int rNew = p2.length;
		int cNew = p2[0].length;
		if (rStart==rNew && cStart==cNew) {
			same = true;
			for (int i=0; i<rStart; i++) {
				for (int j=0; j<cStart; j++) {
					if (p1[i][j] != p2[i][j])
						same = false;
				}
			}
		}
		return same;
	}

	private static boolean solve(PuzzleData data) {
	    return new PuzzleSolver(data).solve(new MockPuzzle(data));
	}

	/**
	 * Mocks TetrisGUI class. Checks if given solutions are legal.
	 * 
	 * @author intro2cs team
	 *
	 */
	private static class MockPuzzle extends PuzzleGUI {

		/**
		 * 
		 */
	    private static final long serialVersionUID = 1L;

	    private int[][] grid;

	    private MockPuzzle(PuzzleData data) {
		grid=new int[data.getBoardHeight()][data.getBoardWidth()];
		for(int i=0;i<grid.length;i++)
		    for(int j=0;j<grid[0].length;j++)
			grid[i][j]=data.getSquare(j,i);
	    }

	    private boolean inPiece=false;
	    @Override public void endPiece() {
	    	assertTrue("Ended piece when not in piece.",inPiece);
	    	inPiece=false;
	    }
	    @Override public void startPiece(int color) {		
	    	assertFalse("Started piece when already in piece.",inPiece);
	    	inPiece=true;
	    }

	    @Override public void setStatusMessage(String message) {}

	    private boolean startedColoring=false;
	    @Override public void colorSquare(int x, int y,int color) {
                if(color>0) startedColoring=true;
                if(startedColoring) {
                    assertFalse("Drawing a black cell", color<0);
                    assertFalse("Recoloring a black cell",grid[y][x]<0);
                    assertFalse("Recoloring a colored cell",color>0 && grid[y][x]>0);
                    assertFalse("Erasing an empty cell",color==0 && grid[y][x]==0);
                }
		grid[y][x]=color;
	    }
	}
    private static class BlackPair {
	private final int x;
	private final int y;
	private BlackPair(int x, int y) {
	    this.x=x;
	    this.y=y;
	}
    }
}

