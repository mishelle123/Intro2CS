import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

/**
 * Automatic tests for PuzzlePiece class
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class PuzzlePieceTester {

    private static boolean [][][][] expectedPieces;

    private static void checkBlock(int[][][][] block){
	for(int i=0;i<block.length;i++)
	    for(int j=0;j<block[0].length;j++) {
		checkBlock(block,i,j);
	    }
    }

    private static void checkBlock(int[][][][] block, int flips, int rotates){
	boolean[][] grid=int2bool(block[flips][rotates]);
	PuzzlePiece p=new PuzzlePiece(grid);
	assertTrue("Grid sent to constructor modified",
		   equals(block[flips][rotates],grid));	
	assertEquals("Wrong number of conformations for block "+PuzzleTesterUtils.toString(grid),
		     block.length*block[0].length,p.getNumberOfConformations());
        int order=0;
	for(int i=0;i<block.length;i++)
	    for(int j=0;j<block[0].length;j++) {
		int c1 = (i==flips ? 
			 (block[0].length+j-rotates)%block[0].length :
			 (rotates+j)%block[0].length+block[0].length
			 );
		int c2 = (i==flips ? 
                          (block[0].length+j-rotates)%block[0].length :
                          (rotates+j+2)%block[0].length+block[0].length
                          );
                if(c1!=c2 && order==0) {
                    boolean[][] res1 = p.getConformation(c1);
                    boolean[][] res2 = p.getConformation(c2);
                    assertNotNull(res1);
                    assertNotNull(res2);
                    if(equals(block[i][j],res1)) {
                        order=1;
                    }
                    else if(equals(block[i][j],res2)) {
                        order=2;
                    }
                    else {
                        fail(PuzzleTesterUtils.toString(block[i][j])+
                             " should be conformation "+c1+" or conformation "+c2);
                    }
                }
                else {
                    int c = order==2 ? c2 : c1;
                    boolean[][] res = p.getConformation(c);
                    assertNotNull(res);
                    assertTrue("Wrong conformation for grid: "+PuzzleTesterUtils.toString(grid)+" conformation "+c+
                               ". Expected: "+PuzzleTesterUtils.toString(block[i][j])+" actual: "+PuzzleTesterUtils.toString(res),
                               equals(block[i][j],res));
                }
            }
    }
    /**
     * Tests 
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoF() {
	checkBlock(PuzzleTesterUtils.getPentomino('F'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoI() {
	checkBlock(PuzzleTesterUtils.getPentomino('I'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoL() {
	checkBlock(PuzzleTesterUtils.getPentomino('L'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoN() {
	checkBlock(PuzzleTesterUtils.getPentomino('N'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoP() {
	checkBlock(PuzzleTesterUtils.getPentomino('P'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoT() {
	checkBlock(PuzzleTesterUtils.getPentomino('T'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoU() {
	checkBlock(PuzzleTesterUtils.getPentomino('U'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoV() {
	checkBlock(PuzzleTesterUtils.getPentomino('V'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoW() {
	checkBlock(PuzzleTesterUtils.getPentomino('W'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoX() {
	checkBlock(PuzzleTesterUtils.getPentomino('X'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoY() {
	checkBlock(PuzzleTesterUtils.getPentomino('Y'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPentominoZ() {
	checkBlock(PuzzleTesterUtils.getPentomino('Z'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testTetrominoI() {
	checkBlock(PuzzleTesterUtils.getTetromino('I'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testTetrominoL() {
	checkBlock(PuzzleTesterUtils.getTetromino('L'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testTetrominoO() {
	checkBlock(PuzzleTesterUtils.getTetromino('O'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testTetrominoS() {
	checkBlock(PuzzleTesterUtils.getTetromino('S'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testTetrominoT() {
	checkBlock(PuzzleTesterUtils.getTetromino('T'));
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testNonPolyomino() {
	checkBlock(new int[][][][]{{{{1,0,1},{0,1,0},{1,0,1}}}});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testSingleCell() {
	checkBlock(new int[][][][]{{{{1}}}});
    }
    
    private static boolean[][] int2bool(int[][] arr) {
	if(arr==null) return null;
	boolean[][] res=new boolean[arr.length][];
	for(int i=0;i<arr.length;i++) {
	    if(arr[i]==null) {
		res[i]=null;
	    }
	    else {
		res[i]=new boolean[arr[i].length];
		for(int j=0;j<arr[i].length;j++) {
		    res[i][j]=(arr[i][j]==1 ? true : false);
		}
	    }
	}
	return res;
    }


    private static boolean equals(int [][] p1, boolean [][] p2) {
	if(p1==null && p2==null) return true;
	if(p1==null || p2==null) return false;

	int rStart = p1.length;
	int rNew = p2.length;
	if(rStart!=rNew) return false;

	for (int i=0; i<rStart; i++) {
	    if(p1[i]==null && p2[i]==null) {} // rows are equal
	    else {
		if(p1[i]==null || p2[i]==null || p1[i].length!=p2[i].length)
		    return false;
		for (int j=0; j<p1[i].length; j++) {
		    if ((p1[i][j]==1) != p2[i][j])
			return false;
		}
	    }
	}
	return true;
    }

    private static boolean equals(boolean [][] p1, boolean [][] p2) {
	if(p1==null && p2==null) return true;
	if(p1==null || p2==null) return false;

	int rStart = p1.length;
	int rNew = p2.length;
	if(rStart!=rNew) return false;

	for (int i=0; i<rStart; i++) {
	    if(p1[i]==null && p2[i]==null) {} // rows are equal
	    else {
		if(p1[i]==null || p2[i]==null || p1[i].length!=p2[i].length)
		    return false;
		for (int j=0; j<p1[i].length; j++) {
		    if (p1[i][j] != p2[i][j])
			return false;
		}
	    }
	}
	return true;
    }

}
