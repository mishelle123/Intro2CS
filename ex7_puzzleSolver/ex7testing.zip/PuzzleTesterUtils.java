public class PuzzleTesterUtils {

    static boolean[][] int2bool(int[][] arr) {
	if(arr==null) return null;
	boolean[][] res=new boolean[arr.length][];
	for(int i=0;i<arr.length;i++) {
	    if(arr[i]==null) {
		res[i]=null;
	    }
	    else {
		res[i]=new boolean[arr[i].length];
		for(int j=0;j<arr[i].length;j++) {
		    res[i][j]=(arr[i][j]==1 ? true : false);
		}
	    }
	}
	return res;
    }


    static boolean equals(int [][] p1, boolean [][] p2) {
	if(p1==null && p2==null) return true;
	if(p1==null || p2==null) return false;

	int rStart = p1.length;
	int rNew = p2.length;
	if(rStart!=rNew) return false;

	for (int i=0; i<rStart; i++) {
	    if(p1[i]==null && p2[i]==null) {} // rows are equal
	    else {
		if(p1[i]==null || p2[i]==null || p1[i].length!=p2[i].length)
		    return false;
		for (int j=0; j<p1[i].length; j++) {
		    if ((p1[i][j]==1) != p2[i][j])
			return false;
		}
	    }
	}
	return true;
    }

     static boolean equals(boolean [][] p1, boolean [][] p2) {
	if(p1==null && p2==null) return true;
	if(p1==null || p2==null) return false;

	int rStart = p1.length;
	int rNew = p2.length;
	if(rStart!=rNew) return false;

	for (int i=0; i<rStart; i++) {
	    if(p1[i]==null && p2[i]==null) {} // rows are equal
	    else {
		if(p1[i]==null || p2[i]==null || p1[i].length!=p2[i].length)
		    return false;
		for (int j=0; j<p1[i].length; j++) {
		    if (p1[i][j] != p2[i][j])
			return false;
		}
	    }
	}
	return true;
    }

    //ILOST
     static int[][][][] getTetromino(char c) {
	switch (c) {
	case 'I': return new int[][][][]{{{{1,1,1,1}},{{1},{1},{1},{1}}}};
	case 'L': return new int[][][][]{{{{1,0},{1,0},{1,1}},{{1,1,1},{1,0,0}},{{1,1},{0,1},{0,1}},{{0,0,1},{1,1,1}}},{{{0,1},{0,1},{1,1}},{{1,0,0},{1,1,1}},{{1,1},{1,0},{1,0}},{{1,1,1},{0,0,1}}}};
	case 'O': return new int[][][][]{{{{1,1},{1,1}}}};
	case 'S': return new int[][][][]{{{{1,1,0},{0,1,1}},{{0,1},{1,1},{1,0}}},{{{0,1,1},{1,1,0}},{{1,0},{1,1},{0,1}}}};
	case 'T': return new int[][][][]{{{{1,1,1},{0,1,0}},{{0,1},{1,1},{0,1}},{{0,1,0},{1,1,1}},{{1,0},{1,1},{1,0}}}};
	default: return null;
	}
    }

    //FILNPTUVWXYZ
     static int[][][][] getPentomino(char c) {
	switch (c) {
	case 'F': return new int[][][][]{{{{0,1,1},{1,1,0},{0,1,0}},{{0,1,0},{1,1,1},{0,0,1}},{{0,1,0},{0,1,1},{1,1,0}},{{1,0,0},{1,1,1},{0,1,0}}},{{{1,1,0},{0,1,1},{0,1,0}},{{0,0,1},{1,1,1},{0,1,0}},{{0,1,0},{1,1,0},{0,1,1}},{{0,1,0},{1,1,1},{1,0,0}}}};
	case 'I': return new int[][][][]{{{{1,1,1,1,1}},{{1},{1},{1},{1},{1}}}};
	case 'L': return new int[][][][]{{{{1,0},{1,0},{1,0},{1,1}},{{1,1,1,1},{1,0,0,0}},{{1,1},{0,1},{0,1},{0,1}},{{0,0,0,1},{1,1,1,1}}},{{{0,1},{0,1},{0,1},{1,1}},{{1,0,0,0},{1,1,1,1}},{{1,1},{1,0},{1,0},{1,0}},{{1,1,1,1},{0,0,0,1}}}};
	case 'N': return new int[][][][]{{{{1,1,0,0},{0,1,1,1}},{{0,1},{1,1},{1,0},{1,0}},{{1,1,1,0},{0,0,1,1}},{{0,1},{0,1},{1,1},{1,0}}},{{{0,0,1,1},{1,1,1,0}},{{1,0},{1,0},{1,1},{0,1}},{{0,1,1,1},{1,1,0,0}},{{1,0},{1,1},{0,1},{0,1}}}};
	case 'P': return new int[][][][]{{{{1,1,1},{1,1,0}},{{1,1},{1,1},{0,1}},{{0,1,1},{1,1,1}},{{1,0},{1,1},{1,1}}},{{{1,1,1},{0,1,1}},{{0,1},{1,1},{1,1}},{{1,1,0},{1,1,1}},{{1,1},{1,1},{1,0}}}};
	case 'T': return new int[][][][]{{{{1,1,1},{0,1,0},{0,1,0}},{{0,0,1},{1,1,1},{0,0,1}},{{0,1,0},{0,1,0},{1,1,1}},{{1,0,0},{1,1,1},{1,0,0}}}};
	case 'U': return new int[][][][]{{{{1,1,1},{1,0,1}},{{1,1},{0,1},{1,1}},{{1,0,1},{1,1,1}},{{1,1},{1,0},{1,1}}}};
	case 'V': return new int[][][][]{{{{1,1,1},{1,0,0},{1,0,0}},{{1,1,1},{0,0,1},{0,0,1}},{{0,0,1},{0,0,1},{1,1,1}},{{1,0,0},{1,0,0},{1,1,1}}}};
	case 'W': return new int[][][][]{{{{0,1,1},{1,1,0},{1,0,0}},{{1,1,0},{0,1,1},{0,0,1}},{{0,0,1},{0,1,1},{1,1,0}},{{1,0,0},{1,1,0},{0,1,1}}}};
	case 'X': return new int[][][][]{{{{0,1,0},{1,1,1},{0,1,0}}}};
	case 'Y': return new int[][][][]{{{{0,0,1,0},{1,1,1,1}},{{1,0},{1,0},{1,1},{1,0}},{{1,1,1,1},{0,1,0,0}},{{0,1},{1,1},{0,1},{0,1}}},{{{0,1,0,0},{1,1,1,1}},{{1,0},{1,1},{1,0},{1,0}},{{1,1,1,1},{0,0,1,0}},{{0,1},{0,1},{1,1},{0,1}}}};
	case 'Z': return new int[][][][]{{{{1,1,0},{0,1,0},{0,1,1}},{{0,0,1},{1,1,1},{1,0,0}}},{{{0,1,1},{0,1,0},{1,1,0}},{{1,0,0},{1,1,1},{0,0,1}}}};
	default: return null;
	}
    }


     static String toString(boolean b) {
	return (b?1:0)+"";
    }

     static String toString(boolean[] b) {
	if (b==null) return "null";
	String str="[";
	for(int i=0;i<b.length;i++) {
	    str+=toString(b[i]);
	    if(i<b.length-1) str+=",";
	}
	return str+"]";
    }

     static String toString(boolean[][] b) {
	if (b==null) return "null";
	String str="[";
	for(int i=0;i<b.length;i++) {
	    str+=toString(b[i]);
	    if(i<b.length-1) str+=",";
	}
	return str+"]";
    }

     static String toString(int[] b) {
	if (b==null) return "null";
	String str="[";
	for(int i=0;i<b.length;i++) {
	    str+=b[i];
	    if(i<b.length-1) str+=",";
	}
	return str+"]";
    }

     static String toString(int[][] b) {
	if (b==null) return "null";
	String str="[";
	for(int i=0;i<b.length;i++) {
	    str+=toString(b[i]);
	    if(i<b.length-1) str+=",";
	}
	return str+"]";
    }

     static String toString(boolean[][][] b) {
	if (b==null) return "null";
	String str="[";
	for(int i=0;i<b.length;i++) {
	    str+=toString(b[i]);
	    if(i<b.length-1) str+=",";
	}
	return str+"]";
    }

     static String toString(boolean[][][][] b) {
	if (b==null) return "null";
	String str="[";
	for(int i=0;i<b.length;i++) {
	    str+=toString(b[i]);
	    if(i<b.length-1) str+=",";
	}
	return str+"]";
    }

}
