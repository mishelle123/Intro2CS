import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;


/**
 * Automatic tests for the Non-recursive mystery task.
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class NonRecursiveMysteryTester {


    private static void checkMystery(int n) {
	checkMystery(n,mysteryComputation(n));
    }

    private static void checkMystery(int n, int answer) {
	assertEquals("Mystery computation fails for n=" + n,
		     NonRecursiveMystery.mysteryComputation(n),answer);
    }


    /**
     * Tests the non-recursive mysteryComputation method for n=5 to 100.
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-20)
    public void testMystery5to100() {
	for (int n=0; n<100; n++) {
	    checkMystery(n);
	}
    }

    /**
     * Tests the non-recursive mysteryComputation method for n=4
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testMystery4() {
	checkMystery(4);
    }

    /**
     * Tests the non-recursive mysteryComputation method for n=3
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testMystery3() {
	checkMystery(3);
    }

    /**
     * Tests the non-recursive mysteryComputation method for n=2
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testMystery2() {
	checkMystery(2);
    }

    /**
     * Tests the non-recursive mysteryComputation method for n=1
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testMystery1() {
	checkMystery(1);
    }

    /**
     * Tests the non-recursive mysteryComputation method for n=0
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testMystery0() {
	checkMystery(0);
    }

    /**
     * Tests the non-recursive mysteryComputation method for negative n
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testMysteryNeg() {
	checkMystery(-1);
	checkMystery(-2);
	checkMystery(-10);
	checkMystery(-10000);
    }

    /**
     * Tests the non-recursive mysteryComputation method for large n
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-15)
    public void testMysteryLarge1() {
	checkMystery(10000,14211);
	checkMystery(100000,146078);
	checkMystery(1000000,1480437);
	checkMystery(10000000,14902280);
    }

    /**
     * Tests the non-recursive mysteryComputation method for large n
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-7)
    public void testMysteryLarge2() {
	checkMystery(10009,1);
	checkMystery(100009,26075);
	checkMystery(1000009,3707);
    }

    private static int mysteryComputation(int n) {
	return mysteryRecursion(n, n-1);
    }
    
    private static int mysteryRecursion(int a, int b) {
	if(b <= 0) {
	    return 0;
	} else {
	    int c = mysteryRecursion(a, b - 1);
	    if(a % b == 0) {
		c += b;
	    }
	    return c;
	}
    }
}
