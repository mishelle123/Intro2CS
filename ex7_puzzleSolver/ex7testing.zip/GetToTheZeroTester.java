import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.runner.RunWith;

import il.ac.huji.cs.intro.junit.TestPenalty;
import il.ac.huji.cs.intro.junit.runners.IntroJUnit4ClassRunner;

import java.util.Arrays;


/**
 * Automatic tests for the Get-to-the-Zero task
 * 
 * @author intro2cs team
 */
@RunWith(IntroJUnit4ClassRunner.class)
public class GetToTheZeroTester {



    private static void checkGetToTheZero(int start, int[] board,
					  boolean expected, int[] refBoard) {
	assertEquals("Wrong answer for: start="+start+", board="+Arrays.toString(board),
		     expected, GetToTheZero.isSolvable(start, board));
	assertArrayEquals("Board array not in original state after: start="+
			  start+", board="+Arrays.toString(board),
			  refBoard, board);
    }
	
    private static void checkGetToTheZero(int[] refBoard, boolean[] expected, int start) {
	// board won't be modified
	int[] board = Arrays.copyOf(refBoard, refBoard.length);
	for(int i=0; i<expected.length; i++) {
	    // As long as assertions pass, board is in expected state
	    checkGetToTheZero(start+i, board, expected[i], refBoard);
	}
    }

    private static void checkGetToTheZero(int[] refBoard, boolean[] expected) {
	checkGetToTheZero(refBoard, expected, 0);
    }

    /**
     * Tests puzzleSolvable of a board, starting in all possible cells.
     **/
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleSolvable51236232420() {
	checkGetToTheZero(new int[]{5,1,2,3,6,2,3,2,4,2,0},
			  new boolean[]{false,true,true,false,true,false,false,false,true,false,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleSolvable3641342530() {
	checkGetToTheZero(new int[]{3,6,4,1,3,4,2,5,3,0},
			  new boolean[]{true,true,true,true,true,
					true,true,true,true,true});
    }
    

    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleSolvable31230() {
	checkGetToTheZero(new int[]{3,1,2,3,0},
			  new boolean[]{false,true,true,false,true});
    }

    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLength1() {
	checkGetToTheZero(new int[]{0},
			  new boolean[]{true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLength2Solvable() {
	checkGetToTheZero(new int[]{1,0},
			  new boolean[]{true,true});
    }
    

    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLength2Unsolvable() {
	checkGetToTheZero(new int[]{2,0},
			  new boolean[]{false,true});
	checkGetToTheZero(new int[]{5,0},
			  new boolean[]{false,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleDirectCycleUnsolvable() {
	checkGetToTheZero(new int[]{3,4,3,3,1,0},
			  new boolean[]{false,true,true,false,true,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleDeadEnd() {
	checkGetToTheZero(new int[]{3,6,3,3,3,0},
			  new boolean[]{false,false,true,false,false,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleIndirectCycle1Unsolvable() {
	checkGetToTheZero(new int[]{1,2,6,3,4,3,3,1,0}, 
			  new boolean[]{false,false,true,false,true,true,false,true,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleIndirectCycle2Unsolvable() {
	checkGetToTheZero(new int[]{7,4,5,2,3,4,1,0}, 
			  new boolean[]{true,false,true,false,true,false,true,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLongCycleUnsolvable1() {
	checkGetToTheZero(new int[]{1,1,1,1,1,1,2,0}, 
			  new boolean[]{false,false,false,false,false,false,false,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLongCycleUnsolvable2() {
	checkGetToTheZero(new int[]{1,2,6,4,4,3,2,7,0}, 
			  new boolean[]{false,false,true,false,true,
					true,true,false,true});
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLongPathSolvable() {
	checkGetToTheZero(new int[]{1,2,2,3,4,5,3,2,1,7,0},
			  new boolean[]{true,true,true,true,
					true,true,true,true,
					true,true,true});
    }
    
    private static int[] getLongArray(int length,int val) {
	int[] arr=new int[length];
	for(int i=0;i<length;i++) {
	    arr[i]=val;
	}
	return arr;
    }

    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLargeBoard1() {
	final int LENGTH=3000;
	int[] board = getLongArray(LENGTH,2);
	board[LENGTH-1]=0;
	checkGetToTheZero(board,
			  new boolean[]{true,false,true,false,
					true,false,true,false,
					true,false,true,false},
			  555);
    }
    
    @Test (timeout=1000) @TestPenalty(penalty=-5)
    public void testPuzzleLargeBoard2() {
	final int LENGTH=5000;
	int[] board = getLongArray(LENGTH,3);
	board[LENGTH-1]=0;
	board[0]=1;
	checkGetToTheZero(board,
			  new boolean[]{true,true,false,true,true,false,
					true,true,false,true,true,false,
					true,true,false,true,true,false},
			  4440);
    }   
}
