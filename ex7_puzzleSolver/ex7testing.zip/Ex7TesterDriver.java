import org.junit.runner.Result;

import org.junit.runner.JUnitCore;
import il.ac.huji.cs.intro.junit.internal.IntroListener;
import org.junit.internal.TextListener;

/**
 * Driver for Ex4 testers
 * 
 * @author Intro2cs Team
 *
 */
public class Ex7TesterDriver {

	/**
	 * Runs the three testers
	 * @param args not used
	 */
	public static void main(String[] args) {
		JUnitCore junit = new JUnitCore();
		junit.addListener(new IntroListener(System.out));
		//junit.addListener(new TextListener(System.out));
		Result res=junit.run(
				     NonRecursiveMysteryTester.class,
				     GetToTheZeroTester.class,
				     PuzzlePieceTester.class,
				     PuzzleSolverTester.class
		);
		System.exit(res.wasSuccessful() ? 0 : 1);
	}

}
